import { useCallback, useEffect, useState } from "react";
import { LockKeyhole } from "lucide-react";
import SiteHeader from "./components/SiteHeader";
import FeedbackDialog from "./components/FeedbackDialog";
import HeroSection from "./sections/HeroSection";
import ProductSections from "./sections/ProductSections";
import WorkflowSection from "./sections/WorkflowSection";
import AboutFooter from "./sections/AboutFooter";

export default function App() {
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [notice, setNotice] = useState(false);
  const closeFeedback = useCallback(() => setFeedbackOpen(false), []);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(false), 3600);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  return (
    <>
      <SiteHeader onFeedback={() => setFeedbackOpen(true)} onLogin={() => setNotice(true)} />
      <main>
        <HeroSection />
        <ProductSections />
        <WorkflowSection />
        <AboutFooter onFeedback={() => setFeedbackOpen(true)} />
      </main>
      {notice && (
        <div role="status" className="fixed bottom-5 left-1/2 z-40 flex -translate-x-1/2 items-center gap-2.5 rounded-full border border-[#d4e3df] bg-white px-4 py-3 text-xs font-medium text-[#45627f] shadow-xl sm:text-sm">
          <LockKeyhole className="size-4 text-[#0c4b80]" /> Workspace login isn’t connected in this homepage preview.
        </div>
      )}
      <FeedbackDialog open={feedbackOpen} onClose={closeFeedback} />
    </>
  );
}
