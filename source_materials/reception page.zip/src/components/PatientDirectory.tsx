import { Mail, MapPin, Phone, Search, UserRound } from "lucide-react";
import { formatDate } from "../lib/format";
import type { Patient } from "../types";

type PatientDirectoryProps = {
  patients: Patient[];
  search: string;
  onSearchChange: (value: string) => void;
  onEdit: (patient: Patient) => void;
};

function initials(name: string): string {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? "").join("");
}

export function PatientDirectory({ patients, search, onSearchChange, onEdit }: PatientDirectoryProps) {
  return (
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white" aria-labelledby="directory-heading">
      <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <div>
          <div className="flex items-center gap-2.5">
            <h2 id="directory-heading" className="text-base font-semibold tracking-tight text-slate-900">Patient records</h2>
            <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-full border border-slate-200 bg-slate-50 px-2 text-xs font-medium tabular-nums text-slate-600">{patients.length}</span>
          </div>
          <p className="mt-1 text-sm text-slate-500">Search by patient name or ID to find a record.</p>
        </div>
        <label className="relative block w-full sm:max-w-[330px]">
          <span className="sr-only">Search patient records by name or patient ID</span>
          <Search size={17} strokeWidth={1.8} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
          <input
            type="search"
            value={search}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Search name or patient ID…"
            className="h-10 w-full rounded-lg border border-slate-200 bg-white pl-10 pr-3.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-slate-500 focus:ring-2 focus:ring-slate-200"
          />
        </label>
      </div>

      <div className="overflow-x-auto" role="region" aria-label="Patient records table" tabIndex={0}>
        <table className="w-full min-w-[1040px] border-collapse text-left">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
              <th scope="col" className="px-6 py-3.5">Patient</th>
              <th scope="col" className="px-4 py-3.5">Demographics</th>
              <th scope="col" className="px-4 py-3.5">Contact numbers</th>
              <th scope="col" className="px-4 py-3.5">Address &amp; email</th>
              <th scope="col" className="px-6 py-3.5 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {patients.map((patient) => (
              <tr key={patient.id} className="group transition-colors hover:bg-slate-50/70">
                <td className="px-6 py-4">
                  <div className="flex min-w-[190px] items-center gap-3">
                    <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-slate-100 text-xs font-semibold text-slate-600" aria-hidden="true">{initials(patient.fullName)}</span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium text-slate-900">{patient.fullName}</span>
                      <span className="mt-0.5 block font-mono text-[11px] tracking-wide text-slate-500">{patient.id}</span>
                    </span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className="block whitespace-nowrap text-sm font-medium text-slate-700">{patient.age} years <span className="font-normal text-slate-500">· {patient.gender}</span></span>
                  <span className="mt-1 block whitespace-nowrap text-xs text-slate-500">DOB · {formatDate(patient.dob)}</span>
                </td>
                <td className="px-4 py-4">
                  <div className="space-y-1.5">
                    <span className="inline-flex items-center gap-2 whitespace-nowrap text-sm text-slate-700"><Phone size={13} className="shrink-0 text-slate-400" /><span className="sr-only">Personal: </span>{patient.personalPhone}</span>
                    {patient.sharedPhone && <span className="flex items-center gap-2 whitespace-nowrap text-sm text-slate-600"><Phone size={13} className="shrink-0 text-slate-400" /><span className="sr-only">Shared / family: </span>{patient.sharedPhone}</span>}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className="flex max-w-[260px] items-start gap-2 text-sm leading-5 text-slate-700"><MapPin size={13} className="mt-1 shrink-0 text-slate-400" /><span className="line-clamp-2">{patient.address}</span></span>
                  <span className="mt-1.5 block max-w-[260px] truncate text-xs text-slate-500">{patient.email}</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button type="button" onClick={() => onEdit(patient)} className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300">
                    <UserRound size={14} strokeWidth={1.8} /> Edit Info
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {patients.length === 0 && (
          <div className="flex flex-col items-center px-6 py-14 text-center">
            <div className="flex h-11 w-11 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-slate-500"><Search size={18} /></div>
            <h3 className="mt-4 text-sm font-semibold text-slate-900">No patient records found</h3>
            <p className="mt-1 max-w-sm text-sm text-slate-500">Try another name or patient ID, or clear your search to see all records.</p>
            {search && <button type="button" onClick={() => onSearchChange("")} className="mt-4 text-sm font-medium text-slate-700 underline decoration-slate-300 underline-offset-4 hover:text-slate-950">Clear search</button>}
          </div>
        )}
      </div>

      <div className="flex flex-col gap-2 border-t border-slate-100 px-5 py-3.5 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <span>Showing <span className="font-medium text-slate-700">{patients.length}</span> patient{patients.length === 1 ? "" : "s"}</span>
        <span className="inline-flex items-center gap-1.5"><Mail size={13} /> Select <span className="font-medium">Edit Info</span> to view or update full details</span>
      </div>
    </section>
  );
}
