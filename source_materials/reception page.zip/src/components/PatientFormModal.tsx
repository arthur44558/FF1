import { useState, type FormEvent } from "react";
import { CalendarDays, Check, CheckCircle2, ChevronDown, CircleUserRound, Mail, MapPin, Phone, ShieldCheck, UserRound } from "lucide-react";
import { calculateAge } from "../lib/format";
import { GENDER_OPTIONS, type Patient, type PatientDraft, type PatientFormValues } from "../types";
import { ModalFrame } from "./ModalFrame";

type PatientFormModalProps = {
  patient: Patient | null;
  onClose: () => void;
  onSave: (draft: PatientDraft) => void;
};

type TextFieldProps = {
  id: string;
  label: string;
  value: string | number;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
  required?: boolean;
  autoComplete?: string;
  min?: number;
  max?: number;
  maxLength?: number;
};

const inputClassName = "block w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-slate-500 focus:ring-2 focus:ring-slate-200";
const labelClassName = "mb-1.5 block text-[13px] font-medium text-slate-700";
const requiredMark = <span className="ml-0.5 text-slate-400" aria-hidden="true">*</span>;
const relationshipOptions = ["Parent", "Spouse / partner", "Child", "Sibling", "Caregiver", "Other"];

function TextField({ id, label, value, onChange, type = "text", placeholder, required = false, autoComplete, min, max, maxLength }: TextFieldProps) {
  return (
    <div>
      <label htmlFor={id} className={labelClassName}>{label}{required && requiredMark}</label>
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        required={required}
        autoComplete={autoComplete}
        min={min}
        max={max}
        maxLength={maxLength}
        className={inputClassName}
      />
    </div>
  );
}

function getInitialValues(patient: Patient | null): PatientFormValues {
  return {
    fullName: patient?.fullName ?? "",
    email: patient?.email ?? "",
    dob: patient?.dob ?? "",
    gender: patient?.gender ?? "",
    personalPhone: patient?.personalPhone ?? "",
    verifiedPhone: patient?.verifiedPhone ?? "",
    isPhoneVerified: patient?.isPhoneVerified ?? false,
    sharedPhone: patient?.sharedPhone ?? "",
    relationship: patient?.relationship ?? "",
    address: patient?.address ?? ""
  };
}

export function PatientFormModal({ patient, onClose, onSave }: PatientFormModalProps) {
  const isEditing = patient !== null;
  const [values, setValues] = useState<PatientFormValues>(() => getInitialValues(patient));
  const [formError, setFormError] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpValue, setOtpValue] = useState("");
  const [otpError, setOtpError] = useState("");

  const update = <K extends keyof PatientFormValues>(key: K, value: PatientFormValues[K]) => {
    setValues((previous) => ({ ...previous, [key]: value }));
    setFormError("");
  };

  const handleDobChange = (dob: string) => {
    setValues((previous) => ({ ...previous, dob }));
    setFormError("");
  };

  const handlePersonalPhoneChange = (phone: string) => {
    setFormError("");
    if (isEditing) {
      setValues((previous) => ({
        ...previous,
        personalPhone: phone,
        verifiedPhone: previous.personalPhone === phone ? previous.verifiedPhone : "",
        isPhoneVerified: previous.personalPhone === phone ? previous.isPhoneVerified : false
      }));
      return;
    }
    setValues((previous) => ({ ...previous, personalPhone: phone, verifiedPhone: "", isPhoneVerified: false }));
    setOtpSent(false);
    setOtpValue("");
    setOtpError("");
  };

  const handleVerifiedPhoneChange = (phone: string) => {
    setValues((previous) => ({ ...previous, verifiedPhone: phone, isPhoneVerified: false }));
    setFormError("");
  };

  const handleSendVerificationCode = () => {
    if (values.personalPhone.replace(/\D/g, "").length < 7) {
      setFormError("Enter a valid personal phone number before requesting a verification code.");
      return;
    }
    setFormError("");
    setOtpValue("");
    setOtpError("");
    setOtpSent(true);
  };

  const handleOtpChange = (rawCode: string) => {
    const code = rawCode.replace(/\D/g, "").slice(0, 4);
    setOtpValue(code);
    if (code.length < 4) {
      setOtpError("");
      return;
    }
    if (code === "1234") {
      setOtpError("");
      setValues((previous) => ({ ...previous, verifiedPhone: previous.personalPhone, isPhoneVerified: true }));
    } else {
      setOtpError("That code did not match. Use 1234 for this demo.");
    }
  };

  const handleChangePhone = () => {
    setValues((previous) => ({ ...previous, verifiedPhone: "", isPhoneVerified: false }));
    setOtpSent(false);
    setOtpValue("");
    setOtpError("");
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!values.fullName.trim()) {
      setFormError("Enter the patient’s full name.");
      return;
    }
    if (!values.address.trim()) {
      setFormError("Enter a permanent address.");
      return;
    }
    const calculatedAge = calculateAge(values.dob);
    if (calculatedAge === null) {
      setFormError("Enter a valid date of birth.");
      return;
    }
    if (!isEditing && !values.isPhoneVerified) {
      setFormError("Verify the personal phone number with the SMS code before registering.");
      return;
    }
    const phoneDigits = (phone: string) => phone.replace(/\D/g, "").length;
    if (phoneDigits(values.personalPhone) < 7 || (values.verifiedPhone && phoneDigits(values.verifiedPhone) < 7)) {
      setFormError("Enter a valid phone number with at least 7 digits.");
      return;
    }
    if (values.isPhoneVerified && phoneDigits(values.verifiedPhone) < 7) {
      setFormError("Enter the phone number that was verified before marking this record as verified.");
      return;
    }
    if (values.sharedPhone && !values.relationship) {
      setFormError("Choose the relationship for the shared or family phone.");
      return;
    }
    if (!values.gender) return;

    setFormError("");
    onSave({
      ...values,
      fullName: values.fullName.trim(),
      email: values.email.trim(),
      personalPhone: values.personalPhone.trim(),
      verifiedPhone: values.verifiedPhone.trim(),
      sharedPhone: values.sharedPhone.trim(),
      relationship: values.sharedPhone ? values.relationship : "",
      address: values.address.trim(),
      age: calculatedAge,
      gender: values.gender
    });
  };

  const today = new Date().toISOString().slice(0, 10);
  const liveAge = calculateAge(values.dob);

  return (
    <ModalFrame titleId="patient-form-title" onClose={onClose} panelClassName="relative max-w-[760px]" closeLabel={isEditing ? "Close edit patient form" : "Close registration form"}>
      <div className="max-h-[90vh] overflow-y-auto">
        <div className="border-b border-slate-200 px-6 py-5 pr-14 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-700">
              {isEditing ? <UserRound size={19} strokeWidth={1.8} /> : <CircleUserRound size={19} strokeWidth={1.8} />}
            </div>
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-500">{isEditing ? `Patient · ${patient.id}` : "New patient"}</p>
              <h2 id="patient-form-title" className="mt-0.5 text-lg font-semibold tracking-tight text-slate-900">{isEditing ? "Edit patient information" : "Register first-time patient"}</h2>
            </div>
          </div>
          <p className="mt-3 text-sm leading-6 text-slate-500">{isEditing ? "Update the record below. Changes are saved to this browser immediately." : "Add the patient’s details to create a new CareTrack record."}</p>
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-6 sm:px-8">
          <section aria-labelledby="identity-heading">
            <div className="mb-4 flex items-center gap-2.5">
              <UserRound size={16} className="text-slate-500" strokeWidth={1.8} />
              <h3 id="identity-heading" className="text-sm font-semibold text-slate-900">Personal details</h3>
              <span className="ml-auto text-xs text-slate-400">* Required</span>
            </div>
            <div className="grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <TextField id="fullName" label="Full name" value={values.fullName} onChange={(value) => update("fullName", value)} placeholder="Enter full name" required autoComplete="name" maxLength={100} />
              </div>
              <TextField id="email" label="Email address" value={values.email} onChange={(value) => update("email", value)} type="email" placeholder="name@example.com" required autoComplete="email" maxLength={150} />
              <div>
                <label htmlFor="gender" className={labelClassName}>Gender{requiredMark}</label>
                <div className="relative">
                  <select id="gender" name="gender" value={values.gender} onChange={(event) => update("gender", event.target.value as PatientFormValues["gender"])} className={`${inputClassName} appearance-none pr-10`} required>
                    <option value="" disabled>Select gender</option>
                    {GENDER_OPTIONS.map((gender) => <option key={gender} value={gender}>{gender}</option>)}
                  </select>
                  <ChevronDown size={15} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>
              </div>
              <div>
                <label htmlFor="dob" className={labelClassName}>Date of birth{requiredMark}</label>
                <div className="relative">
                  <input id="dob" name="dob" type="date" max={today} value={values.dob} onChange={(event) => handleDobChange(event.target.value)} className={`${inputClassName} pr-10`} required />
                  <CalendarDays size={15} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>
                <p className="mt-1.5 text-xs text-slate-500" aria-live="polite">{liveAge === null ? "Age will be calculated from date of birth." : `Calculated age · ${liveAge} ${liveAge === 1 ? "year" : "years"}`}</p>
              </div>
            </div>
          </section>

          <div className="my-6 border-t border-slate-100" />

          <section aria-labelledby="contact-heading">
            <div className="mb-4 flex items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 text-slate-500"><Phone size={15} strokeWidth={1.8} /><Mail size={15} strokeWidth={1.8} /></span>
              <h3 id="contact-heading" className="text-sm font-semibold text-slate-900">Contact information</h3>
            </div>
            <div className="grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2">
              <div className={!isEditing ? "sm:col-span-2" : ""}>
                <label htmlFor="personalPhone" className={labelClassName}>Personal phone number{requiredMark}</label>
                <div className="flex min-w-0 items-center gap-2">
                  <input id="personalPhone" name="personalPhone" type="tel" value={values.personalPhone} onChange={(event) => handlePersonalPhoneChange(event.target.value)} placeholder="(555) 555-0100" required autoComplete="tel" maxLength={30} disabled={!isEditing && values.isPhoneVerified} className={`${inputClassName} min-w-0 flex-1 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-600`} />
                  {!isEditing && !values.isPhoneVerified && <button type="button" onClick={handleSendVerificationCode} disabled={values.personalPhone.replace(/\D/g, "").length < 7} className="inline-flex min-h-10 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white px-3 text-[11px] font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-45 sm:text-xs">{otpSent ? "Resend code" : "Send Verification Code"}</button>}
                  {!isEditing && values.isPhoneVerified && <button type="button" onClick={handleChangePhone} className="shrink-0 text-[11px] font-medium text-slate-500 underline decoration-slate-300 underline-offset-4 hover:text-slate-900">Change</button>}
                </div>
                {!isEditing && values.isPhoneVerified && <p className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-800"><CheckCircle2 size={14} /> Verified Phone</p>}
              </div>
              {!isEditing && otpSent && !values.isPhoneVerified && <div className="sm:col-span-2 rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
                <label htmlFor="otpCode" className={labelClassName}>SMS verification code</label>
                <div className="flex max-w-[360px] items-center gap-3">
                  <input id="otpCode" name="otpCode" type="text" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{4}" maxLength={4} value={otpValue} onChange={(event) => handleOtpChange(event.target.value)} placeholder="Enter 4-digit code" aria-describedby="otp-help" aria-invalid={Boolean(otpError)} className={`${inputClassName} max-w-[200px] font-mono tracking-[0.18em]`} />
                  <span className="text-xs text-slate-500">Enter the code to verify</span>
                </div>
                <p id="otp-help" className="mt-2 text-[11px] leading-4 text-slate-500">Demo only: no SMS is sent. Use code <span className="font-mono font-semibold text-slate-700">1234</span>.</p>
                {otpError && <p className="mt-2 text-xs text-rose-700" role="alert">{otpError}</p>}
              </div>}
              {isEditing && <TextField id="verifiedPhone" label="Verified phone number" value={values.verifiedPhone} onChange={handleVerifiedPhoneChange} type="tel" placeholder="Verified contact number" maxLength={30} />}
              {isEditing && <div className="sm:col-span-2">
                <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-slate-50/70 px-3.5 py-2.5 transition hover:border-slate-300">
                  <input type="checkbox" checked={values.isPhoneVerified} onChange={(event) => update("isPhoneVerified", event.target.checked)} className="h-4 w-4 rounded border-slate-300 accent-[#09090b] focus:ring-slate-500" />
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-medium text-slate-800">SMS / OTP verification complete</span>
                    <span className="mt-0.5 block text-xs text-slate-500">Update this status when editing an existing record.</span>
                  </span>
                  {values.isPhoneVerified && <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-800"><ShieldCheck size={13} /> Verified</span>}
                </label>
              </div>}
              <TextField id="sharedPhone" label="Shared / family phone" value={values.sharedPhone} onChange={(value) => update("sharedPhone", value)} type="tel" placeholder="Optional contact number" maxLength={30} />
              <div>
                <label htmlFor="relationship" className={labelClassName}>Relationship{values.sharedPhone && requiredMark}</label>
                <div className="relative">
                  <select id="relationship" name="relationship" value={values.relationship} onChange={(event) => update("relationship", event.target.value)} className={`${inputClassName} appearance-none pr-10`} required={Boolean(values.sharedPhone)}>
                    <option value="">{values.sharedPhone ? "Select relationship" : "Select if applicable"}</option>
                    {relationshipOptions.map((relationship) => <option key={relationship} value={relationship}>{relationship}</option>)}
                  </select>
                  <ChevronDown size={15} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>
              </div>
            </div>
          </section>

          <div className="my-6 border-t border-slate-100" />

          <section aria-labelledby="address-heading">
            <div className="mb-4 flex items-center gap-2.5">
              <MapPin size={16} className="text-slate-500" strokeWidth={1.8} />
              <h3 id="address-heading" className="text-sm font-semibold text-slate-900">Permanent address</h3>
            </div>
            <label htmlFor="address" className={labelClassName}>Street address and location{requiredMark}</label>
            <textarea id="address" name="address" value={values.address} onChange={(event) => update("address", event.target.value)} placeholder="Street, city, state, ZIP code" rows={3} required maxLength={300} className={`${inputClassName} resize-y`} />
          </section>

          {formError && <p className="mt-5 rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-xs text-slate-700" role="alert">{formError}</p>}
          <div className="mt-7 flex flex-col-reverse gap-2.5 border-t border-slate-100 pt-5 sm:flex-row sm:justify-end">
            <button type="button" onClick={onClose} className="inline-flex min-h-10 items-center justify-center rounded-lg border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 transition hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300">Cancel</button>
            <button type="submit" className="inline-flex min-h-10 items-center justify-center gap-2 rounded-lg bg-[#09090b] px-4 text-sm font-medium text-white transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500 focus-visible:ring-offset-2">
              {isEditing ? <Check size={16} /> : <UserRound size={16} />}
              {isEditing ? "Save changes" : "Register patient"}
            </button>
          </div>
        </form>
      </div>
    </ModalFrame>
  );
}
