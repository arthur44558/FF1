import { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, Bell, CalendarDays, Check, ChevronDown, ChevronRight, CircleCheck, Clock3, HeartPulse, Info, LogOut } from "lucide-react";
import type { Patient } from "../types";

type ReceptionistHeaderProps = {
  patients: Patient[];
  unreadCount: number;
  onMarkNotificationsRead: () => void;
  onLogOut: () => void;
};

type NotificationItem = {
  id: string;
  kind: "System update" | "Registration log" | "Alert";
  title: string;
  detail: string;
  time: string;
  sortAt: number;
};

type OpenPanel = "notifications" | "profile" | null;

function timeToday(hour: number, minute: number): number {
  const date = new Date();
  date.setHours(hour, minute, 0, 0);
  return date.getTime();
}

const systemNotifications: NotificationItem[] = [
  {
    id: "system-sync",
    kind: "System update",
    title: "Reception workspace is up to date",
    detail: "The patient directory is ready for front-desk intake.",
    time: "Today · 09:14",
    sortAt: timeToday(9, 14)
  },
  {
    id: "contact-review",
    kind: "Alert",
    title: "Contact review reminder",
    detail: "Review pending phone verification with patients at check-in.",
    time: "Today · 08:52",
    sortAt: timeToday(8, 52)
  }
];

function notificationIcon(kind: NotificationItem["kind"]) {
  if (kind === "Alert") return <AlertTriangle size={15} className="text-slate-700" />;
  if (kind === "Registration log") return <CircleCheck size={15} className="text-slate-700" />;
  return <Info size={15} className="text-slate-500" />;
}

function displayRegistrationDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Recently";
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(date);
}

export function ReceptionistHeader({ patients, unreadCount, onMarkNotificationsRead, onLogOut }: ReceptionistHeaderProps) {
  const [openPanel, setOpenPanel] = useState<OpenPanel>(null);
  const panelRoot = useRef<HTMLDivElement>(null);
  const dateLabel = useMemo(
    () => new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric" }).format(new Date()),
    []
  );

  const notificationItems = useMemo(() => {
    const registrations = [...patients]
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, 3)
      .map((patient): NotificationItem => ({
        id: `registration-${patient.id}`,
        kind: "Registration log",
        title: `${patient.fullName} added to the directory`,
        detail: `Patient ID ${patient.id}`,
        time: displayRegistrationDate(patient.createdAt),
        sortAt: new Date(patient.createdAt).getTime()
      }));
    return [...systemNotifications, ...registrations].sort((a, b) => b.sortAt - a.sortAt);
  }, [patients]);

  useEffect(() => {
    if (!openPanel) return;
    const closeOnOutsideClick = (event: PointerEvent) => {
      if (event.target instanceof Node && !panelRoot.current?.contains(event.target)) setOpenPanel(null);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpenPanel(null);
    };
    document.addEventListener("pointerdown", closeOnOutsideClick);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("pointerdown", closeOnOutsideClick);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [openPanel]);

  const toggleNotifications = () => {
    const nextPanel = openPanel === "notifications" ? null : "notifications";
    setOpenPanel(nextPanel);
    if (nextPanel === "notifications") onMarkNotificationsRead();
  };

  const toggleProfile = () => setOpenPanel((current) => current === "profile" ? null : "profile");

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
      <div className="flex h-[68px] items-center justify-between gap-3 px-4 sm:px-7 lg:px-9">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#09090b] text-white lg:hidden"><HeartPulse size={17} /></span>
          <div className="flex min-w-0 items-center gap-2 text-sm">
            <span className="hidden font-medium text-slate-500 sm:inline">CareTrack</span>
            <ChevronRight size={14} className="hidden shrink-0 text-slate-300 sm:inline" />
            <span className="truncate font-medium text-slate-800">Patient directory</span>
          </div>
        </div>

        <div ref={panelRoot} className="flex shrink-0 items-center gap-2.5 sm:gap-4">
          <div className="hidden items-center gap-2 text-xs text-slate-500 lg:flex"><CalendarDays size={15} className="text-slate-400" />{dateLabel}</div>
          <span className="hidden h-5 w-px bg-slate-200 lg:block" />

          <div className="relative">
            <button
              type="button"
              onClick={toggleNotifications}
              aria-label={`Notifications${unreadCount > 0 ? `, ${unreadCount} unread` : ""}`}
              aria-expanded={openPanel === "notifications"}
              aria-haspopup="true"
              className="relative inline-flex h-10 w-10 items-center justify-center rounded-lg border border-transparent text-slate-600 transition hover:border-slate-200 hover:bg-slate-50 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"
            >
              <Bell size={18} strokeWidth={1.8} />
              {unreadCount > 0 && <span className="absolute right-1 top-1 inline-flex min-h-[17px] min-w-[17px] items-center justify-center rounded-full border-2 border-white bg-[#09090b] px-1 text-[9px] font-semibold leading-none text-white">{unreadCount > 9 ? "9+" : unreadCount}</span>}
            </button>
            {openPanel === "notifications" && (
              <section className="absolute right-0 top-[calc(100%+10px)] z-40 w-[min(380px,calc(100vw-2rem))] overflow-hidden rounded-xl border border-slate-200 bg-white" aria-label="Recent notifications">
                <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3.5">
                  <div>
                    <h2 className="text-sm font-semibold text-slate-900">Notifications</h2>
                    <p className="mt-0.5 text-xs text-slate-500">System updates, patient activity, and alerts</p>
                  </div>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2 py-1 text-[10px] font-medium text-slate-600"><Check size={12} /> Read</span>
                </div>
                <div className="max-h-[min(65vh,440px)] divide-y divide-slate-100 overflow-y-auto">
                  {notificationItems.map((item) => (
                    <article key={item.id} className="flex gap-3 px-4 py-3.5">
                      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-slate-50">{notificationIcon(item.kind)}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-3">
                          <p className="text-xs font-medium leading-5 text-slate-800">{item.title}</p>
                          <span className="shrink-0 text-[10px] text-slate-400">{item.time}</span>
                        </div>
                        <p className="mt-0.5 text-[11px] leading-4 text-slate-500">{item.detail}</p>
                        <span className="mt-2 inline-flex rounded border border-slate-200 px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wide text-slate-500">{item.kind}</span>
                      </div>
                    </article>
                  ))}
                </div>
                <div className="flex items-center gap-2 border-t border-slate-200 bg-slate-50/70 px-4 py-2.5 text-[10px] text-slate-500"><Clock3 size={12} /> Showing recent activity for this demo workspace</div>
              </section>
            )}
          </div>

          <div className="relative">
            <button
              type="button"
              onClick={toggleProfile}
              aria-expanded={openPanel === "profile"}
              aria-haspopup="true"
              className="flex items-center gap-2 rounded-lg border border-transparent py-1 pl-1 pr-1.5 text-left transition hover:border-slate-200 hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300 sm:gap-2.5 sm:pr-2"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-slate-100 text-[11px] font-semibold text-slate-800">ST</span>
              <span className="block min-w-0">
                <span className="block max-w-[120px] truncate text-[11px] font-medium text-slate-800 sm:max-w-none sm:text-xs">Sofia Torres</span>
                <span className="mt-0.5 block text-[10px] text-slate-500">RCP-302</span>
              </span>
              <ChevronDown size={14} className="hidden text-slate-400 sm:block" />
            </button>
            {openPanel === "profile" && (
              <section className="absolute right-0 top-[calc(100%+10px)] z-40 w-[min(290px,calc(100vw-2rem))] overflow-hidden rounded-xl border border-slate-200 bg-white" aria-label="Receptionist account menu">
                <div className="border-b border-slate-200 px-4 py-4">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-slate-100 text-xs font-semibold text-slate-800">ST</span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-semibold text-slate-900">Sofia Torres</span>
                      <span className="mt-0.5 block text-xs text-slate-500">Receptionist · RCP-302</span>
                    </span>
                  </div>
                </div>
                <div className="space-y-3 px-4 py-3.5">
                  <div className="flex items-center justify-between gap-3 text-xs"><span className="text-slate-500">Account ID</span><span className="font-mono font-medium text-slate-800">RCP-302</span></div>
                  <div className="flex items-center justify-between gap-3 text-xs"><span className="text-slate-500">Workspace</span><span className="font-medium text-slate-800">Front desk</span></div>
                  <p className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-2 text-[10px] leading-4 text-slate-500">Demo account. Authentication is not connected in this prototype.</p>
                </div>
                <div className="border-t border-slate-200 p-2">
                  <button type="button" onClick={() => { setOpenPanel(null); onLogOut(); }} className="flex h-9 w-full items-center gap-2 rounded-lg px-2.5 text-left text-xs font-medium text-slate-700 transition hover:bg-slate-50 hover:text-slate-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300"><LogOut size={15} /> Log Out</button>
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
