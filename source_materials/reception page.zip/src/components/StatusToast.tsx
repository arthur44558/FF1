import { CheckCircle2, X } from "lucide-react";

type StatusToastProps = {
  message: string;
  onDismiss: () => void;
};

export function StatusToast({ message, onDismiss }: StatusToastProps) {
  return (
    <div role="status" aria-live="polite" className="fixed bottom-5 right-5 z-[60] flex max-w-[calc(100vw-2.5rem)] items-center gap-3 rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm text-slate-800 shadow-[0_10px_30px_-18px_rgba(15,23,42,0.32)]">
      <CheckCircle2 size={17} className="shrink-0 text-slate-900" />
      <span>{message}</span>
      <button type="button" onClick={onDismiss} aria-label="Dismiss notification" className="ml-1 inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"><X size={15} /></button>
    </div>
  );
}
