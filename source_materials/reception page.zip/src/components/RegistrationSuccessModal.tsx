import { useState } from "react";
import { Check, CheckCheck, Clipboard, Copy, UserRound } from "lucide-react";
import { ModalFrame } from "./ModalFrame";

type RegistrationSuccessModalProps = {
  patientId: string;
  patientName: string;
  persisted: boolean;
  onClose: () => void;
};

export function RegistrationSuccessModal({ patientId, patientName, persisted, onClose }: RegistrationSuccessModalProps) {
  const [copied, setCopied] = useState(false);

  const copyId = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(patientId);
      } else {
        const input = document.createElement("textarea");
        input.value = patientId;
        input.style.position = "fixed";
        input.style.opacity = "0";
        document.body.appendChild(input);
        input.select();
        document.execCommand("copy");
        input.remove();
      }
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  return (
    <ModalFrame titleId="registration-success-title" onClose={onClose} panelClassName="relative max-w-[430px]" closeLabel="Close registration confirmation">
      <div className="px-6 pb-6 pt-8 text-center sm:px-8">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full border border-slate-200 bg-slate-100 text-slate-900">
          <Check size={22} strokeWidth={2} />
        </div>
        <p className="mt-5 text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Registration complete</p>
        <h2 id="registration-success-title" className="mt-1.5 text-xl font-semibold tracking-tight text-slate-900">Patient added successfully</h2>
        <p className="mt-2 text-sm leading-6 text-slate-500"><span className="font-medium text-slate-700">{patientName}</span> is now in the patient directory.</p>

        <div className="mt-6 rounded-lg border border-slate-200 bg-slate-50 p-4 text-left">
          <span className="text-[11px] font-semibold uppercase tracking-[0.09em] text-slate-500">Patient ID</span>
          <div className="mt-2 flex items-center justify-between gap-3">
            <span className="font-mono text-lg font-semibold tracking-[0.07em] text-slate-900">{patientId}</span>
            <button type="button" onClick={copyId} className="inline-flex h-9 shrink-0 items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300">
              {copied ? <CheckCheck size={14} className="text-slate-900" /> : <Copy size={14} />}
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
        </div>
        <div className="mt-5 flex items-start gap-2.5 rounded-lg border border-slate-200 bg-white px-3.5 py-3 text-left">
          <Clipboard size={16} className="mt-0.5 shrink-0 text-slate-500" />
          <p className="text-xs leading-5 text-slate-500">{persisted ? "The new record is saved in this browser and is ready to review in the directory." : "Browser storage is unavailable. This record is available for this session only and may not remain after reload."}</p>
        </div>
        <button type="button" onClick={onClose} className="mt-6 inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-[#09090b] px-4 text-sm font-medium text-white transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500 focus-visible:ring-offset-2"><UserRound size={16} /> Done</button>
      </div>
    </ModalFrame>
  );
}
