import { seedPatients } from "../data/patients";
import type { Patient } from "../types";

const STORAGE_KEY = "caretrack-patients-v1";
const ID_MIN = 10_000;
const ID_RANGE = 90_000;

export function loadPatients(): Patient[] {
  if (typeof window === "undefined") return seedPatients;

  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return seedPatients;

    const parsed: unknown = JSON.parse(stored);
    if (
      Array.isArray(parsed) &&
      parsed.every(
        (record): record is Patient =>
          typeof record === "object" &&
          record !== null &&
          "id" in record &&
          typeof record.id === "string" &&
          "fullName" in record &&
          typeof record.fullName === "string" &&
          "createdAt" in record &&
          typeof record.createdAt === "string"
      )
    ) {
      return parsed;
    }
  } catch {
    // A blocked or malformed storage entry should not prevent the directory from opening.
  }

  return seedPatients;
}

export function savePatients(patients: Patient[]): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(patients));
    return true;
  } catch {
    // Keep the current in-memory session usable and let the UI explain that persistence failed.
    return false;
  }
}

export function generatePatientId(patients: Patient[]): string {
  const usedIds = new Set(patients.map((patient) => patient.id));
  const random = new Uint32Array(1);

  if (typeof crypto !== "undefined" && "getRandomValues" in crypto) {
    crypto.getRandomValues(random);
  } else {
    random[0] = Math.floor(Math.random() * 0xffff_ffff);
  }

  const start = random[0] % ID_RANGE;
  for (let offset = 0; offset < ID_RANGE; offset += 1) {
    const candidate = ID_MIN + ((start + offset) % ID_RANGE);
    const id = `PT-${candidate}`;
    if (!usedIds.has(id)) return id;
  }

  throw new Error("No unused patient IDs remain in the PT-XXXXX range.");
}
