import { useEffect, useMemo, useState } from "react";
import { Activity, HeartPulse, Plus, ShieldCheck, UsersRound, Phone, MapPin, Database, Search, LogOut } from "lucide-react";
import { PatientDirectory } from "./components/PatientDirectory";
import { PatientFormModal } from "./components/PatientFormModal";
import { ReceptionistHeader } from "./components/ReceptionistHeader";
import { RegistrationSuccessModal } from "./components/RegistrationSuccessModal";
import { StatusToast } from "./components/StatusToast";
import { generatePatientId, loadPatients, savePatients } from "./lib/patient-store";
import type { Patient, PatientDraft } from "./types";

type FormState = { mode: "register" } | { mode: "edit"; patient: Patient } | null;
type SuccessState = { patientId: string; patientName: string; persisted: boolean } | null;

export default function App() {
  const [patients, setPatients] = useState<Patient[]>(() => loadPatients());
  const [search, setSearch] = useState("");
  const [formState, setFormState] = useState<FormState>(null);
  const [success, setSuccess] = useState<SuccessState>(null);
  const [notice, setNotice] = useState("");
  const [unreadNotifications, setUnreadNotifications] = useState(3);
  const [sessionActive, setSessionActive] = useState(true);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(""), 3600);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  const visiblePatients = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    const matched = query
      ? patients.filter((patient) => patient.id.toLocaleLowerCase().includes(query) || patient.fullName.toLocaleLowerCase().includes(query))
      : patients;
    return [...matched].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [patients, search]);

  const verifiedCount = patients.filter((patient) => patient.isPhoneVerified).length;
  const familyContactCount = patients.filter((patient) => Boolean(patient.sharedPhone)).length;

  const closeForm = () => setFormState(null);
  const handleSave = (draft: PatientDraft) => {
    if (formState?.mode === "edit") {
      const existing = formState.patient;
      const updatedPatients = patients.map((patient) => patient.id === existing.id ? { ...existing, ...draft } : patient);
      const persisted = savePatients(updatedPatients);
      setPatients(updatedPatients);
      setFormState(null);
      setNotice(persisted ? `Changes saved for ${draft.fullName}.` : `Changes for ${draft.fullName} are available this session only; browser storage is unavailable.`);
      return;
    }

    const patient: Patient = {
      ...draft,
      id: generatePatientId(patients),
      createdAt: new Date().toISOString()
    };
    const updatedPatients = [patient, ...patients];
    const persisted = savePatients(updatedPatients);
    setPatients(updatedPatients);
    setUnreadNotifications((count) => count + 1);
    setFormState(null);
    setSuccess({ patientId: patient.id, patientName: patient.fullName, persisted });
  };

  if (!sessionActive) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f8fafc] px-5 py-10 text-slate-900">
        <section className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-7 text-center sm:p-9" aria-labelledby="signed-out-title">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-[#09090b] text-white"><LogOut size={20} /></span>
          <p className="mt-5 text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">CareTrack reception</p>
          <h1 id="signed-out-title" className="mt-1.5 text-xl font-semibold tracking-tight">Demo session ended</h1>
          <p className="mt-2 text-sm leading-6 text-slate-500">You have left the reception interface. This local preview does not connect to an authenticated account service.</p>
          <button type="button" onClick={() => setSessionActive(true)} className="mt-6 inline-flex min-h-10 items-center justify-center rounded-lg bg-[#09090b] px-4 text-sm font-medium text-white transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500 focus-visible:ring-offset-2">Return to demo portal</button>
        </section>
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-[248px] flex-col border-r border-slate-200 bg-white lg:flex">
        <div className="flex h-[76px] items-center gap-3 border-b border-slate-200 px-6">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#09090b] text-white"><HeartPulse size={19} strokeWidth={1.9} /></span>
          <span className="min-w-0">
            <span className="block text-[15px] font-semibold tracking-tight text-slate-900">CareTrack</span>
            <span className="mt-0.5 block text-[9px] font-semibold uppercase tracking-[0.17em] text-slate-500">Reception portal</span>
          </span>
        </div>

        <div className="px-4 pt-7">
          <p className="px-3 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-400">Front desk</p>
          <div className="relative mt-2.5 flex h-10 items-center gap-3 rounded-lg bg-slate-100 px-3 text-sm font-medium text-slate-900" aria-current="page">
            <span className="absolute bottom-2 left-0 top-2 w-[2px] rounded-r bg-[#09090b]" />
            <Search size={17} strokeWidth={1.8} className="text-slate-700" />
            Patient directory
            <span className="ml-auto rounded-md bg-white px-1.5 py-0.5 text-[10px] tabular-nums text-slate-600">{patients.length}</span>
          </div>
        </div>

        <div className="mt-auto border-t border-slate-200 p-4">
          <div className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-3">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-700"><Database size={14} className="text-slate-500" /> Reception workspace</div>
            <p className="mt-1.5 text-[11px] leading-5 text-slate-500">Demo records only. Do not enter live patient information in browser storage.</p>
          </div>
          <div className="mt-4 flex items-center justify-between px-1 text-[10px] text-slate-400">
            <span>CareTrack · Front desk</span>
            <span>v1.0</span>
          </div>
        </div>
      </aside>

      <div className="min-h-screen lg:pl-[248px]">
        <ReceptionistHeader
          patients={patients}
          unreadCount={unreadNotifications}
          onMarkNotificationsRead={() => setUnreadNotifications(0)}
          onLogOut={() => setSessionActive(false)}
        />

        <main className="mx-auto max-w-[1480px] px-5 pb-10 pt-7 sm:px-7 sm:pt-9 lg:px-9">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-xs font-medium text-slate-500"><Activity size={14} /> Reception operations</div>
              <h1 className="text-[26px] font-semibold tracking-[-0.04em] text-slate-900 sm:text-[30px]">Patients</h1>
              <p className="mt-1.5 text-sm text-slate-500">Search, review, and register patient records.</p>
            </div>
            <button type="button" onClick={() => setFormState({ mode: "register" })} className="inline-flex min-h-10 items-center justify-center gap-2 self-start rounded-lg bg-[#09090b] px-4 text-sm font-medium text-white transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500 focus-visible:ring-offset-2 sm:self-auto">
              <Plus size={17} strokeWidth={2} /> Register First-Time Patient
            </button>
          </div>

          <section className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-3" aria-label="Patient directory summary">
            <div className="flex min-h-[92px] items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-4 sm:px-5">
              <div>
                <p className="text-xs font-medium text-slate-500">Total patients</p>
                <p className="mt-1.5 text-[25px] font-semibold leading-none tracking-tight tabular-nums text-slate-900">{patients.length}</p>
              </div>
              <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600"><UsersRound size={17} strokeWidth={1.8} /></span>
            </div>
            <div className="flex min-h-[92px] items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-4 sm:px-5">
              <div>
                <p className="text-xs font-medium text-slate-500">Verified phone numbers</p>
                <p className="mt-1.5 text-[25px] font-semibold leading-none tracking-tight tabular-nums text-slate-900">{verifiedCount}<span className="ml-1.5 text-sm font-medium text-slate-400">/ {patients.length}</span></p>
              </div>
              <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600"><ShieldCheck size={17} strokeWidth={1.8} /></span>
            </div>
            <div className="flex min-h-[92px] items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-4 sm:px-5">
              <div>
                <p className="text-xs font-medium text-slate-500">Shared / family contacts</p>
                <p className="mt-1.5 text-[25px] font-semibold leading-none tracking-tight tabular-nums text-slate-900">{familyContactCount}</p>
              </div>
              <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600"><Phone size={17} strokeWidth={1.8} /></span>
            </div>
          </section>

          <div className="mt-7">
            <PatientDirectory
              patients={visiblePatients}
              search={search}
              onSearchChange={setSearch}
              onEdit={(patient) => setFormState({ mode: "edit", patient })}
            />
          </div>

          <div className="mt-5 flex flex-col gap-2 border-t border-slate-200/80 pt-4 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
            <span className="inline-flex items-center gap-1.5"><MapPin size={13} className="text-slate-400" /> Reception workspace</span>
            <span>Demo only — browser-local storage is not approved for live patient data.</span>
          </div>
        </main>
      </div>

      {formState && (
        <PatientFormModal
          key={formState.mode === "edit" ? formState.patient.id : "new-patient"}
          patient={formState.mode === "edit" ? formState.patient : null}
          onClose={closeForm}
          onSave={handleSave}
        />
      )}
      {success && <RegistrationSuccessModal patientId={success.patientId} patientName={success.patientName} persisted={success.persisted} onClose={() => setSuccess(null)} />}
      {notice && <StatusToast message={notice} onDismiss={() => setNotice("")} />}
    </div>
  );
}
