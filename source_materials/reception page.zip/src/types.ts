export const GENDER_OPTIONS = ["Woman", "Man", "Non-binary", "Prefer not to say", "Other"] as const;

export type Gender = (typeof GENDER_OPTIONS)[number];

export type Patient = {
  id: string;
  fullName: string;
  email: string;
  dob: string;
  age: number;
  gender: Gender;
  personalPhone: string;
  verifiedPhone: string;
  isPhoneVerified: boolean;
  sharedPhone: string;
  relationship: string;
  address: string;
  createdAt: string;
};

export type PatientDraft = Omit<Patient, "id" | "createdAt">;

export type PatientFormValues = Omit<PatientDraft, "gender" | "age"> & {
  gender: Gender | "";
};
