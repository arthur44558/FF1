# CareTrack Receptionist Portal — Outcomes

## Patient directory and live search
- [x] Display a searchable table/list of all registered patients.
- [x] Provide a live search input allowing receptionists to instantly filter patient records by Patient ID (e.g., `PT-20496`) or Patient Name.

## Edit patient information
- [x] Every patient row must include an "Edit Info" button.
- [x] Clicking it opens a clean modal pre-filled with the patient's existing details (Name, DOB, Age, Gender, Address, Email, Personal Phone, Verified Phone, Shared/Family Phone) allowing seamless updates.
- [x] Saved patient edits must immediately update the directory state.

## First-time registration and confirmation
- [x] Include a prominent primary action button labeled "Register First-Time Patient" at the top right.
- [x] Clicking it opens a registration modal with fields for Full Name, Email Address, Date of Birth (DOB), Gender (Dropdown), Personal Phone Number, Shared / Family Phone Number (with relationship tag), and Permanent Address (Textarea); age is calculated automatically from DOB and displayed as a live summary, not entered manually.
- [x] Upon submitting the registration form, generate a unique Patient ID (e.g., `PT-XXXXX`), insert the patient data into the records state and browser-local storage, and display a popup block confirming success with the generated ID and a quick "Copy" button.

## Swiss Minimalist interface and interaction quality
- [x] Follow the Swiss Minimalist design system: pure white cards, soft slate-50 canvas `#f8fafc`, razor-thin `border-slate-200` borders, dark slate-900 headers, and a monochromatic deep charcoal action theme `#09090b` with Lucide icons.
- [x] Keep the presentation clean, flat, spacious, and professional for healthcare operations; avoid heavy drop shadows and skeuomorphic styling.
- [x] Use deep charcoal (`#09090b`) for primary CTAs and clear status feedback elements.
- [x] Provide responsive, accessible modal and form interactions, validation, clear status feedback, and Lucide icon affordances.

## Receptionist header, notifications, and profile
- [x] Update the receptionist portal top header to include a Notification Bell Icon with an active badge counter; clicking it opens a clean dropdown/panel displaying recent system updates, registration logs, and alerts.
- [x] Add a Receptionist Profile Widget displaying avatar initials, Receptionist Name, and ID (e.g., `RCP-302`); clicking it opens a dropdown menu with account info and a secure "Log Out" option.

## Registration OTP and calculated age
- [x] Beside the Personal Phone Number input field in the first-time patient registration modal, add a "Send Verification Code" button; when clicked, simulate sending an OTP and display an inline OTP input block using demo code `1234`.
- [x] When the correct OTP is entered and validated, instantly lock the personal phone field and display a green success badge labeled "Verified Phone".
- [x] Remove the manual Age input block; retain the Date of Birth (DOB) picker and automatically calculate the patient's exact age from the selected DOB, displaying it live in the form summary.

## Patient directory table clean-up
- [x] Completely remove the phone status / verification status column and all phone-verification badges/sub-text from the registered-patients table.
- [x] Retain these table columns: Patient ID & Name; Demographics (Age & Gender, DOB); Contact Numbers (Personal & Shared / Family phone numbers only); Address & Email; and Actions ("Edit Info" button).

## Preserved core features
- [x] Keep live search filtering by Patient ID or Name, the Edit Info patient modal, and the registration success popup showing the generated unique `PT-XXXXX` ID with a Copy button fully intact and operational.
