export type Severity = 'Severe' | 'Mid' | 'Low'
export type ReminderChannel = 'SMS / WhatsApp' | 'Voice Call'

export interface ReminderSeed {
  offsetDays: number
  channel: ReminderChannel
  detail: string
}

export interface PatientRecord {
  id: string
  name: string
  age: number
  gender: string
  severity: Severity
  personalPhone: string
  sharedPhone?: string
  sharedContactLabel?: string
  doctor: string
  specialty: string
  address: string
  careContext: string
  reminders: ReminderSeed[]
}

// Fictional sample records only; they are not connected to a live EHR.
export const SAMPLE_PATIENTS: PatientRecord[] = [
  {
    id: 'PT-20481',
    name: 'Zahra Ali',
    age: 64,
    gender: 'Female',
    severity: 'Severe',
    personalPhone: '+1 (202) 555-0142',
    sharedPhone: '+1 (202) 555-0187',
    sharedContactLabel: 'Daughter · additional contact',
    doctor: 'Dr. Amina Patel',
    specialty: 'Cardiology',
    address: '18 Meadowline Ave, Northpoint, IL 60608',
    careContext: 'Post-discharge check-in · medication review',
    reminders: [
      { offsetDays: -7, channel: 'SMS / WhatsApp', detail: 'Discharge follow-up sent' },
      { offsetDays: 0, channel: 'Voice Call', detail: 'Priority care-plan check-in' },
      { offsetDays: 4, channel: 'SMS / WhatsApp', detail: 'Confirm next appointment' },
    ],
  },
  {
    id: 'PT-20496',
    name: 'Miguel Santos',
    age: 51,
    gender: 'Male',
    severity: 'Severe',
    personalPhone: '+1 (202) 555-0138',
    doctor: 'Dr. Daniel Kim',
    specialty: 'Pulmonology',
    address: '42 Alder Street, Northpoint, IL 60611',
    careContext: 'Respiratory review · symptom monitoring',
    reminders: [
      { offsetDays: -2, channel: 'SMS / WhatsApp', detail: 'Symptom check message sent' },
      { offsetDays: 0, channel: 'SMS / WhatsApp', detail: 'Confirm symptom update' },
      { offsetDays: 2, channel: 'Voice Call', detail: 'Clinician follow-up call' },
    ],
  },
  {
    id: 'PT-20511',
    name: 'Clara Nguyen',
    age: 39,
    gender: 'Female',
    severity: 'Mid',
    personalPhone: '+1 (202) 555-0164',
    sharedPhone: '+1 (202) 555-0121',
    sharedContactLabel: 'Partner · shared contact',
    doctor: 'Dr. Evelyn Moore',
    specialty: 'Endocrinology',
    address: '7 Birch Court, Northpoint, IL 60614',
    careContext: 'Care-plan review · lab results follow-up',
    reminders: [
      { offsetDays: -5, channel: 'Voice Call', detail: 'Initial care-plan review' },
      { offsetDays: -1, channel: 'SMS / WhatsApp', detail: 'Appointment reminder sent' },
      { offsetDays: 0, channel: 'SMS / WhatsApp', detail: 'Confirm follow-up attendance' },
      { offsetDays: 5, channel: 'Voice Call', detail: 'Review progress with care team' },
    ],
  },
  {
    id: 'PT-20530',
    name: 'James Okafor',
    age: 72,
    gender: 'Male',
    severity: 'Mid',
    personalPhone: '+1 (202) 555-0192',
    doctor: 'Dr. Rebecca Chen',
    specialty: 'Family Medicine',
    address: '105 Pine Avenue, Northpoint, IL 60618',
    careContext: 'Routine care coordination · mobility check',
    reminders: [
      { offsetDays: -3, channel: 'SMS / WhatsApp', detail: 'Routine follow-up sent' },
      { offsetDays: 1, channel: 'Voice Call', detail: 'Check mobility and support needs' },
      { offsetDays: 4, channel: 'SMS / WhatsApp', detail: 'Appointment confirmation' },
    ],
  },
  {
    id: 'PT-20544',
    name: 'Eleanor Price',
    age: 28,
    gender: 'Female',
    severity: 'Low',
    personalPhone: '+1 (202) 555-0173',
    doctor: 'Dr. Marcus Reed',
    specialty: 'Dermatology',
    address: '63 Willow Walk, Northpoint, IL 60621',
    careContext: 'Routine check-in · treatment plan follow-up',
    reminders: [
      { offsetDays: -8, channel: 'SMS / WhatsApp', detail: 'Treatment-plan message sent' },
      { offsetDays: 0, channel: 'Voice Call', detail: 'Routine progress check-in' },
      { offsetDays: 8, channel: 'SMS / WhatsApp', detail: 'Close the follow-up loop' },
    ],
  },
  {
    id: 'PT-20567',
    name: 'Amir Haddad',
    age: 46,
    gender: 'Male',
    severity: 'Low',
    personalPhone: '+1 (202) 555-0116',
    sharedPhone: '+1 (202) 555-0159',
    sharedContactLabel: 'Spouse · additional contact',
    doctor: 'Dr. Sofia Laurent',
    specialty: 'Neurology',
    address: '29 Brookfield Road, Northpoint, IL 60624',
    careContext: 'Routine care coordination · wellness review',
    reminders: [
      { offsetDays: -5, channel: 'Voice Call', detail: 'Routine wellness check' },
      { offsetDays: -2, channel: 'SMS / WhatsApp', detail: 'Follow-up reminder sent' },
      { offsetDays: 3, channel: 'Voice Call', detail: 'Review next steps' },
    ],
  },
]
