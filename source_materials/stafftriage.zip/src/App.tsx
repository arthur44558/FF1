import { useEffect, useMemo, useState, type KeyboardEvent } from 'react'
import {
  Activity,
  ArrowRight,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleCheck,
  FileClock,
  MapPin,
  MessageSquare,
  Pencil,
  Phone,
  PhoneCall,
  Search,
  ShieldCheck,
  Stethoscope,
  Users,
  X,
} from 'lucide-react'
import {
  SAMPLE_PATIENTS,
  type PatientRecord,
  type ReminderChannel,
  type Severity,
} from './data/records'

type Reminder = {
  date: string
  channel: ReminderChannel
  detail: string
}

type ScheduledPatient = PatientRecord & { timeline: Reminder[] }
type RemarksMap = Record<string, string>

const REMARKS_STORAGE_KEY = 'staff-follow-up-dashboard:remarks:v1'
const BARRIERS_STORAGE_KEY = 'staff-follow-up-dashboard:barriers:v1'
const RESULTS_STORAGE_KEY = 'staff-follow-up-dashboard:consultation-results:v1'
const FINALIZED_STORAGE_KEY = 'staff-follow-up-dashboard:finalized:v1'
const severityRank: Record<Severity, number> = { Severe: 0, Mid: 1, Low: 2 }
type BarrierFlags = Record<string, boolean>
type RecordTextMap = Record<string, string>
type FinalizedMap = Record<string, boolean>

function toIsoDate(date: Date): string {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function shiftIsoDate(isoDate: string, days: number): string {
  const date = new Date(`${isoDate}T12:00:00`)
  date.setDate(date.getDate() + days)
  return toIsoDate(date)
}

function prettyDate(isoDate: string, options: Intl.DateTimeFormatOptions = {}): string {
  const date = new Date(`${isoDate}T12:00:00`)
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    ...options,
  }).format(date)
}

function followUpKey(patientId: string, date: string): string {
  return `${patientId}::${date}`
}

function readSavedRemarks(): RemarksMap {
  try {
    const saved = window.localStorage.getItem(REMARKS_STORAGE_KEY)
    return saved ? (JSON.parse(saved) as RemarksMap) : {}
  } catch {
    return {}
  }
}

function readSavedBarrierFlags(): BarrierFlags {
  try {
    const saved = window.localStorage.getItem(BARRIERS_STORAGE_KEY)
    return saved ? (JSON.parse(saved) as BarrierFlags) : {}
  } catch {
    return {}
  }
}

function readSavedRecordText(key: string): RecordTextMap {
  try {
    const saved = window.localStorage.getItem(key)
    return saved ? (JSON.parse(saved) as RecordTextMap) : {}
  } catch {
    return {}
  }
}

function readSavedFinalized(): FinalizedMap {
  try {
    const saved = window.localStorage.getItem(FINALIZED_STORAGE_KEY)
    return saved ? (JSON.parse(saved) as FinalizedMap) : {}
  } catch {
    return {}
  }
}

function severityClasses(severity: Severity): string {
  if (severity === 'Severe') {
    return 'border-zinc-900 bg-zinc-900 text-white'
  }
  if (severity === 'Mid') {
    return 'border-slate-300 bg-slate-100 text-slate-700'
  }
  return 'border-slate-200 bg-white text-slate-500'
}

function App() {
  const todayIso = toIsoDate(new Date())
  const [selectedDate, setSelectedDate] = useState(todayIso)
  const [searchTerm, setSearchTerm] = useState('')
  const [remarks, setRemarks] = useState<RemarksMap>(readSavedRemarks)
  const [barrierFlags, setBarrierFlags] = useState<BarrierFlags>(readSavedBarrierFlags)
  const [consultationResults, setConsultationResults] = useState<RecordTextMap>(() => readSavedRecordText(RESULTS_STORAGE_KEY))
  const [finalizedRecords, setFinalizedRecords] = useState<FinalizedMap>(readSavedFinalized)
  const [activePatientId, setActivePatientId] = useState<string | null>(null)
  const [isEditingReceipt, setIsEditingReceipt] = useState(false)

  const patients = useMemo<ScheduledPatient[]>(
    () =>
      SAMPLE_PATIENTS.map((patient) => ({
        ...patient,
        timeline: patient.reminders
          .map((reminder) => ({
            date: shiftIsoDate(todayIso, reminder.offsetDays),
            channel: reminder.channel,
            detail: reminder.detail,
          }))
          .sort((a, b) => a.date.localeCompare(b.date)),
      })),
    [todayIso],
  )

  const scheduledToday = useMemo(
    () =>
      patients
        .flatMap((patient) => {
          const action = patient.timeline.find((reminder) => reminder.date === selectedDate)
          return action ? [{ ...patient, action }] : []
        })
        .sort((a, b) => severityRank[a.severity] - severityRank[b.severity] || a.name.localeCompare(b.name)),
    [patients, selectedDate],
  )

  const visiblePatients = useMemo(() => {
    const query = searchTerm.trim().toLowerCase()
    if (!query) return scheduledToday
    return scheduledToday.filter((patient) =>
      [patient.name, patient.id, patient.doctor, patient.specialty, patient.personalPhone, patient.sharedPhone]
        .filter(Boolean)
        .some((value) => value!.toLowerCase().includes(query)),
    )
  }, [scheduledToday, searchTerm])

  const activePatient = activePatientId
    ? patients.find((patient) => patient.id === activePatientId) ?? null
    : null

  useEffect(() => {
    try {
      window.localStorage.setItem(REMARKS_STORAGE_KEY, JSON.stringify(remarks))
    } catch {
      // Notes still remain in this view if browser storage is unavailable.
    }
  }, [remarks])

  useEffect(() => {
    try {
      window.localStorage.setItem(BARRIERS_STORAGE_KEY, JSON.stringify(barrierFlags))
    } catch {
      // Barrier selections remain in this view if browser storage is unavailable.
    }
  }, [barrierFlags])

  useEffect(() => {
    try {
      window.localStorage.setItem(RESULTS_STORAGE_KEY, JSON.stringify(consultationResults))
    } catch {
      // Results remain in this view if browser storage is unavailable.
    }
  }, [consultationResults])

  useEffect(() => {
    try {
      window.localStorage.setItem(FINALIZED_STORAGE_KEY, JSON.stringify(finalizedRecords))
    } catch {
      // Finalized state remains in this view if browser storage is unavailable.
    }
  }, [finalizedRecords])

  useEffect(() => {
    if (!activePatient) return
    const handleEscape = (event: KeyboardEvent | globalThis.KeyboardEvent) => {
      if (event.key === 'Escape') setActivePatientId(null)
    }
    window.addEventListener('keydown', handleEscape)
    return () => window.removeEventListener('keydown', handleEscape)
  }, [activePatient])

  const updateRemarks = (patientId: string, value: string) => {
    setRemarks((current) => ({ ...current, [patientId]: value }))
  }

  const updateOnlineConsultation = (patientId: string, checked: boolean) => {
    setBarrierFlags((current) => ({ ...current, [patientId]: checked }))
  }

  const openReceipt = (patientId: string, edit = false) => {
    const recordKey = followUpKey(patientId, selectedDate)
    setActivePatientId(patientId)
    setIsEditingReceipt(edit || !finalizedRecords[recordKey])
  }

  const saveReceipt = (recordKey: string, result: string, note: string) => {
    setConsultationResults((current) => ({ ...current, [recordKey]: result }))
    setRemarks((current) => ({ ...current, [recordKey]: note }))
    setFinalizedRecords((current) => ({ ...current, [recordKey]: true }))
    setActivePatientId(null)
  }

  const setDateFromInput = (value: string) => {
    if (value && value <= todayIso) setSelectedDate(value)
  }

  const handleRowKeyDown = (event: KeyboardEvent<HTMLTableRowElement>, patientId: string) => {
    if (event.target instanceof HTMLElement && ['INPUT', 'BUTTON', 'TEXTAREA'].includes(event.target.tagName)) return
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      openReceipt(patientId)
    }
  }

  const isViewingToday = selectedDate === todayIso
  const severeCount = scheduledToday.filter((patient) => patient.severity === 'Severe').length
  const voiceCount = scheduledToday.filter((patient) => patient.action.channel === 'Voice Call').length
  const smsCount = scheduledToday.length - voiceCount
  const selectedDateLabel = isViewingToday ? "Today's follow-ups" : 'Follow-ups on selected date'
  const activeRecordKey = activePatient ? followUpKey(activePatient.id, selectedDate) : ''

  return (
    <div className="min-h-screen bg-canvas text-slate-900">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-6 px-5 py-4 sm:px-8 lg:px-12">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-zinc-900">
              <Activity size={19} strokeWidth={1.8} aria-hidden="true" />
            </div>
            <div className="leading-tight">
              <p className="text-[11px] font-bold uppercase tracking-[0.17em] text-slate-900">Care / Ops</p>
              <p className="mt-1 text-[10px] font-medium uppercase tracking-[0.12em] text-slate-400">Staff workspace</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-right">
            <div className="hidden sm:block">
              <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-400">Daily operations</p>
              <p className="mt-1 text-xs font-medium text-slate-600">{prettyDate(todayIso, { weekday: 'short', month: 'short', day: 'numeric' })}</p>
            </div>
            <div className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600" aria-label="Staff member">
              ST
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1600px] px-5 pb-12 pt-8 sm:px-8 sm:pt-10 lg:px-12">
        <div className="flex flex-col gap-7">
          <section className="flex flex-col justify-between gap-6 xl:flex-row xl:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2">
                <span className="inline-flex h-1.5 w-1.5 rounded-full bg-zinc-900" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-500">Clinical follow-up · staff view</span>
              </div>
              <h1 className="text-[29px] font-semibold tracking-[-0.045em] text-slate-900 sm:text-[36px]">Staff Follow-Up Dashboard</h1>
              <p className="mt-2 text-sm text-slate-500 sm:text-[15px]">Daily Priority Triage &amp; Actionable Reminders</p>
            </div>
            <div className="flex flex-wrap items-end gap-3">
              <div className="min-w-[190px]">
                <label htmlFor="selected-date" className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-500">Review date</label>
                <div className="relative">
                  <CalendarDays size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                  <input
                    id="selected-date"
                    type="date"
                    max={todayIso}
                    value={selectedDate}
                    onChange={(event) => setDateFromInput(event.target.value)}
                    className="h-11 w-full rounded-lg border border-slate-200 bg-white pl-10 pr-3 text-sm font-medium text-slate-800 outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                    aria-label="Select present or past review date"
                  />
                </div>
              </div>
              <div className="flex h-11 items-center rounded-lg border border-slate-200 bg-white p-1">
                <button
                  type="button"
                  onClick={() => setSelectedDate((date) => shiftIsoDate(date, -1))}
                  className="flex h-9 w-9 items-center justify-center rounded-md text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300"
                  aria-label="Previous day"
                >
                  <ChevronLeft size={17} />
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedDate((date) => shiftIsoDate(date, 1))}
                  disabled={selectedDate >= todayIso}
                  className="flex h-9 w-9 items-center justify-center rounded-md text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300 disabled:cursor-not-allowed disabled:text-slate-200 disabled:hover:bg-transparent"
                  aria-label="Next day"
                >
                  <ChevronRight size={17} />
                </button>
              </div>
              {!isViewingToday && (
                <button
                  type="button"
                  onClick={() => setSelectedDate(todayIso)}
                  className="h-11 rounded-lg bg-zinc-900 px-4 text-xs font-semibold text-white transition hover:bg-zinc-700 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2"
                >
                  Back to today
                </button>
              )}
            </div>
          </section>

          <section className="grid grid-cols-1 gap-3 sm:grid-cols-3" aria-label="Selected date summary">
            <SummaryCard
              label={selectedDateLabel}
              value={String(scheduledToday.length).padStart(2, '0')}
              detail={`${smsCount} message${smsCount === 1 ? '' : 's'} · ${voiceCount} voice call${voiceCount === 1 ? '' : 's'}`}
              icon={<CalendarDays size={17} strokeWidth={1.8} />}
            />
            <SummaryCard
              label="Severe priority"
              value={String(severeCount).padStart(2, '0')}
              detail="Placed first in the triage list"
              icon={<ShieldCheck size={17} strokeWidth={1.8} />}
            />
            <SummaryCard
              label="Voice calls"
              value={String(voiceCount).padStart(2, '0')}
              detail="Scheduled for selected date"
              icon={<PhoneCall size={17} strokeWidth={1.8} />}
            />
          </section>

          <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
            <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <h2 className="text-[15px] font-semibold tracking-[-0.02em] text-slate-900">Actionable record logs</h2>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10px] font-semibold text-slate-600">
                    <span className="h-1.5 w-1.5 rounded-full bg-zinc-900" />
                    {scheduledToday.length} due
                  </span>
                </div>
                <p className="mt-1.5 text-xs text-slate-500">{prettyDate(selectedDate, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })} <span className="mx-1 text-slate-300">/</span> Sorted by severity</p>
              </div>
              <div className="relative w-full sm:max-w-[270px]">
                <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                <input
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                  type="search"
                  placeholder="Search name, doctor, or ID"
                  aria-label="Search patients due on the selected date"
                  className="h-10 w-full rounded-lg border border-slate-200 bg-slate-50/70 pl-9 pr-3 text-xs text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:bg-white focus:ring-2 focus:ring-slate-100"
                />
              </div>
            </div>

            <div className="dashboard-scrollbar overflow-x-auto">
              <table className="w-full min-w-[1450px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80">
                    <th scope="col" className="px-6 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Patient / demographics</th>
                    <th scope="col" className="px-4 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Severity</th>
                    <th scope="col" className="px-4 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Action required</th>
                    <th scope="col" className="px-4 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Contact numbers</th>
                    <th scope="col" className="px-4 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Doctor / specialty</th>
                    <th scope="col" className="min-w-[205px] px-4 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Distance / time constraint</th>
                    <th scope="col" className="min-w-[245px] px-4 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Staff remarks</th>
                    <th scope="col" className="min-w-[150px] px-4 py-3.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Follow-up receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {visiblePatients.map((patient) => {
                    const recordKey = followUpKey(patient.id, selectedDate)
                    const isFinalized = Boolean(finalizedRecords[recordKey])
                    const rowRemark = remarks[recordKey] ?? remarks[patient.id] ?? ''
                    return (
                    <tr
                      key={patient.id}
                      role="button"
                      tabIndex={0}
                      aria-haspopup="dialog"
                      aria-label={`${isFinalized ? 'View completed' : 'Open'} follow-up receipt for ${patient.name}`}
                      onClick={() => openReceipt(patient.id)}
                      onKeyDown={(event) => handleRowKeyDown(event, patient.id)}
                      className={`group cursor-pointer transition-colors focus:outline-none ${isFinalized ? 'bg-slate-200/80 hover:bg-slate-200 focus:bg-slate-200' : 'bg-white hover:bg-slate-50/75 focus:bg-slate-50'}`}
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-600">
                            {patient.name.split(' ').map((part) => part[0]).join('')}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="truncate text-[13px] font-semibold text-slate-900">{patient.name}</span>
                              <ArrowRight size={13} className="shrink-0 text-slate-300 opacity-0 transition group-hover:translate-x-0.5 group-hover:opacity-100" aria-hidden="true" />
                            </div>
                            <p className="mt-1 text-[11px] text-slate-500">{patient.age} yrs <span className="mx-1 text-slate-300">·</span> {patient.gender} <span className="mx-1 text-slate-300">·</span> <span className="font-mono text-[10px]">{patient.id}</span></p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[10px] font-semibold ${severityClasses(patient.severity)}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${patient.severity === 'Severe' ? 'bg-white' : patient.severity === 'Mid' ? 'bg-slate-500' : 'bg-slate-300'}`} />
                          {patient.severity}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <ActionBadge channel={patient.action.channel} />
                        <p className="mt-1.5 text-[10px] text-slate-400">{isViewingToday ? 'Due today' : 'Due on selected date'}</p>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-start gap-2 text-[11px] text-slate-700">
                          <Phone size={12} className="mt-0.5 shrink-0 text-slate-400" aria-hidden="true" />
                          <div>
                            <p className="font-medium tabular-nums">{patient.personalPhone}</p>
                            <p className="mt-1 text-[10px] text-slate-400">Personal</p>
                          </div>
                        </div>
                        {patient.sharedPhone && (
                          <div className="mt-2 flex items-start gap-2 text-[11px] text-slate-600">
                            <Users size={12} className="mt-0.5 shrink-0 text-slate-400" aria-hidden="true" />
                            <div>
                              <p className="font-medium tabular-nums">{patient.sharedPhone}</p>
                              <p className="mt-1 text-[10px] text-slate-400">{patient.sharedContactLabel ?? 'Shared / additional'}</p>
                            </div>
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-4">
                        <p className="text-[11px] font-medium text-slate-800">{patient.doctor}</p>
                        <p className="mt-1 text-[10px] text-slate-500">{patient.specialty}</p>
                      </td>
                      <td className="px-4 py-4" onClick={(event) => event.stopPropagation()}>
                        <label htmlFor={`online-consultation-${patient.id}`} className={`inline-flex min-h-9 items-center gap-2 rounded-md border px-2.5 py-2 transition ${isFinalized ? 'cursor-not-allowed border-slate-300 bg-slate-300/60' : `cursor-pointer ${barrierFlags[patient.id] ? 'border-zinc-900 bg-slate-50' : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'}`}`}>
                          <input
                            id={`online-consultation-${patient.id}`}
                            type="checkbox"
                            checked={Boolean(barrierFlags[patient.id])}
                            onChange={(event) => updateOnlineConsultation(patient.id, event.target.checked)}
                            disabled={isFinalized}
                            aria-label={`Online consultation for ${patient.name} due to a distance or time constraint`}
                            className="h-4 w-4 shrink-0 rounded border-slate-300 accent-zinc-900 focus:ring-2 focus:ring-slate-400"
                          />
                          <span className="text-[11px] font-medium text-slate-700">Online consultation</span>
                        </label>
                      </td>
                      <td className="px-4 py-4" onClick={(event) => event.stopPropagation()}>
                        <div className="relative">
                          <MessageSquare size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                          <input
                            value={rowRemark}
                            onChange={(event) => updateRemarks(recordKey, event.target.value)}
                            onKeyDown={(event) => event.stopPropagation()}
                            onClick={(event) => event.stopPropagation()}
                            readOnly={isFinalized}
                            onFocus={(event) => event.stopPropagation()}
                            type="text"
                            placeholder="Add a note…"
                            aria-label={`Staff remarks for ${patient.name}`}
                            className={`h-9 w-full rounded-md border border-slate-200 pl-8 pr-2.5 text-[11px] text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:ring-2 focus:ring-slate-100 ${isFinalized ? 'bg-slate-200/70' : 'bg-white hover:border-slate-300'}`}
                          />
                        </div>
                      </td>
                      <td className="px-4 py-4" onClick={(event) => event.stopPropagation()}>
                        {isFinalized ? (
                          <div className="flex items-center gap-2.5">
                            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-slate-300/70 px-2 py-1.5 text-[10px] font-semibold text-slate-700">
                              <CircleCheck size={12} /> Done
                            </span>
                            <button
                              type="button"
                              onClick={() => openReceipt(patient.id, true)}
                              aria-label={`Edit consultation result or remark for ${patient.name}`}
                              className="inline-flex h-7 items-center gap-1 rounded-md px-2 text-[10px] font-semibold text-slate-600 transition hover:bg-white hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-400"
                            >
                              <Pencil size={11} /> Edit
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] font-medium text-slate-400">Not finalized</span>
                        )}
                      </td>
                    </tr>
                    )
                  })}
                  {visiblePatients.length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-6 py-16 text-center">
                        <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-slate-500">
                          {scheduledToday.length === 0 ? <FileClock size={19} strokeWidth={1.7} /> : <Search size={18} strokeWidth={1.7} />}
                        </div>
                        <p className="mt-4 text-sm font-semibold text-slate-800">
                          {scheduledToday.length === 0 ? 'No reminders scheduled for this date' : 'No matching patients'}
                        </p>
                        <p className="mx-auto mt-1.5 max-w-sm text-xs leading-5 text-slate-500">
                          {scheduledToday.length === 0
                            ? 'Choose another present or past date to review its scheduled follow-up actions.'
                            : 'Try another name, doctor, or patient ID.'}
                        </p>
                        {scheduledToday.length === 0 && !isViewingToday && (
                          <button type="button" onClick={() => setSelectedDate(todayIso)} className="mt-4 text-xs font-semibold text-slate-900 underline decoration-slate-300 underline-offset-4 hover:decoration-slate-900">
                            Return to today
                          </button>
                        )}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex flex-col gap-2 border-t border-slate-200 bg-slate-50/60 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[10px] text-slate-500">
                <span className="inline-flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-zinc-900" /> Severe first</span>
                <span>Records with a milestone on the selected date</span>
              </div>
              <p className="text-[10px] text-slate-400">Sample records · not connected to a live EHR</p>
            </div>
          </section>

          <footer className="flex flex-col gap-2 border-t border-slate-200 pt-4 text-[10px] text-slate-400 sm:flex-row sm:items-center sm:justify-between">
            <span className="inline-flex items-center gap-1.5"><ShieldCheck size={13} /> Staff follow-up workspace</span>
            <span>Remarks and online consultation marks save to this browser · sample clinical data</span>
          </footer>
        </div>
      </main>

      {activePatient && (
        <ReceiptModal
          key={`${activePatient.id}-${selectedDate}`}
          patient={activePatient}
          selectedDate={selectedDate}
          todayIso={todayIso}
          note={remarks[activeRecordKey] ?? remarks[activePatient.id] ?? ''}
          result={consultationResults[activeRecordKey] ?? ''}
          onlineConsultation={Boolean(barrierFlags[activePatient.id])}
          isFinalized={Boolean(finalizedRecords[activeRecordKey])}
          canEdit={!finalizedRecords[activeRecordKey] || isEditingReceipt}
          onSave={(result, note) => saveReceipt(activeRecordKey, result, note)}
          onEdit={() => setIsEditingReceipt(true)}
          onClose={() => setActivePatientId(null)}
        />
      )}
    </div>
  )
}

function SummaryCard({ label, value, detail, icon }: { label: string; value: string; detail: string; icon: React.ReactNode }) {
  return (
    <div className="flex min-h-[104px] items-start justify-between rounded-xl border border-slate-200 bg-white px-5 py-4">
      <div>
        <p className="text-[10px] font-semibold uppercase tracking-[0.13em] text-slate-500">{label}</p>
        <div className="mt-2 flex items-baseline gap-2.5">
          <span className="text-[27px] font-semibold leading-none tracking-[-0.05em] text-slate-900">{value}</span>
          <span className="text-[10px] text-slate-400">{detail}</span>
        </div>
      </div>
      <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600">{icon}</div>
    </div>
  )
}

function ActionBadge({ channel }: { channel: ReminderChannel }) {
  const Icon = channel === 'Voice Call' ? PhoneCall : MessageSquare
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap rounded-md bg-zinc-900 px-2.5 py-1.5 text-[10px] font-semibold text-white">
      <Icon size={12} strokeWidth={2} aria-hidden="true" />
      {channel}
    </span>
  )
}

function ReceiptModal({
  patient,
  selectedDate,
  todayIso,
  note,
  result,
  onlineConsultation,
  isFinalized,
  canEdit,
  onSave,
  onEdit,
  onClose,
}: {
  patient: ScheduledPatient
  selectedDate: string
  todayIso: string
  note: string
  result: string
  onlineConsultation: boolean
  isFinalized: boolean
  canEdit: boolean
  onSave: (result: string, note: string) => void
  onEdit: () => void
  onClose: () => void
}) {
  const [draftResult, setDraftResult] = useState(result)
  const [draftNote, setDraftNote] = useState(note)

  useEffect(() => {
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = previousOverflow
    }
  }, [])

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/35 p-0 backdrop-blur-[2px] sm:items-center sm:p-5"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose()
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="receipt-title"
        className="flex max-h-[94vh] w-full max-w-[760px] flex-col overflow-hidden rounded-t-2xl border border-slate-200 bg-white shadow-none sm:max-h-[88vh] sm:rounded-2xl"
      >
        <div className="flex items-start justify-between gap-5 border-b border-slate-200 px-5 py-5 sm:px-7">
          <div>
            <div className="mb-2 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-500">
              <FileClock size={13} /> Follow-up receipt <span className="text-slate-300">/</span> <span className="font-mono">{patient.id}</span>
            </div>
            <h2 id="receipt-title" className="text-xl font-semibold tracking-[-0.04em] text-slate-900 sm:text-2xl">{patient.name}</h2>
            <p className="mt-1.5 text-xs text-slate-500">{patient.age} years <span className="mx-1 text-slate-300">·</span> {patient.gender} <span className="mx-1 text-slate-300">·</span> {patient.careContext}</p>
            {isFinalized && <span className="mt-2 inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-600"><CircleCheck size={12} /> Follow-up finalized</span>}
          </div>
          <button type="button" onClick={onClose} aria-label="Close receipt" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:bg-slate-50 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-300">
            <X size={17} />
          </button>
        </div>

        <div className="dashboard-scrollbar flex-1 overflow-y-auto px-5 py-5 sm:px-7 sm:py-6">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
              <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Patient details</p>
              <div className="mt-3 flex items-center gap-2 text-xs font-medium text-slate-800"><span className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-[10px] font-semibold ${severityClasses(patient.severity)}`}><span className={`h-1.5 w-1.5 rounded-full ${patient.severity === 'Severe' ? 'bg-white' : patient.severity === 'Mid' ? 'bg-slate-500' : 'bg-slate-300'}`} />{patient.severity}</span><span className="text-slate-300">/</span>{patient.gender}, {patient.age}</div>
              <div className="mt-3 flex items-start gap-2 text-xs leading-5 text-slate-600"><MapPin size={14} className="mt-0.5 shrink-0 text-slate-400" /><span>{patient.address}</span></div>
            </div>
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
              <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Doctor context</p>
              <div className="mt-3 flex items-start gap-2.5">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500"><Stethoscope size={15} /></div>
                <div><p className="text-xs font-semibold text-slate-800">{patient.doctor}</p><p className="mt-1 text-[11px] text-slate-500">{patient.specialty}</p></div>
              </div>
              <p className="mt-3 border-t border-slate-200 pt-2.5 text-[11px] leading-5 text-slate-500">{patient.careContext}</p>
            </div>
          </div>

          <section className="mt-6">
            <div className="flex items-end justify-between gap-4">
              <div>
                <h3 className="text-sm font-semibold tracking-[-0.02em] text-slate-900">Reminder timeline</h3>
                <p className="mt-1 text-[11px] text-slate-500">Complete schedule <span className="mx-1 text-slate-300">·</span> selected date is emphasized</p>
              </div>
              <span className="hidden text-[10px] font-medium text-slate-400 sm:block">{patient.timeline.length} milestones</span>
            </div>
            <div className="mt-3 overflow-hidden rounded-lg border border-slate-200">
              {patient.timeline.map((reminder, index) => {
                const isSelectedDay = reminder.date === selectedDate
                const isPast = reminder.date < todayIso
                const Icon = reminder.channel === 'Voice Call' ? PhoneCall : MessageSquare
                return (
                  <div key={`${reminder.date}-${index}`} className={`flex items-center gap-3 border-b border-slate-100 px-3.5 py-3 last:border-b-0 sm:gap-4 sm:px-4 ${isSelectedDay ? 'bg-zinc-900 text-white' : 'bg-white text-slate-800'}`}>
                    <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border ${isSelectedDay ? 'border-white/20 bg-white/10 text-white' : 'border-slate-200 bg-slate-50 text-slate-500'}`}>
                      {isPast && !isSelectedDay ? <Check size={15} /> : <Icon size={14} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <p className={`text-xs font-semibold ${isSelectedDay ? 'text-white' : 'text-slate-800'}`}>{prettyDate(reminder.date, { weekday: 'short', month: 'short', day: 'numeric', year: undefined })}</p>
                        {isSelectedDay && <span className="rounded-full bg-white/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-white">Selected date</span>}
                      </div>
                      <p className={`mt-1 truncate text-[10px] ${isSelectedDay ? 'text-slate-300' : 'text-slate-500'}`}>{reminder.detail}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className={`inline-flex items-center gap-1.5 text-[10px] font-semibold ${isSelectedDay ? 'text-white' : 'text-slate-700'}`}><Icon size={11} />{reminder.channel}</p>
                      <p className={`mt-1 text-[9px] ${isSelectedDay ? 'text-slate-300' : 'text-slate-400'}`}>{isSelectedDay ? (selectedDate === todayIso ? 'Action due today' : 'Action due on selected date') : isPast ? 'Completed' : 'Scheduled'}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </section>

          <section className="mt-6 rounded-lg border border-slate-200 bg-slate-50/70 p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold tracking-[-0.02em] text-slate-900">Consultation result</h3>
                <p className="mt-1 text-[11px] text-slate-500">Record the outcome, patient response, or agreed next step.</p>
              </div>
              <span className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[10px] font-semibold ${onlineConsultation ? 'border-zinc-900 bg-zinc-900 text-white' : 'border-slate-200 bg-white text-slate-500'}`}>
                {onlineConsultation ? <Check size={12} /> : <CircleCheck size={12} />}
                {onlineConsultation ? 'Online consultation selected' : 'Online consultation not selected'}
              </span>
            </div>
            <label htmlFor={`consultation-result-${patient.id}`} className="mt-4 block text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">Online consultation result / outcome</label>
            <textarea
              id={`consultation-result-${patient.id}`}
              value={draftResult}
              onChange={(event) => setDraftResult(event.target.value)}
              readOnly={!canEdit}
              placeholder="Record the consultation outcome, patient response, or next steps…"
              rows={3}
              aria-label={`Online consultation result for ${patient.name}`}
              className={`mt-2 w-full resize-y rounded-lg border border-slate-200 px-3.5 py-3 text-xs leading-5 text-slate-800 outline-none transition placeholder:text-slate-400 ${canEdit ? 'bg-white focus:border-slate-400 focus:ring-2 focus:ring-slate-100' : 'cursor-default bg-slate-100'}`}
            />
          </section>

          <section className="mt-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-semibold tracking-[-0.02em] text-slate-900">Staff remarks &amp; call notes</h3>
                <p className="mt-1 text-[11px] text-slate-500">Add or revise the staff follow-up note.</p>
              </div>
            </div>
            <textarea
              value={draftNote}
              onChange={(event) => setDraftNote(event.target.value)}
              readOnly={!canEdit}
              placeholder="Add a call response, status update, or next step…"
              rows={4}
              aria-label={`Expanded staff remarks for ${patient.name}`}
              className={`mt-3 w-full resize-y rounded-lg border border-slate-200 px-3.5 py-3 text-xs leading-5 text-slate-800 outline-none transition placeholder:text-slate-400 ${canEdit ? 'bg-white focus:border-slate-400 focus:ring-2 focus:ring-slate-100' : 'cursor-default bg-slate-100'}`}
            />
            <p className="mt-2 text-[10px] text-slate-400">Table remarks save as you type. Receipt edits are saved only with the footer action.</p>
          </section>
        </div>

        <div className="flex flex-col gap-2 border-t border-slate-200 bg-slate-50/70 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
          <p className="text-[10px] text-slate-500">{isFinalized ? 'Finalized receipt · saved in this browser' : 'Save to finalize this follow-up receipt'}</p>
          <div className="flex items-center justify-end gap-2">
            {canEdit ? (
              <>
                <button type="button" onClick={onClose} className="inline-flex h-9 items-center justify-center rounded-lg border border-slate-200 bg-white px-3.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-300">Cancel</button>
                <button type="button" onClick={() => onSave(draftResult, draftNote)} className="inline-flex h-9 items-center justify-center gap-2 rounded-lg bg-zinc-900 px-4 text-xs font-semibold text-white transition hover:bg-zinc-700 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2">
                  {isFinalized ? 'Save changes' : 'Save & finalize'} <ArrowRight size={14} />
                </button>
              </>
            ) : (
              <>
                <button type="button" onClick={onClose} className="inline-flex h-9 items-center justify-center rounded-lg border border-slate-200 bg-white px-3.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-300">Close</button>
                <button type="button" onClick={onEdit} className="inline-flex h-9 items-center justify-center gap-2 rounded-lg bg-zinc-900 px-4 text-xs font-semibold text-white transition hover:bg-zinc-700 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2">
                  <Pencil size={13} /> Edit receipt
                </button>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}

export default App
