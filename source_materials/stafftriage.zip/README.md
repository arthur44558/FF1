# Staff Follow-Up Dashboard

A single-page clinical follow-up triage interface built with React, TypeScript, Tailwind CSS, Lucide icons, and Vite.

## Development

```sh
pnpm install
pnpm dev
```

The Vite development server listens on port 3000. Create a production bundle with:

```sh
pnpm build
```

The static output is written to `dist/` and can be served by a static host such as Vercel.

## Dashboard behavior

- The date selector defaults to the local current date and allows present or past dates only.
- Sample reminder schedules are calculated relative to the current date so the default dashboard demonstrates actions due today.
- Due records are matched exactly to the selected date and ordered Severe, Mid, then Low.
- The “Distance / time constraint” column contains a direct “Online consultation” checkbox for each patient log.
- Receipts capture the consultation result and staff remark; “Save & finalize” commits receipt edits and marks that date-specific follow-up complete, and a compact Edit action allows revisions. Inline table remarks continue to save as staff type.
- Finalized rows are shaded and marked Done. Checkbox selections, receipt results, completion state, and remarks save to the current browser's local storage.

## Demo-data notice

The included patient names, contact numbers, addresses, clinicians, and follow-up details are fictional demonstration content. This sample app is not connected to an EHR, does not provide clinical advice, and does not send SMS, WhatsApp, or voice calls. Remarks, results, online consultation marks, and receipt completion remain in the browser on the current device; there is no server or database persistence.
