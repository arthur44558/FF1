# TODO

- [x] Date selection and severity triage
  - Provide a minimalist date picker allowing staff to select the present or a past date; default to today's date.
  - Automatically sort all patient record logs by severity priority tier: Severe first → Mid → Low.
  - Dynamically identify and highlight patients whose scheduled notification milestone (SMS/WhatsApp or Voice Call) falls precisely on the selected date.
  - Display a clean dashboard header with the title “Staff Follow-Up Dashboard” and subtitle “Daily Priority Triage & Actionable Reminders”.

- [x] Actionable table and inline remarks
  - Display records for the selected date in a clean, border-separated data table.
  - Include Patient Name & Demographics (Name, Age, Gender); Severity Badge (Severe, Mid, Low sorted descending); Action Required Today (clear badge indicating SMS/WhatsApp or Voice Call); Contact Numbers (Personal & Shared/Additional flags); Doctor & Speciality; and a Staff Remarks Section with an inline text input field for staff to type real-time notes/status updates.
  - Use React, Tailwind CSS, and Lucide icons; follow the Swiss minimalist design with pure white cards, soft slate-50 canvas elements (#f8fafc), razor-thin border-slate-200 borders, dark slate-900 headers, and monochromatic deep charcoal (#09090b) actions, without heavy drop shadows or skeuomorphism.

- [x] Distance / time constraint and online consultation marking
  - Label the table column “Distance / time constraint” to indicate when the patient cannot attend an appointment because of distance or time.
  - Show a directly accessible “Online consultation” checkbox in each patient log so staff can mark or unmark that patient without opening a pop-up.
  - Save each patient's checkbox selection in this browser.

- [x] Receipt detail modal and synchronized notes
  - Clicking any row opens a full detailed receipt modal card.
  - Summarize patient demographics, doctor context, address, and the complete calculated reminder timeline, highlighting today's scheduled action.
  - Include an expanded Remarks/Notes text area where staff can record patient call responses or update follow-up logs; synchronize those updates with the corresponding record's inline remarks.

- [x] Consultation result, receipt finalization, and editing
  - Include the online-consultation selection status and a consultation result/outcome field in the receipt.
  - Provide a final Save & finalize action at the end of the receipt that saves the consultation result and receipt remark and marks that date-specific follow-up log done; retain the table remark's real-time saving behavior.
  - Visually darken finalized follow-up logs and show their Done state in the table.
  - Provide a compact Edit option for a finalized log so staff can change its consultation result or remark and save changes without clearing its Done state.
  - Persist consultation results and finalized status per patient and selected reminder date in browser storage.
