"""Background worker entry points."""
