# CareTrack Staff Head Dashboard — ToDo

## Date-driven activity and task audit
- [x] By default, all staff logs and task metrics open filtered to today's date.
- [x] Include a clean, prominent date picker/button at the top of the dashboard.
- [x] Changing the date lets the Staff Head inspect all past activities of staff members for that specific date, including due/pending tasks left uncompleted on that day.
- [x] Provide historical pending-task inspection that clearly exposes work that remained incomplete or overdue on the selected date.

## Staff operations overview and audit table
- [x] Display metrics dynamically filtered by the selected date: Total Active Staff, Tasks Assigned, Tasks Completed, and Uncompleted/Overdue Tasks for that period.
- [x] Render a comprehensive, interactive tabular log displaying all registered clinical and administrative staff members based on the selected date filter.
- [x] Each row includes avatar or initials, staff name, role/department, unique staff ID (e.g. STF-4410), total tasks allocated for the selected date, completed task count and percentage completion indicator, highlighted count of open/delayed/pending or uncompleted tasks, and a prominent “Report / Issue Warning” action.

## Supervisory warning workflow
- [x] Clicking “Report” on any staff row opens a clean modal workflow from the relevant audit row.
- [x] The modal allows the Staff Head to flag uncompleted tasks, select warning categories, add remarks, set resolution deadlines, validate required fields, and submit a formal supervisory warning.
- [x] Provide clear validation and success states for warning submission.

## Search, filtering, and responsive states
- [x] Provide real-time search across staff name, staff ID, and department.
- [x] Provide a quick “Staff with Pending Tasks” filter toggle that limits the audit table to staff members with pending tasks.
- [x] Provide responsive, accessible frontend interactions with clear empty, loading, validation, success, and no-results states; use Lucide icons.

## Swiss Minimalist interface
- [x] Use a clean, flat, spacious, distraction-free healthcare operations interface with no heavy shadows or skeuomorphic styling.
- [x] Strictly use the specified Swiss Minimalist visual system: soft slate-50 `#f8fafc` canvas, pure white cards, razor-thin slate-200 borders, dark slate-900 headings, monochromatic deep charcoal `#09090b` primary actions, and restrained rose `#e11d48` or amber `#d97706` alert/warning badges.
