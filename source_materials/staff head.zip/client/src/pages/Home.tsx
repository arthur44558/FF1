import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  ClipboardCheck,
  ClipboardList,
  FileWarning,
  LoaderCircle,
  Search,
  ShieldAlert,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  formatAuditDate,
  getStaffAuditForDate,
  toLocalDateString,
  type AuditTask,
  type StaffAuditRecord,
  type TaskStatus,
} from "@/data/staffAudit";

type WarningCategory =
  | "Missed clinical task"
  | "Delayed documentation"
  | "Handover gap"
  | "Protocol non-compliance"
  | "Other";

type WarningRecord = {
  id: string;
  staffName: string;
  staffId: string;
  date: string;
  category: WarningCategory;
  remarks: string;
  deadline: string;
  taskTitles: string[];
  submittedAt: string;
};

type ExpandedAudit = { staffId: string; mode: "all" | "pending" } | null;

const warningCategories: WarningCategory[] = [
  "Missed clinical task",
  "Delayed documentation",
  "Handover gap",
  "Protocol non-compliance",
  "Other",
];

const statusLabels: Record<TaskStatus, string> = {
  completed: "Completed",
  pending: "Open",
  overdue: "Overdue",
};

function readSavedWarnings(): WarningRecord[] {
  try {
    const saved = window.localStorage.getItem("caretrack.supervisory-warnings");
    if (!saved) return [];
    const parsed: unknown = JSON.parse(saved);
    return Array.isArray(parsed) ? (parsed as WarningRecord[]) : [];
  } catch {
    return [];
  }
}

function datePlusDays(date: string, days: number) {
  const result = new Date(`${date}T12:00:00`);
  result.setDate(result.getDate() + days);
  return toLocalDateString(result);
}

function completionRate(record: StaffAuditRecord) {
  return record.assignedCount === 0
    ? 0
    : Math.round((record.completedCount / record.assignedCount) * 100);
}

function TaskLog({
  staff,
  mode,
  selectedDate,
}: {
  staff: StaffAuditRecord;
  mode: "all" | "pending";
  selectedDate: string;
}) {
  const tasks = mode === "pending" ? staff.pendingTasks : staff.tasks;
  const pendingCount = staff.pendingTasks.length;

  return (
    <div className="task-log-panel">
      <div className="task-log-heading">
        <div>
          <span className="task-log-kicker">{mode === "pending" ? "Outstanding work" : "Daily task log"}</span>
          <h3>{staff.name}<span> · {formatAuditDate(selectedDate, { weekday: "short" })}</span></h3>
        </div>
        <div className="task-log-summary">
          {mode === "pending" ? (
            <><span className="status-dot status-dot--warning" />{pendingCount} {pendingCount === 1 ? "task needs" : "tasks need"} attention</>
          ) : (
            <><ClipboardList size={15} />{staff.completedCount} of {staff.assignedCount} completed</>
          )}
        </div>
      </div>
      {tasks.length === 0 ? (
        <div className="task-log-empty">
          <CheckCircle2 size={18} />
          {mode === "pending"
            ? "No incomplete tasks were recorded for this staff member on this date."
            : "No tasks were assigned to this staff member on this date."}
        </div>
      ) : (
        <ul className="task-list">
          {tasks.map((task) => <TaskListItem key={task.id} task={task} />)}
        </ul>
      )}
      <div className="task-log-footnote">Task status is shown as recorded for {formatAuditDate(selectedDate)}.</div>
    </div>
  );
}

function TaskListItem({ task }: { task: AuditTask }) {
  const Icon = task.status === "completed" ? CheckCircle2 : task.status === "overdue" ? AlertTriangle : Clock3;
  return (
    <li className="task-item">
      <span className={`task-status-icon task-status-icon--${task.status}`}><Icon size={15} strokeWidth={1.8} /></span>
      <span className="task-item-name">{task.title}<small>{task.area}</small></span>
      <span className="task-item-due">Due {task.dueAt}</span>
      <span className={`task-status-label task-status-label--${task.status}`}>{statusLabels[task.status]}</span>
    </li>
  );
}

function MetricCard({
  label,
  value,
  detail,
  icon: Icon,
  tone = "neutral",
}: {
  label: string;
  value: string;
  detail: string;
  icon: typeof Users;
  tone?: "neutral" | "warning" | "danger";
}) {
  return (
    <article className="metric-card">
      <div className="metric-topline">
        <span className="metric-label">{label}</span>
        <span className={`metric-icon metric-icon--${tone}`}><Icon size={17} strokeWidth={1.8} /></span>
      </div>
      <div className="metric-value">{value}</div>
      <div className="metric-detail">{detail}</div>
    </article>
  );
}

function StaffRow({
  staff,
  expanded,
  onExpand,
  onReport,
  selectedDate,
}: {
  staff: StaffAuditRecord;
  expanded: ExpandedAudit;
  onExpand: (staffId: string, mode: "all" | "pending") => void;
  onReport: (staff: StaffAuditRecord) => void;
  selectedDate: string;
}) {
  const isExpanded = expanded?.staffId === staff.id;
  const rate = completionRate(staff);
  return (
    <>
      <tr className={`staff-row${isExpanded ? " staff-row--expanded" : ""}`}>
        <td>
          <div className="staff-cell">
            <span className={`staff-avatar staff-avatar--${staff.avatarTone}`}>{staff.initials}</span>
            <span className="staff-identity">
              <strong>{staff.name}</strong>
              <span>{staff.role} <i aria-hidden="true">·</i> {staff.department}</span>
              <small>{staff.id}<span className="team-tag">{staff.team}</span></small>
            </span>
          </div>
        </td>
        <td>
          <div className="assigned-cell">
            <strong>{staff.assignedCount}</strong>
            {staff.assignedCount > 0 && (
              <button
                className="text-action"
                type="button"
                aria-expanded={isExpanded && expanded?.mode === "all"}
                onClick={() => onExpand(staff.id, "all")}
              >
                {isExpanded && expanded?.mode === "all" ? "Close log" : "View log"}
              </button>
            )}
          </div>
        </td>
        <td>
          <div className="completion-cell" aria-label={`${staff.completedCount} of ${staff.assignedCount} tasks completed, ${rate}%`}>
            <div className="completion-count"><strong>{staff.completedCount}</strong><span> / {staff.assignedCount}</span><b>{rate}%</b></div>
            <div className="progress-track" role="meter" aria-label="Task completion" aria-valuemin={0} aria-valuemax={100} aria-valuenow={rate}>
              <span style={{ width: `${rate}%` }} />
            </div>
          </div>
        </td>
        <td>
          {staff.pendingTasks.length === 0 ? (
            <span className="no-pending">—</span>
          ) : (
            <button
              className={`pending-count${staff.overdueCount > 0 ? " pending-count--overdue" : ""}`}
              type="button"
              aria-label={`View ${staff.pendingTasks.length} outstanding tasks for ${staff.name}`}
              aria-expanded={isExpanded && expanded?.mode === "pending"}
              onClick={() => onExpand(staff.id, "pending")}
            >
              <span>{staff.pendingTasks.length}</span><span className="pending-count-copy">{staff.overdueCount > 0 ? `${staff.overdueCount} overdue` : "open"}</span>
            </button>
          )}
        </td>
        <td>
          <button className="warning-button" type="button" onClick={() => onReport(staff)}>
            <ShieldAlert size={15} strokeWidth={1.8} />
            <span>Issue warning</span>
          </button>
        </td>
      </tr>
      {isExpanded && (
        <tr className="expanded-row">
          <td colSpan={5}>
            <TaskLog staff={staff} mode={expanded.mode} selectedDate={selectedDate} />
          </td>
        </tr>
      )}
    </>
  );
}

export default function Home() {
  const today = useMemo(() => toLocalDateString(new Date()), []);
  const [selectedDate, setSelectedDate] = useState(today);
  const [search, setSearch] = useState("");
  const [pendingOnly, setPendingOnly] = useState(false);
  const [expandedAudit, setExpandedAudit] = useState<ExpandedAudit>(null);
  const [reportStaff, setReportStaff] = useState<StaffAuditRecord | null>(null);
  const [warningCategory, setWarningCategory] = useState<WarningCategory | "">("");
  const [warningRemarks, setWarningRemarks] = useState("");
  const [resolutionDate, setResolutionDate] = useState(datePlusDays(today, 2));
  const [selectedTaskIds, setSelectedTaskIds] = useState<string[]>([]);
  const [formError, setFormError] = useState("");
  const [submittedWarning, setSubmittedWarning] = useState<WarningRecord | null>(null);
  const [warnings, setWarnings] = useState<WarningRecord[]>(readSavedWarnings);
  const [loadedAuditDate, setLoadedAuditDate] = useState(today);
  const [auditLoading, setAuditLoading] = useState(false);

  useEffect(() => {
    if (!auditLoading) return;
    const timer = window.setTimeout(() => {
      setLoadedAuditDate(selectedDate);
      setAuditLoading(false);
      setExpandedAudit(null);
    }, 120);
    return () => window.clearTimeout(timer);
  }, [auditLoading, selectedDate]);

  useEffect(() => {
    try {
      window.localStorage.setItem("caretrack.supervisory-warnings", JSON.stringify(warnings));
    } catch {
      // Keep the in-session warning receipt usable when browser storage is unavailable.
    }
  }, [warnings]);

  const audit = useMemo(() => getStaffAuditForDate(loadedAuditDate, today), [loadedAuditDate, today]);
  const metrics = useMemo(() => audit.reduce((totals, staff) => ({
    active: totals.active + 1,
    assigned: totals.assigned + staff.assignedCount,
    completed: totals.completed + staff.completedCount,
    outstanding: totals.outstanding + staff.pendingTasks.length,
    overdue: totals.overdue + staff.overdueCount,
  }), { active: 0, assigned: 0, completed: 0, outstanding: 0, overdue: 0 }), [audit]);

  const visibleStaff = useMemo(() => {
    const normalizedQuery = search.trim().toLowerCase();
    return audit.filter((staff) => {
      const matchesSearch = !normalizedQuery || [staff.name, staff.id, staff.department, staff.role, staff.team]
        .some((field) => field.toLowerCase().includes(normalizedQuery));
      return matchesSearch && (!pendingOnly || staff.pendingTasks.length > 0);
    });
  }, [audit, pendingOnly, search]);

  const currentRate = metrics.assigned === 0 ? 0 : Math.round((metrics.completed / metrics.assigned) * 100);
  const dateLabel = formatAuditDate(selectedDate, { weekday: "long" });

  function toggleExpanded(staffId: string, mode: "all" | "pending") {
    setExpandedAudit((current) => current?.staffId === staffId && current.mode === mode ? null : { staffId, mode });
  }

  function changeAuditDate(date: string) {
    if (!date || date === selectedDate) return;
    setAuditLoading(true);
    setSelectedDate(date);
    setExpandedAudit(null);
  }

  function openWarning(staff: StaffAuditRecord) {
    setReportStaff(staff);
    setWarningCategory("");
    setWarningRemarks("");
    setResolutionDate(datePlusDays(today, 2));
    setSelectedTaskIds(staff.pendingTasks.map((task) => task.id));
    setFormError("");
    setSubmittedWarning(null);
  }

  function closeWarning(open: boolean) {
    if (open) return;
    setReportStaff(null);
    setSubmittedWarning(null);
    setFormError("");
  }

  function handleWarningSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!reportStaff) return;
    if (reportStaff.pendingTasks.length === 0) {
      setFormError("There are no uncompleted tasks to flag for this staff member on the selected date.");
      return;
    }
    if (!warningCategory) {
      setFormError("Select a warning category to continue.");
      return;
    }
    if (selectedTaskIds.length === 0) {
      setFormError("Select at least one uncompleted task for this warning.");
      return;
    }
    if (warningRemarks.trim().length < 10) {
      setFormError("Add at least 10 characters of supervisory remarks.");
      return;
    }
    if (!resolutionDate || resolutionDate < today) {
      setFormError("Choose a resolution deadline that is today or later.");
      return;
    }

    const warning: WarningRecord = {
      id: `WARN-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
      staffName: reportStaff.name,
      staffId: reportStaff.id,
      date: selectedDate,
      category: warningCategory,
      remarks: warningRemarks.trim(),
      deadline: resolutionDate,
      taskTitles: reportStaff.pendingTasks.filter((task) => selectedTaskIds.includes(task.id)).map((task) => task.title),
      submittedAt: new Date().toISOString(),
    };
    setWarnings((current) => [warning, ...current]);
    setSubmittedWarning(warning);
    setFormError("");
    toast.success("Supervisory warning recorded", { description: `${warning.staffName} · ${warning.id}` });
  }

  function toggleTask(taskId: string) {
    setSelectedTaskIds((current) => current.includes(taskId)
      ? current.filter((id) => id !== taskId)
      : [...current, taskId]);
  }

  return (
    <div className="caretrack-app">
      <header className="topbar">
        <div className="topbar-inner">
          <a href="#top" className="brand" aria-label="CareTrack staff operations home">
            <span className="brand-mark"><Activity size={18} strokeWidth={2.15} /></span>
            <span className="brand-name">CareTrack</span>
          </a>
          <span className="topbar-divider" />
          <span className="topbar-section">Staff operations</span>
          <div className="topbar-spacer" />
          <span className="system-status"><span />Operational</span>
          <span className="topbar-divider topbar-divider--right" />
          <div className="profile-chip">
            <span className="profile-avatar">SL</span>
            <span className="profile-label"><strong>Susan Lee</strong><small>Staff head</small></span>
            <ChevronDown size={14} className="profile-chevron" />
          </div>
        </div>
      </header>

      <main id="top" className="dashboard-shell">
        <div className="page-intro">
          <div className="page-copy">
            <div className="breadcrumb"><span>Operations</span><span className="breadcrumb-slash">/</span><strong>Staff audit</strong></div>
            <div className="page-heading-line">
              <div>
                <h1>Staff activity</h1>
                <p>Daily workforce activity, task completion, and follow-up.</p>
              </div>
              <span className="audit-period"><CalendarDays size={14} />{selectedDate === today ? "Today" : formatAuditDate(selectedDate)}</span>
            </div>
          </div>
          <div className="date-toolbar" aria-label="Audit date controls">
            <label className="date-control">
              <CalendarDays size={17} aria-hidden="true" />
              <span className="date-control-copy"><small>Audit date</small><input type="date" aria-label="Choose staff audit date" value={selectedDate} max={today} onChange={(event) => changeAuditDate(event.target.value)} /></span>
            </label>
            <button className="today-button" type="button" onClick={() => changeAuditDate(today)}>Today</button>
          </div>
        </div>

        {auditLoading && <div className="audit-loading-state" role="status" aria-live="polite"><LoaderCircle size={15} />Loading staff activity for {dateLabel}…</div>}
        <section className="metrics-grid" aria-busy={auditLoading} aria-label={`Staff operations metrics for ${dateLabel}`}>
          <MetricCard label="Active staff" value={`${metrics.active}`} detail="Registered team members" icon={Users} />
          <MetricCard label="Tasks assigned" value={`${metrics.assigned}`} detail={`Across ${metrics.active} active staff`} icon={ClipboardList} />
          <MetricCard label="Tasks completed" value={`${metrics.completed}`} detail={`${currentRate}% of assigned work`} icon={ClipboardCheck} />
          <MetricCard label="Uncompleted / overdue" value={`${metrics.outstanding}`} detail={`${metrics.overdue} overdue · requires review`} icon={AlertCircle} tone={metrics.outstanding ? "warning" : "neutral"} />
        </section>

        <section className={`follow-up-strip${metrics.outstanding === 0 ? " follow-up-strip--clear" : ""}`} aria-live="polite">
          <span className="follow-up-icon">{metrics.outstanding === 0 ? <CheckCircle2 size={19} /> : <AlertTriangle size={18} />}</span>
          <div className="follow-up-copy">
            <strong>{metrics.outstanding === 0 ? "All assigned work is complete" : `${metrics.outstanding} task${metrics.outstanding === 1 ? "" : "s"} need${metrics.outstanding === 1 ? "s" : ""} follow-up`}</strong>
            <span>{metrics.outstanding === 0 ? `No outstanding tasks recorded for ${dateLabel}.` : `${metrics.overdue} overdue · ${metrics.outstanding - metrics.overdue} still open · recorded ${dateLabel}.`}</span>
          </div>
          <span className="follow-up-date">{selectedDate === today ? "Current shift" : "Historical audit"}</span>
        </section>

        <section className="audit-card" aria-busy={auditLoading} aria-labelledby="audit-heading">
          <div className="audit-card-header">
            <div className="audit-title-group">
              <div className="audit-title-line"><h2 id="audit-heading">Team audit</h2><span className="staff-count-badge">{visibleStaff.length} of {audit.length}</span></div>
              <p>Staff assignments and outcomes for {dateLabel}.</p>
            </div>
            <div className="audit-controls">
              <label className="search-control">
                <Search size={16} aria-hidden="true" />
                <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search staff, ID, department" aria-label="Search staff by name, staff ID, or department" />
                {search && <button type="button" className="clear-search" onClick={() => setSearch("")} aria-label="Clear search"><X size={14} /></button>}
              </label>
              <div className={`pending-filter${pendingOnly ? " pending-filter--active" : ""}`}>
                <span className="filter-label">Pending only</span>
                <Switch checked={pendingOnly} onCheckedChange={setPendingOnly} aria-label="Show staff with pending tasks only" />
              </div>
            </div>
          </div>

          <div className="table-meta">
            <span><span className="table-live-dot" />{selectedDate === today ? "Live date view" : "Historical date view"}<span className="table-meta-divider">·</span>{formatAuditDate(selectedDate)}</span>
            <span className="table-meta-note">Select a task count to inspect its date-specific log</span>
          </div>

          <div className="table-scroll">
            <table className="staff-table">
              <thead>
                <tr>
                  <th scope="col" className="staff-heading">Staff member</th>
                  <th scope="col">Tasks assigned</th>
                  <th scope="col">Tasks completed</th>
                  <th scope="col">Pending / overdue</th>
                  <th scope="col" className="action-heading">Action</th>
                </tr>
              </thead>
              <tbody>
                {visibleStaff.map((staff) => (
                  <StaffRow key={staff.id} staff={staff} expanded={expandedAudit} onExpand={toggleExpanded} onReport={openWarning} selectedDate={selectedDate} />
                ))}
              </tbody>
            </table>
            {visibleStaff.length === 0 && (
              <div className="empty-state" role="status">
                <span className="empty-icon">{pendingOnly ? <CheckCircle2 size={20} /> : <Search size={20} />}</span>
                <strong>{pendingOnly ? "No staff with pending tasks" : "No matching staff found"}</strong>
                <span>{pendingOnly ? `All recorded work is complete for ${formatAuditDate(selectedDate)}.` : "Try a different name, staff ID, or department."}</span>
                {(search || pendingOnly) && <button className="text-action" type="button" onClick={() => { setSearch(""); setPendingOnly(false); }}>Clear filters</button>}
              </div>
            )}
          </div>

          <div className="audit-card-footer">
            <span><span className="footer-info-mark">i</span>Completion reflects tasks recorded for the selected date.</span>
            <span>{visibleStaff.length} {visibleStaff.length === 1 ? "staff member" : "staff members"} shown</span>
          </div>
        </section>

        <section className="warnings-card" aria-labelledby="warnings-heading">
          <div className="warnings-heading-row">
            <div className="warnings-heading-icon"><FileWarning size={17} /></div>
            <div className="warnings-heading-copy"><h2 id="warnings-heading">Recent supervisory warnings</h2><p>Formal follow-up entries submitted from this dashboard.</p></div>
            <span className="warning-total">{warnings.length} {warnings.length === 1 ? "record" : "records"}</span>
          </div>
          {warnings.length === 0 ? (
            <div className="warnings-empty"><span>No warnings submitted in this browser session.</span><span>Warnings you submit are saved locally on this device.</span></div>
          ) : (
            <div className="warning-list">
              {warnings.slice(0, 3).map((warning) => (
                <article className="warning-list-item" key={warning.id}>
                  <span className="warning-list-mark"><ShieldAlert size={16} /></span>
                  <span className="warning-list-main"><strong>{warning.staffName}</strong><small>{warning.staffId} · {warning.category} · {warning.taskTitles.length} task{warning.taskTitles.length === 1 ? "" : "s"} flagged</small></span>
                  <span className="warning-list-deadline"><small>Resolve by</small><strong>{formatAuditDate(warning.deadline, { month: "short", day: "numeric" })}</strong></span>
                  <span className="warning-id">{warning.id}</span>
                </article>
              ))}
            </div>
          )}
        </section>

        <footer className="page-footer">
          <span>CareTrack <span>·</span> Staff operations</span>
          <span className="sample-note"><span className="sample-dot" />Sample audit data · warnings are saved locally in this browser</span>
        </footer>
      </main>

      <Dialog open={Boolean(reportStaff)} onOpenChange={closeWarning}>
        <DialogContent className="warning-dialog" showCloseButton={false}>
          {submittedWarning ? (
            <div className="warning-success-state">
              <span className="success-mark"><Check size={24} /></span>
              <p className="dialog-eyebrow">Supervisory record created</p>
              <DialogTitle className="success-title">Warning submitted</DialogTitle>
              <DialogDescription className="success-copy">A formal warning was recorded for {submittedWarning.staffName}. This browser has saved the record locally.</DialogDescription>
              <div className="success-receipt">
                <span>Reference</span><strong>{submittedWarning.id}</strong>
                <span>Audit date</span><strong>{formatAuditDate(submittedWarning.date)}</strong>
                <span>Resolution deadline</span><strong>{formatAuditDate(submittedWarning.deadline)}</strong>
              </div>
              <button className="primary-button success-done" type="button" onClick={() => closeWarning(false)}>Done</button>
            </div>
          ) : (
            <>
              <DialogHeader className="warning-dialog-header">
                <div className="dialog-icon"><ShieldAlert size={19} /></div>
                <p className="dialog-eyebrow">Staff supervision · {selectedDate === today ? "Today's audit" : "Historical audit"}</p>
                <DialogTitle className="warning-dialog-title">Report / issue warning</DialogTitle>
                <DialogDescription className="warning-dialog-copy">Document uncompleted work and set a clear resolution deadline.</DialogDescription>
              </DialogHeader>
              {reportStaff && (
                <form className="warning-form" onSubmit={handleWarningSubmit}>
                  <div className="warning-staff-summary">
                    <span className={`staff-avatar staff-avatar--${reportStaff.avatarTone}`}>{reportStaff.initials}</span>
                    <span><strong>{reportStaff.name}</strong><small>{reportStaff.id} · {reportStaff.department}</small></span>
                    <span className="warning-audit-date">{formatAuditDate(selectedDate, { month: "short", day: "numeric" })}</span>
                  </div>

                  <fieldset className="flagged-tasks-fieldset">
                    <legend>Uncompleted tasks <span>{reportStaff.pendingTasks.length} recorded</span></legend>
                    {reportStaff.pendingTasks.length === 0 ? (
                      <div className="no-flagged-tasks"><CheckCircle2 size={17} /><span>No uncompleted tasks recorded for this staff member on {formatAuditDate(selectedDate)}.</span></div>
                    ) : (
                      <div className="flagged-task-list">
                        {reportStaff.pendingTasks.map((task) => (
                          <label className={`flagged-task${selectedTaskIds.includes(task.id) ? " flagged-task--selected" : ""}`} key={task.id}>
                            <input type="checkbox" checked={selectedTaskIds.includes(task.id)} onChange={() => toggleTask(task.id)} />
                            <span className="flagged-task-title">{task.title}<small>Due {task.dueAt} · {task.area}</small></span>
                            <span className={`task-status-label task-status-label--${task.status}`}>{statusLabels[task.status]}</span>
                          </label>
                        ))}
                      </div>
                    )}
                  </fieldset>

                  <div className="form-field">
                    <label htmlFor="warning-category">Warning category <span className="required-mark">Required</span></label>
                    <select id="warning-category" value={warningCategory} onChange={(event) => setWarningCategory(event.target.value as WarningCategory | "")} required>
                      <option value="" disabled>Select a category</option>
                      {warningCategories.map((category) => <option key={category} value={category}>{category}</option>)}
                    </select>
                  </div>
                  <div className="form-field">
                    <label htmlFor="warning-remarks">Supervisory remarks <span className="required-mark">Required</span></label>
                    <textarea id="warning-remarks" value={warningRemarks} onChange={(event) => setWarningRemarks(event.target.value)} placeholder="Describe the concern and expected next step…" rows={3} minLength={10} maxLength={500} required />
                    <span className="field-hint">At least 10 characters · {warningRemarks.length}/500</span>
                  </div>
                  <div className="form-field deadline-field">
                    <label htmlFor="resolution-date">Resolution deadline <span className="required-mark">Required</span></label>
                    <div className="deadline-control"><CalendarDays size={16} /><input id="resolution-date" type="date" value={resolutionDate} min={today} onChange={(event) => setResolutionDate(event.target.value)} required /></div>
                  </div>
                  {formError && <p className="form-error" role="alert"><AlertCircle size={15} />{formError}</p>}
                  <div className="warning-modal-footer">
                    <span className="form-assurance"><AlertCircle size={14} />Review before submitting</span>
                    <button className="secondary-button" type="button" onClick={() => closeWarning(false)}>Cancel</button>
                    <button className="primary-button" type="submit" disabled={reportStaff.pendingTasks.length === 0}><ShieldAlert size={15} />Submit warning</button>
                  </div>
                  <p className="local-save-note">This demo stores supervisory records in this browser only.</p>
                </form>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
