export type TaskStatus = "completed" | "pending" | "overdue";

export type AuditTask = {
  id: string;
  title: string;
  dueAt: string;
  status: TaskStatus;
  area: string;
};

export type StaffProfile = {
  id: string;
  name: string;
  initials: string;
  role: string;
  department: string;
  team: "Clinical" | "Administration";
  avatarTone: "sage" | "blue" | "sand" | "rose" | "lavender";
  taskTitles: string[];
  todayStatuses: TaskStatus[];
  active: boolean;
};

export type StaffAuditRecord = StaffProfile & {
  tasks: AuditTask[];
  assignedCount: number;
  completedCount: number;
  pendingTasks: AuditTask[];
  overdueCount: number;
};

const profiles: StaffProfile[] = [
  {
    id: "STF-4410",
    name: "Maya Chen",
    initials: "MC",
    role: "Registered nurse",
    department: "Emergency",
    team: "Clinical",
    avatarTone: "sage",
    taskTitles: [
      "Complete patient observations",
      "Review medication chart",
      "Update bedside care plan",
      "Document shift handover",
      "Confirm allergy status",
      "Recheck post-treatment vitals",
      "Sign controlled-drug register",
    ],
    todayStatuses: ["completed", "completed", "completed", "completed", "completed", "pending", "overdue"],
    active: true,
  },
  {
    id: "STF-4412",
    name: "Priya Nair",
    initials: "PN",
    role: "Senior nurse",
    department: "Intensive care",
    team: "Clinical",
    avatarTone: "lavender",
    taskTitles: [
      "Review ventilator observations",
      "Complete central-line checklist",
      "Record fluid balance",
      "Verify medication administration",
      "Update family communication note",
      "Complete bedside safety check",
    ],
    todayStatuses: ["completed", "completed", "completed", "completed", "pending", "overdue"],
    active: true,
  },
  {
    id: "STF-4421",
    name: "Lucas Bennett",
    initials: "LB",
    role: "Attending physician",
    department: "Internal medicine",
    team: "Clinical",
    avatarTone: "blue",
    taskTitles: [
      "Review morning round list",
      "Sign discharge summary",
      "Approve diagnostic orders",
      "Complete patient assessment",
      "Update care-team notes",
    ],
    todayStatuses: ["completed", "completed", "completed", "completed", "completed"],
    active: true,
  },
  {
    id: "STF-4430",
    name: "Amara Okafor",
    initials: "AO",
    role: "Care coordinator",
    department: "Cardiology",
    team: "Clinical",
    avatarTone: "rose",
    taskTitles: [
      "Confirm follow-up appointment",
      "Coordinate discharge transport",
      "Review referral documentation",
      "Update care pathway",
      "Contact family representative",
      "Submit post-discharge plan",
    ],
    todayStatuses: ["completed", "completed", "completed", "pending", "pending", "overdue"],
    active: true,
  },
  {
    id: "STF-4434",
    name: "Elena Petrova",
    initials: "EP",
    role: "Lab technologist",
    department: "Diagnostics",
    team: "Clinical",
    avatarTone: "sand",
    taskTitles: [
      "Verify specimen intake",
      "Run chemistry panel",
      "Validate CBC results",
      "Document quality control",
      "Release pending result",
    ],
    todayStatuses: ["completed", "completed", "completed", "completed", "pending"],
    active: true,
  },
  {
    id: "STF-4446",
    name: "Noah Williams",
    initials: "NW",
    role: "Admissions coordinator",
    department: "Patient access",
    team: "Administration",
    avatarTone: "blue",
    taskTitles: [
      "Reconcile admissions list",
      "Verify patient demographics",
      "Process referral documents",
      "Confirm insurance details",
      "Close completed registrations",
    ],
    todayStatuses: ["completed", "completed", "completed", "completed", "completed"],
    active: true,
  },
  {
    id: "STF-4453",
    name: "Sofia Martinez",
    initials: "SM",
    role: "Clinical pharmacist",
    department: "Pharmacy",
    team: "Clinical",
    avatarTone: "sage",
    taskTitles: [
      "Review high-risk prescriptions",
      "Complete medication reconciliation",
      "Verify discharge medication list",
      "Document clinical intervention",
      "Confirm cold-chain log",
      "Review formulary exception",
    ],
    todayStatuses: ["completed", "completed", "completed", "pending", "pending", "overdue"],
    active: true,
  },
  {
    id: "STF-4461",
    name: "Ethan Park",
    initials: "EP",
    role: "Medical assistant",
    department: "Outpatient care",
    team: "Clinical",
    avatarTone: "lavender",
    taskTitles: [
      "Prepare exam room",
      "Record intake measurements",
      "Upload visit documentation",
      "Restock clinical supplies",
    ],
    todayStatuses: ["completed", "completed", "completed", "pending"],
    active: true,
  },
  {
    id: "STF-4468",
    name: "Leila Haddad",
    initials: "LH",
    role: "Clinical supervisor",
    department: "Nursing services",
    team: "Clinical",
    avatarTone: "rose",
    taskTitles: [
      "Review staffing allocation",
      "Complete safety walk-through",
      "Approve incident follow-up",
      "Sign unit handover record",
    ],
    todayStatuses: ["completed", "completed", "completed", "completed"],
    active: true,
  },
  {
    id: "STF-4472",
    name: "Omar Farouk",
    initials: "OF",
    role: "Radiology technologist",
    department: "Imaging",
    team: "Clinical",
    avatarTone: "sand",
    taskTitles: [
      "Complete equipment safety check",
      "Verify imaging consent",
      "Upload study notes",
      "Review contrast documentation",
      "Close imaging worklist",
    ],
    todayStatuses: ["completed", "completed", "completed", "pending", "overdue"],
    active: true,
  },
];

const dueTimes = ["08:30", "09:15", "10:00", "11:30", "13:00", "14:15", "16:00"];

function hashValue(value: string) {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) {
    hash = (hash * 31 + value.charCodeAt(index)) | 0;
  }
  return Math.abs(hash);
}

function isFutureDate(date: string, today: string) {
  return date > today;
}

/** Returns a stable local calendar date without UTC timezone shifts. */
export function toLocalDateString(date: Date) {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function formatAuditDate(date: string, options?: Intl.DateTimeFormatOptions) {
  const parsed = new Date(`${date}T12:00:00`);
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    ...options,
  }).format(parsed);
}

function historicalStatuses(profile: StaffProfile, date: string): TaskStatus[] {
  const seed = hashValue(`${date}-${profile.id}`);
  const assigned = 3 + (seed % 4);
  const fullyComplete = seed % 5 === 0;
  const completed = fullyComplete
    ? assigned
    : Math.max(1, Math.min(assigned - 1, Math.floor(assigned * (0.54 + ((seed >> 3) % 4) * 0.1))));

  return Array.from({ length: assigned }, (_, index) => {
    if (index < completed) return "completed";
    return (seed + index * 17) % 3 === 0 ? "overdue" : "pending";
  });
}

function makeTasks(profile: StaffProfile, date: string, today: string): AuditTask[] {
  if (isFutureDate(date, today)) return [];

  const statuses = date === today ? profile.todayStatuses : historicalStatuses(profile, date);
  return statuses.map((status, index) => ({
    id: `${profile.id}-${date}-${index + 1}`,
    title: profile.taskTitles[index % profile.taskTitles.length],
    dueAt: dueTimes[index % dueTimes.length],
    status,
    area: profile.department,
  }));
}

/**
 * Build a deterministic day-specific audit view. Past dates use stable synthetic audit records
 * so the frontend can demonstrate historical review without implying a live hospital data feed.
 */
export function getStaffAuditForDate(date: string, today = toLocalDateString(new Date())): StaffAuditRecord[] {
  return profiles
    .filter((profile) => profile.active)
    .map((profile) => {
      const tasks = makeTasks(profile, date, today);
      const pendingTasks = tasks.filter((task) => task.status !== "completed");
      return {
        ...profile,
        tasks,
        assignedCount: tasks.length,
        completedCount: tasks.filter((task) => task.status === "completed").length,
        pendingTasks,
        overdueCount: tasks.filter((task) => task.status === "overdue").length,
      };
    });
}
