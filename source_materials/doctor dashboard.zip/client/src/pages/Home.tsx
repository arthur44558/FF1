import { useMemo, useState, type FormEvent } from "react";
import {
  Activity,
  ArrowDownToLine,
  Bell,
  CalendarCheck2,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock3,
  FileText,
  HeartPulse,
  LayoutDashboard,
  ListFilter,
  MapPin,
  Menu,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  UserRound,
  UsersRound,
  Video,
  X,
} from "lucide-react";
import { toast } from "sonner";
import PatientReceiptModal from "@/features/caretrack/PatientReceiptModal";
import { useDialogFocus } from "@/features/caretrack/useDialogFocus";
import {
  createSeedPatients,
  formatActivityTimestamp,
  formatDate,
  formatLongDate,
  formatTime,
  todayKey,
  type AppointmentMode,
  type AuthorizationDecision,
  type PatientLog,
  type Severity,
} from "@/features/caretrack/patientData";

const DOCTOR_NAME = "Dr. Maya Patel";
const MODE_FILTERS: Array<{ value: "all" | AppointmentMode; label: string }> = [
  { value: "all", label: "All appointments" },
  { value: "Online Consultancy", label: "Online" },
  { value: "In-person", label: "In-person" },
];

type Section = "overview" | "logs" | "calendar" | "approvals";
type DecisionTarget = { patientId: string } | null;

function dateDistance(dateKey: string): number {
  const [year, month, day] = dateKey.split("-").map(Number);
  const target = new Date(year, month - 1, day, 12).getTime();
  const now = new Date();
  const today = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    12
  ).getTime();
  return Math.round((target - today) / 86_400_000);
}

function relativeDay(dateKey: string): string {
  const distance = dateDistance(dateKey);
  if (distance === 0) return "Today";
  if (distance === 1) return "Tomorrow";
  if (distance === -1) return "Yesterday";
  return formatDate(dateKey, {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

function greeting(): string {
  const hour = new Date().getHours();
  return hour < 12
    ? "Good morning"
    : hour < 17
      ? "Good afternoon"
      : "Good evening";
}

function severityStyle(severity: PatientLog["severity"]): string {
  if (severity === "High") return "bg-rose-50 text-rose-700 ring-rose-100";
  if (severity === "Moderate")
    return "bg-amber-50 text-amber-700 ring-amber-100";
  return "bg-emerald-50 text-emerald-700 ring-emerald-100";
}

function getRequestLabel(patient: PatientLog): string {
  const request = patient.changeRequest;
  if (!request) return "Scheduled";
  if (request.status === "pending") return "Pending approval";
  if (request.status === "approved") return "Approved by doctor";
  if (request.status === "revised") return "Revised by doctor";
  return "Change rejected";
}

function downloadCsv(patients: PatientLog[]) {
  const columns = [
    "Patient ID",
    "Patient",
    "Age",
    "Gender",
    "Severity",
    "Appointment date",
    "Appointment time",
    "Mode",
    "Phone",
    "Email",
    "Assistant notes",
    "Change status",
  ];
  const escape = (value: string | number) =>
    `"${String(value).replaceAll('"', '""')}"`;
  const rows = patients.map(patient =>
    [
      patient.id,
      patient.name,
      patient.age,
      patient.gender,
      patient.severity,
      patient.appointmentDate,
      patient.appointmentTime,
      patient.mode,
      patient.phone,
      patient.email,
      patient.notes,
      getRequestLabel(patient),
    ]
      .map(escape)
      .join(",")
  );
  const csv = [columns.map(escape).join(","), ...rows].join("\r\n");
  const url = URL.createObjectURL(
    new Blob([csv], { type: "text/csv;charset=utf-8" })
  );
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `caretrack-patient-logs-${todayKey()}.csv`;
  anchor.click();
  URL.revokeObjectURL(url);
}

function SmallMark({ inverse = false }: { inverse?: boolean }) {
  return (
    <span
      className={`flex h-8 w-8 items-center justify-center rounded-lg ${inverse ? "bg-white text-slate-900" : "bg-[#09090b] text-white"}`}
    >
      <Activity size={17} strokeWidth={2.2} />
    </span>
  );
}

function Sidebar({
  active,
  onNavigate,
  mobileOpen,
  onClose,
  pendingCount,
}: {
  active: Section;
  onNavigate: (section: Section) => void;
  mobileOpen: boolean;
  onClose: () => void;
  pendingCount: number;
}) {
  const links: Array<{
    id: Section;
    label: string;
    icon: typeof LayoutDashboard;
  }> = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "logs", label: "Patient logs", icon: FileText },
    { id: "calendar", label: "Calendar", icon: CalendarDays },
    { id: "approvals", label: "Approvals", icon: ShieldCheck },
  ];
  return (
    <>
      {mobileOpen && (
        <button
          aria-label="Close navigation"
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/25 lg:hidden"
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-[248px] flex-col border-r border-slate-200 bg-white transition-transform duration-200 lg:translate-x-0 ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="flex h-[72px] items-center justify-between border-b border-slate-200 px-5">
          <button
            onClick={() => {
              onNavigate("overview");
              onClose();
            }}
            className="flex items-center gap-3 text-left"
            aria-label="CareTrack overview"
          >
            <SmallMark />
            <span>
              <span className="block text-[15px] font-semibold tracking-tight text-slate-900">
                CareTrack
              </span>
              <span className="block text-[10px] font-medium uppercase tracking-[0.14em] text-slate-400">
                Clinical workspace
              </span>
            </span>
          </button>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 lg:hidden"
            aria-label="Close menu"
          >
            <X size={17} />
          </button>
        </div>
        <div className="px-4 pt-6">
          <p className="px-2 pb-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-400">
            Workspace
          </p>
          <nav aria-label="Main navigation" className="space-y-1">
            {links.map(link => {
              const Icon = link.icon;
              const selected = active === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => {
                    onNavigate(link.id);
                    onClose();
                  }}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[13px] transition ${selected ? "bg-slate-100 font-semibold text-slate-900" : "font-medium text-slate-500 hover:bg-slate-50 hover:text-slate-800"}`}
                  aria-current={selected ? "page" : undefined}
                >
                  <Icon size={17} strokeWidth={selected ? 2.15 : 1.8} />
                  <span className="flex-1">{link.label}</span>
                  {link.id === "approvals" && pendingCount > 0 && (
                    <span
                      className={`rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${selected ? "bg-white text-slate-700" : "bg-slate-100 text-slate-600"}`}
                    >
                      {pendingCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto border-t border-slate-200 p-4">
          <div className="mb-3 rounded-xl border border-slate-200 bg-slate-50/70 p-3">
            <div className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-[11px] font-semibold text-slate-700">
                MP
              </span>
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold text-slate-800">
                  {DOCTOR_NAME}
                </p>
                <p className="mt-0.5 truncate text-[10px] text-slate-500">
                  Internal Medicine
                </p>
              </div>
              <ChevronDown size={14} className="ml-auto text-slate-400" />
            </div>
          </div>
          <div className="flex items-center justify-between px-1 text-[10px] text-slate-400">
            <span>CareTrack v1.0</span>
            <span className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
              Demo mode
            </span>
          </div>
        </div>
      </aside>
    </>
  );
}

function Topbar({
  onMenu,
  patientCount,
  pendingCount,
  onApprovals,
}: {
  onMenu: () => void;
  patientCount: number;
  pendingCount: number;
  onApprovals: () => void;
}) {
  return (
    <header className="sticky top-0 z-30 flex h-[68px] items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur sm:px-6 lg:px-8">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenu}
          className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 lg:hidden"
          aria-label="Open navigation"
        >
          <Menu size={17} />
        </button>
        <div className="hidden items-center gap-2 text-xs text-slate-400 sm:flex">
          <span>CareTrack</span>
          <ChevronRight size={13} />
          <span className="font-medium text-slate-700">Doctor workspace</span>
        </div>
        <div className="sm:hidden">
          <p className="text-sm font-semibold text-slate-900">CareTrack</p>
        </div>
      </div>
      <div className="flex items-center gap-3 sm:gap-5">
        <div className="hidden items-center gap-2 text-xs text-slate-500 md:flex">
          <UsersRound size={15} className="text-slate-400" />
          <span>{patientCount} active patient records</span>
        </div>
        <button
          onClick={onApprovals}
          className="relative rounded-lg p-2 text-slate-500 transition hover:bg-slate-100"
          aria-label={`Open approvals${pendingCount ? `, ${pendingCount} pending changes` : ""}`}
        >
          <Bell size={17} />
          {pendingCount > 0 && (
            <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-slate-900 ring-2 ring-white" />
          )}
        </button>
        <span className="hidden h-7 w-px bg-slate-200 sm:block" />
        <div className="flex items-center gap-2.5 rounded-lg text-left">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-[11px] font-semibold text-slate-700">
            MP
          </span>
          <span className="hidden text-xs font-medium text-slate-700 sm:block">
            Maya Patel
          </span>
          <ChevronDown size={14} className="hidden text-slate-400 sm:block" />
        </div>
      </div>
    </header>
  );
}

function StatCard({
  label,
  value,
  detail,
  icon: Icon,
  active,
  onClick,
}: {
  label: string;
  value: string | number;
  detail: string;
  icon: typeof CalendarCheck2;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`group rounded-xl border bg-white p-4 text-left transition hover:border-slate-300 hover:bg-slate-50/30 sm:p-5 ${active ? "border-slate-900" : "border-slate-200"}`}
    >
      <div className="flex items-start justify-between gap-3">
        <span className="text-xs font-medium text-slate-500">{label}</span>
        <span
          className={`flex h-8 w-8 items-center justify-center rounded-lg ${active ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-500 group-hover:bg-slate-200"}`}
        >
          <Icon size={16} />
        </span>
      </div>
      <p className="mt-3 text-[26px] font-semibold leading-none tracking-tight text-slate-900">
        {value}
      </p>
      <p className="mt-2 text-[11px] leading-4 text-slate-400">{detail}</p>
    </button>
  );
}

function SectionHeading({
  active,
  filteredCount,
  onExport,
}: {
  active: Section;
  filteredCount: number;
  onExport: () => void;
}) {
  const titles: Record<Section, { title: string; sub: string }> = {
    overview: {
      title: "Patient logs",
      sub: "Review your assigned patients and today’s care schedule.",
    },
    logs: {
      title: "Patient logs",
      sub: "All assigned patient records in one place.",
    },
    calendar: {
      title: "Official calendar",
      sub: "Your confirmed appointment schedule, including approved changes.",
    },
    approvals: {
      title: "Approval queue",
      sub: "Assistant-proposed schedule changes awaiting your review.",
    },
  };
  return (
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        <div className="mb-2 flex items-center gap-2 text-[11px] font-medium text-slate-400">
          <span>Care operations</span>
          <ChevronRight size={12} />
          <span className="text-slate-600">
            {active === "overview" ? "Doctor overview" : titles[active].title}
          </span>
        </div>
        <h2 className="text-xl font-semibold tracking-tight text-slate-900 sm:text-[22px]">
          {titles[active].title}
        </h2>
        <p className="mt-1 text-xs text-slate-500">{titles[active].sub}</p>
      </div>
      <div className="flex items-center gap-2">
        <span className="mr-1 text-[11px] text-slate-400">
          {filteredCount} {filteredCount === 1 ? "record" : "records"}
        </span>
        <button
          onClick={onExport}
          className="inline-flex h-9 items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 transition hover:bg-slate-50"
        >
          <ArrowDownToLine size={14} />
          Export CSV
        </button>
      </div>
    </div>
  );
}

function FilterBar({
  search,
  onSearch,
  dateFilter,
  onDateChange,
  modeFilter,
  onModeChange,
  statusFilter,
  onStatusChange,
  severityFilter,
  onSeverityChange,
  onReset,
}: {
  search: string;
  onSearch: (value: string) => void;
  dateFilter: string;
  onDateChange: (value: string) => void;
  modeFilter: "all" | AppointmentMode;
  onModeChange: (value: "all" | AppointmentMode) => void;
  statusFilter: "all" | "pending" | "reviewed";
  onStatusChange: (value: "all" | "pending" | "reviewed") => void;
  severityFilter: "all" | Severity;
  onSeverityChange: (value: "all" | Severity) => void;
  onReset: () => void;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3.5 sm:p-4">
      <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
        <div className="relative w-full xl:max-w-[300px]">
          <Search
            size={15}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            value={search}
            onChange={event => onSearch(event.target.value)}
            type="search"
            placeholder="Search patients, notes…"
            className="h-9 w-full rounded-lg border border-slate-200 bg-white pl-9 pr-3 text-xs text-slate-800 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-100"
            aria-label="Search patient logs"
          />
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between xl:justify-end">
          <label className="flex h-9 items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 text-xs text-slate-600">
            <CalendarDays size={14} className="text-slate-400" />
            <span className="hidden text-slate-400 sm:inline">Date</span>
            <input
              type="date"
              value={dateFilter}
              onChange={event => onDateChange(event.target.value)}
              className="min-w-0 border-0 bg-transparent p-0 text-xs text-slate-700 outline-none"
              aria-label="Filter by appointment date"
            />
          </label>
          <div
            className="flex items-center gap-1 rounded-lg bg-slate-100 p-1"
            role="group"
            aria-label="Filter by appointment mode"
          >
            {MODE_FILTERS.map(filter => (
              <button
                key={filter.value}
                onClick={() => onModeChange(filter.value)}
                className={`whitespace-nowrap rounded-md px-2.5 py-1.5 text-[11px] font-medium transition ${modeFilter === filter.value ? "bg-white text-slate-900 ring-1 ring-slate-200" : "text-slate-500 hover:text-slate-800"}`}
              >
                {filter.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <label className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 text-[11px] text-slate-500">
              <SlidersHorizontal size={13} />
              <select
                value={severityFilter}
                onChange={event =>
                  onSeverityChange(event.target.value as "all" | Severity)
                }
                className="max-w-[105px] bg-transparent text-xs font-medium text-slate-700 outline-none"
                aria-label="Filter by severity"
              >
                <option value="all">All severity</option>
                <option value="High">High</option>
                <option value="Moderate">Moderate</option>
                <option value="Low">Low</option>
              </select>
            </label>
            <label className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 text-[11px] text-slate-500">
              <SlidersHorizontal size={13} />
              <select
                value={statusFilter}
                onChange={event =>
                  onStatusChange(
                    event.target.value as "all" | "pending" | "reviewed"
                  )
                }
                className="max-w-[116px] bg-transparent text-xs font-medium text-slate-700 outline-none"
                aria-label="Filter by approval status"
              >
                <option value="all">All statuses</option>
                <option value="pending">Pending review</option>
                <option value="reviewed">Reviewed changes</option>
              </select>
            </label>
            <button
              onClick={onReset}
              className="h-9 rounded-lg px-2.5 text-[11px] font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PatientRow({
  patient,
  onOpen,
  onApprove,
  onReject,
}: {
  patient: PatientLog;
  onOpen: () => void;
  onApprove: () => void;
  onReject: () => void;
}) {
  const pending = patient.changeRequest?.status === "pending";
  const modeIcon = patient.mode === "Online Consultancy" ? Video : MapPin;
  const ModeIcon = modeIcon;
  const request = patient.changeRequest;

  return (
    <div
      role="group"
      aria-label={`Patient record for ${patient.name}. Press Enter or Space to open receipt.`}
      tabIndex={0}
      onClick={onOpen}
      onKeyDown={event => {
        if (event.target !== event.currentTarget) return;
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onOpen();
        }
      }}
      className="patient-row cursor-pointer border-b border-slate-100 px-4 py-3.5 transition last:border-b-0 hover:bg-slate-50/80 focus:bg-slate-50/80 focus:outline-none sm:px-5"
    >
      <div className="patient-grid min-w-[1080px] items-center gap-x-4">
        <div className="flex min-w-0 items-center gap-3">
          <span
            className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold ${patient.severity === "High" ? "bg-rose-50 text-rose-700" : patient.severity === "Moderate" ? "bg-amber-50 text-amber-700" : "bg-slate-100 text-slate-600"}`}
          >
            {patient.initials}
          </span>
          <div className="min-w-0">
            <button
              onClick={event => {
                event.stopPropagation();
                onOpen();
              }}
              data-open-patient={patient.id}
              className="block max-w-full truncate text-left text-xs font-semibold text-slate-800 hover:text-slate-950 focus-visible:underline"
            >
              {patient.name}
            </button>
            <p className="mt-1 truncate text-[10px] text-slate-400">
              {patient.id} · {patient.age} yrs · {patient.gender}
            </p>
          </div>
        </div>
        <div className="min-w-0">
          <span
            className={`inline-flex max-w-full items-center gap-1.5 rounded-md border px-2 py-1 text-[10px] font-medium ${patient.mode === "Online Consultancy" ? "border-slate-200 bg-white text-slate-700" : "border-slate-100 bg-slate-50 text-slate-600"}`}
          >
            <ModeIcon size={12} className="shrink-0 text-slate-400" />
            <span className="truncate">{patient.mode}</span>
          </span>
          <p className="mt-1.5 truncate text-[10px] text-slate-400">
            {patient.diagnosis}
          </p>
        </div>
        <div>
          <p className="text-xs font-medium text-slate-800">
            {relativeDay(patient.appointmentDate)}
          </p>
          <p className="mt-1 text-[10px] text-slate-500">
            {formatDate(patient.appointmentDate, {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}{" "}
            · {formatTime(patient.appointmentTime)}
          </p>
        </div>
        <div>
          <span
            className={`inline-flex items-center gap-1.5 rounded-full px-2 py-1 text-[10px] font-medium ring-1 ring-inset ${severityStyle(patient.severity)}`}
          >
            <span className="h-1.5 w-1.5 rounded-full bg-current" />
            {patient.severity}
          </span>
        </div>
        <div className="min-w-0">
          <p className="truncate text-[11px] font-medium text-slate-700">
            {patient.phone}
          </p>
          <p className="mt-1 truncate text-[10px] text-slate-400">
            {patient.email}
          </p>
        </div>
        <div className="min-w-0">
          <p
            className="line-clamp-2 text-[10px] leading-[1.45] text-slate-500"
            title={patient.notes}
          >
            {patient.notes}
          </p>
          <p className="mt-1 truncate text-[9px] text-slate-400">
            Assistant · {patient.assistantName}
          </p>
        </div>
        <div className="min-w-0">
          {pending && request ? (
            <>
              <div className="flex items-center gap-1.5">
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-slate-900 text-white">
                  <Clock3 size={10} />
                </span>
                <span className="text-[10px] font-semibold text-slate-800">
                  Pending approval
                </span>
              </div>
              <p
                className="mt-1 truncate text-[10px] text-slate-500"
                title={request.assistantNote}
              >
                Date changed by assistant ·{" "}
                {formatDate(request.requestedDate, {
                  month: "short",
                  day: "numeric",
                })}{" "}
                at {formatTime(request.requestedTime)}
              </p>
              <div className="mt-2 flex items-center gap-1.5">
                <button
                  onClick={event => {
                    event.stopPropagation();
                    onApprove();
                  }}
                  className="inline-flex h-7 items-center gap-1 rounded-md bg-[#09090b] px-2.5 text-[10px] font-medium text-white transition hover:bg-slate-700"
                >
                  <Check size={12} />
                  Approve
                </button>
                <button
                  onClick={event => {
                    event.stopPropagation();
                    onReject();
                  }}
                  className="inline-flex h-7 items-center gap-1 rounded-md border border-slate-200 bg-white px-2 text-[10px] font-medium text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  <FileText size={11} />
                  Reject / Revise
                </button>
              </div>
            </>
          ) : (
            <>
              <span
                className={`inline-flex items-center gap-1.5 text-[10px] font-medium ${request?.status === "approved" || request?.status === "revised" ? "text-slate-700" : request?.status === "rejected" ? "text-slate-500" : "text-slate-600"}`}
              >
                <CheckCircle2
                  size={13}
                  className={
                    request?.status === "approved" ||
                    request?.status === "revised"
                      ? "text-emerald-600"
                      : "text-slate-400"
                  }
                />
                {getRequestLabel(patient)}
              </span>
              <p className="mt-1 truncate text-[10px] text-slate-400">
                {request?.decision
                  ? `${request.decision.by} · ${request.decision.at}`
                  : patient.location}
              </p>
              {request?.decision && (
                <p
                  className="mt-1 truncate text-[9px] text-slate-400"
                  title={request.decision.note}
                >
                  Sign-off: {request.decision.note}
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function PatientTable({
  patients,
  onOpen,
  onApprove,
  onReject,
  active,
}: {
  patients: PatientLog[];
  onOpen: (id: string) => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  active: Section;
}) {
  const title =
    active === "approvals"
      ? "Assistant change requests"
      : "Assigned patient records";
  return (
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <div className="flex flex-col gap-1 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
        <div>
          <div className="flex items-center gap-2">
            <h3
              tabIndex={-1}
              data-dialog-return-focus
              className="text-sm font-semibold text-slate-900"
            >
              {title}
            </h3>
            {active === "approvals" && (
              <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                {patients.length} pending
              </span>
            )}
          </div>
          <p className="mt-1 text-[11px] text-slate-400">
            Select a patient row to open their full consultation receipt.
          </p>
        </div>
        <div className="mt-1 flex items-center gap-1.5 text-[10px] text-slate-400 sm:mt-0">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          Schedule synced
        </div>
      </div>
      <div className="overflow-x-auto">
        <div className="patient-grid min-w-[1080px] gap-x-4 border-b border-slate-200 bg-slate-50/80 px-4 py-2.5 text-[9px] font-semibold uppercase tracking-[0.09em] text-slate-400 sm:px-5">
          <span>Patient</span>
          <span>Appointment</span>
          <span>Schedule</span>
          <span>Severity</span>
          <span>Contact</span>
          <span>Assistant notes</span>
          <span>Authorization</span>
        </div>
        {patients.length > 0 ? (
          patients.map(patient => (
            <PatientRow
              key={patient.id}
              patient={patient}
              onOpen={() => onOpen(patient.id)}
              onApprove={() => onApprove(patient.id)}
              onReject={() => onReject(patient.id)}
            />
          ))
        ) : (
          <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-slate-100 text-slate-400">
              <ListFilter size={18} />
            </span>
            <p className="mt-3 text-sm font-semibold text-slate-800">
              No patient logs found
            </p>
            <p className="mt-1 max-w-[300px] text-xs leading-5 text-slate-500">
              Try adjusting your filters or search terms to find the patient
              record you’re looking for.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

function CalendarView({
  patients,
  onOpen,
}: {
  patients: PatientLog[];
  onOpen: (id: string) => void;
}) {
  const sorted = [...patients].sort((a, b) =>
    `${a.appointmentDate} ${a.appointmentTime}`.localeCompare(
      `${b.appointmentDate} ${b.appointmentTime}`
    )
  );
  const grouped = sorted.reduce<Record<string, PatientLog[]>>(
    (groups, patient) => {
      groups[patient.appointmentDate] = [
        ...(groups[patient.appointmentDate] ?? []),
        patient,
      ];
      return groups;
    },
    {}
  );
  const dates = Object.keys(grouped);
  return (
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Schedule overview
          </h3>
          <p className="mt-1 text-[11px] text-slate-400">
            Approved changes are reflected here as the official schedule.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-md bg-slate-100 px-2.5 py-1.5 text-[10px] font-medium text-slate-600">
          <CalendarCheck2 size={13} />
          Live schedule
        </span>
      </div>
      {dates.length ? (
        <div className="divide-y divide-slate-100">
          {dates.map(date => (
            <div
              key={date}
              className="grid gap-3 px-5 py-4 sm:grid-cols-[150px_1fr] sm:gap-6"
            >
              <div>
                <p className="text-xs font-semibold text-slate-800">
                  {relativeDay(date)}
                </p>
                <p className="mt-1 text-[10px] text-slate-400">
                  {formatLongDate(date)}
                </p>
              </div>
              <div className="space-y-2">
                {grouped[date].map(patient => (
                  <button
                    key={patient.id}
                    onClick={() => onOpen(patient.id)}
                    className="flex w-full items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 text-left transition hover:border-slate-300 hover:bg-slate-50"
                  >
                    <span className="w-[58px] shrink-0 text-xs font-semibold text-slate-700">
                      {formatTime(patient.appointmentTime)}
                    </span>
                    <span className="h-8 w-px bg-slate-200" />
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-[10px] font-semibold text-slate-600">
                      {patient.initials}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-semibold text-slate-800">
                        {patient.name}
                      </span>
                      <span className="mt-0.5 block truncate text-[10px] text-slate-500">
                        {patient.diagnosis} · {patient.duration}
                      </span>
                    </span>
                    <span className="hidden items-center gap-1.5 text-[10px] text-slate-500 md:flex">
                      {patient.mode === "Online Consultancy" ? (
                        <Video size={13} />
                      ) : (
                        <MapPin size={13} />
                      )}{" "}
                      {patient.mode}
                    </span>
                    {patient.changeRequest?.status === "pending" ? (
                      <span className="rounded-md bg-slate-100 px-2 py-1 text-[9px] font-medium text-slate-600">
                        Pending
                      </span>
                    ) : patient.changeRequest?.status === "approved" ||
                      patient.changeRequest?.status === "revised" ? (
                      <span className="rounded-md bg-emerald-50 px-2 py-1 text-[9px] font-medium text-emerald-700">
                        Authorized
                      </span>
                    ) : null}
                    <ChevronRight size={15} className="text-slate-300" />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="px-6 py-14 text-center">
          <p className="text-sm font-semibold text-slate-800">
            No scheduled appointments
          </p>
          <p className="mt-1 text-xs text-slate-500">
            The current filter has no appointments to display.
          </p>
        </div>
      )}
    </section>
  );
}

function DecisionModal({
  patient,
  onClose,
  onSubmit,
}: {
  patient: PatientLog;
  onClose: () => void;
  onSubmit: (
    response: string,
    revisedDate: string,
    revisedTime: string
  ) => void;
}) {
  const request = patient.changeRequest;
  const [response, setResponse] = useState("");
  const [revisedDate, setRevisedDate] = useState("");
  const [revisedTime, setRevisedTime] = useState(
    request?.requestedTime ?? patient.appointmentTime
  );
  const [error, setError] = useState("");
  const dialogRef = useDialogFocus(
    onClose,
    `[data-open-patient="${patient.id}"]`
  );
  const isRevision = Boolean(revisedDate);
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (response.trim().length < 3) {
      setError("Add a brief note to record your decision.");
      return;
    }
    onSubmit(response.trim(), revisedDate, revisedTime);
  };

  return (
    <div
      className="modal-backdrop fixed inset-0 z-[90] flex items-end justify-center bg-slate-950/35 p-0 sm:items-center sm:p-5"
      onMouseDown={event => event.target === event.currentTarget && onClose()}
    >
      <section
        ref={dialogRef}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-labelledby="decision-title"
        className="modal-panel w-full max-w-[500px] overflow-hidden rounded-t-2xl border border-slate-200 bg-white sm:rounded-2xl"
      >
        <div className="flex items-start justify-between border-b border-slate-200 px-5 py-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
                <Clock3 size={16} />
              </span>
              <div>
                <h2
                  id="decision-title"
                  className="text-sm font-semibold text-slate-900"
                >
                  Review schedule change
                </h2>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  {patient.name} · {patient.id}
                </p>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            data-autofocus
            aria-label="Close review dialog"
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X size={17} />
          </button>
        </div>
        <form onSubmit={submit}>
          <div className="space-y-4 px-5 py-5">
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                Assistant proposal
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                <span className="text-slate-500">Current</span>
                <span className="font-medium text-slate-800">
                  {formatDate(
                    request?.originalDate ?? patient.appointmentDate,
                    { month: "short", day: "numeric" }
                  )}{" "}
                  · {formatTime(patient.appointmentTime)}
                </span>
                <ChevronRight size={13} className="text-slate-400" />
                <span className="font-semibold text-slate-900">
                  {formatDate(
                    request?.requestedDate ?? patient.appointmentDate,
                    { month: "short", day: "numeric" }
                  )}{" "}
                  ·{" "}
                  {formatTime(
                    request?.requestedTime ?? patient.appointmentTime
                  )}
                </span>
              </div>
              <p className="mt-2 text-[11px] leading-4 text-slate-500">
                {request?.assistantNote}
              </p>
              <p className="mt-2 text-[10px] text-slate-400">
                Proposed by {request?.requestedBy} · {request?.requestedAt}
              </p>
            </div>
            <div>
              <label
                htmlFor="doctor-response"
                className="mb-1.5 block text-xs font-medium text-slate-700"
              >
                Doctor response <span className="text-rose-600">*</span>
              </label>
              <textarea
                id="doctor-response"
                value={response}
                onChange={event => {
                  setResponse(event.target.value);
                  setError("");
                }}
                rows={3}
                placeholder="Add a note for the authorization record…"
                className="w-full resize-none rounded-lg border border-slate-200 px-3 py-2.5 text-xs leading-5 text-slate-700 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-100"
              />
              {error && (
                <p className="mt-1 text-[11px] text-rose-600">{error}</p>
              )}
            </div>
            <div className="rounded-lg border border-dashed border-slate-300 p-3.5">
              <div className="flex items-start gap-2">
                <CalendarDays size={15} className="mt-0.5 text-slate-500" />
                <div className="flex-1">
                  <p className="text-xs font-medium text-slate-700">
                    Suggest a different appointment date
                  </p>
                  <p className="mt-1 text-[10px] leading-4 text-slate-500">
                    Leave the date blank to reject the assistant change and keep
                    the current schedule.
                  </p>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <label className="text-[10px] font-medium text-slate-500">
                  Revised date
                  <input
                    type="date"
                    value={revisedDate}
                    onChange={event => setRevisedDate(event.target.value)}
                    className="mt-1.5 h-9 w-full rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-700 outline-none focus:border-slate-400"
                  />
                </label>
                <label className="text-[10px] font-medium text-slate-500">
                  Revised time
                  <input
                    type="time"
                    value={revisedTime}
                    onChange={event => setRevisedTime(event.target.value)}
                    disabled={!revisedDate}
                    className="mt-1.5 h-9 w-full rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-700 outline-none disabled:bg-slate-50 disabled:text-slate-400 focus:border-slate-400"
                  />
                </label>
              </div>
            </div>
          </div>
          <footer className="flex justify-end gap-2 border-t border-slate-200 bg-slate-50/70 px-5 py-3.5">
            <button
              type="button"
              onClick={onClose}
              className="h-9 rounded-lg border border-slate-200 bg-white px-3.5 text-xs font-medium text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex h-9 items-center gap-2 rounded-lg bg-[#09090b] px-3.5 text-xs font-medium text-white hover:bg-slate-700"
            >
              <Check size={14} />
              {isRevision ? "Save revision" : "Reject change"}
            </button>
          </footer>
        </form>
      </section>
    </div>
  );
}

function PageFooter() {
  return (
    <footer className="flex flex-col gap-1 border-t border-slate-200 pt-4 text-[10px] text-slate-400 sm:flex-row sm:items-center sm:justify-between">
      <span>
        CareTrack Doctor Dashboard{" "}
        <span className="mx-1.5 text-slate-300">·</span> Synthetic sample
        records
      </span>
      <span>
        Session-only demo <span className="mx-1.5 text-slate-300">·</span>{" "}
        Changes reset on refresh
      </span>
    </footer>
  );
}

export default function Home() {
  const [patients, setPatients] = useState<PatientLog[]>(createSeedPatients);
  const [activeSection, setActiveSection] = useState<Section>("overview");
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [modeFilter, setModeFilter] = useState<"all" | AppointmentMode>("all");
  const [statusFilter, setStatusFilter] = useState<
    "all" | "pending" | "reviewed"
  >("all");
  const [severityFilter, setSeverityFilter] = useState<"all" | Severity>("all");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(
    null
  );
  const [decisionTarget, setDecisionTarget] = useState<DecisionTarget>(null);
  const today = todayKey();

  const pendingCount = patients.filter(
    patient => patient.changeRequest?.status === "pending"
  ).length;
  const todayCount = patients.filter(
    patient => patient.appointmentDate === today
  ).length;
  const onlineCount = patients.filter(
    patient => patient.mode === "Online Consultancy"
  ).length;
  const highCount = patients.filter(
    patient => patient.severity === "High"
  ).length;

  const filteredPatients = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();
    return patients
      .filter(patient => {
        const request = patient.changeRequest;
        const searchable = [
          patient.name,
          patient.id,
          patient.age,
          patient.gender,
          patient.diagnosis,
          patient.phone,
          patient.email,
          patient.notes,
          patient.assistantName,
        ]
          .join(" ")
          .toLowerCase();
        const matchesSearch =
          !normalizedSearch || searchable.includes(normalizedSearch);
        const matchesDate =
          !dateFilter ||
          patient.appointmentDate === dateFilter ||
          (request?.status === "pending" &&
            request.requestedDate === dateFilter);
        const matchesMode = modeFilter === "all" || patient.mode === modeFilter;
        const matchesSeverity =
          severityFilter === "all" || patient.severity === severityFilter;
        const matchesStatus =
          statusFilter === "all" ||
          (statusFilter === "pending" && request?.status === "pending") ||
          (statusFilter === "reviewed" &&
            Boolean(request && request.status !== "pending"));
        const matchesSection =
          activeSection !== "approvals" || request?.status === "pending";
        return (
          matchesSearch &&
          matchesDate &&
          matchesMode &&
          matchesSeverity &&
          matchesStatus &&
          matchesSection
        );
      })
      .sort((a, b) =>
        `${a.appointmentDate} ${a.appointmentTime}`.localeCompare(
          `${b.appointmentDate} ${b.appointmentTime}`
        )
      );
  }, [
    patients,
    search,
    dateFilter,
    modeFilter,
    severityFilter,
    statusFilter,
    activeSection,
  ]);

  const selectedPatient = selectedPatientId
    ? (patients.find(patient => patient.id === selectedPatientId) ?? null)
    : null;
  const decisionPatient = decisionTarget
    ? (patients.find(patient => patient.id === decisionTarget.patientId) ??
      null)
    : null;

  const resetFilters = () => {
    setSearch("");
    setDateFilter("");
    setModeFilter("all");
    setStatusFilter("all");
    setSeverityFilter("all");
  };
  const handleExport = () => {
    const exportPatients =
      activeSection === "calendar" ? patients : filteredPatients;
    downloadCsv(exportPatients);
    toast.success("Patient logs exported", {
      description: `${exportPatients.length} records saved as a CSV file.`,
    });
  };

  const approveChange = (id: string) => {
    const patient = patients.find(record => record.id === id);
    const request = patient?.changeRequest;
    if (!patient || !request || request.status !== "pending") return;
    const signOff: AuthorizationDecision = {
      outcome: "approved",
      by: DOCTOR_NAME,
      at: formatActivityTimestamp(),
      note: "Assistant-proposed appointment date approved.",
      previousDate: patient.appointmentDate,
      finalDate: request.requestedDate,
    };
    setPatients(current =>
      current.map(record =>
        record.id !== id
          ? record
          : {
              ...record,
              appointmentDate: request.requestedDate,
              appointmentTime: request.requestedTime,
              changeRequest: {
                ...request,
                status: "approved",
                decision: signOff,
              },
              authorizationTrail: [...record.authorizationTrail, signOff],
              reminders: [
                ...record.reminders,
                {
                  date: request.requestedDate,
                  time: "08:00",
                  channel: "Portal",
                  status: "Scheduled",
                  message:
                    "Updated appointment schedule confirmed after doctor authorization.",
                },
              ],
            }
      )
    );
    toast.success("Schedule approved", {
      description: `${patient.name} is now scheduled for ${formatDate(request.requestedDate, { month: "short", day: "numeric" })} at ${formatTime(request.requestedTime)}.`,
    });
  };

  const decideChange = (
    response: string,
    revisedDate: string,
    revisedTime: string
  ) => {
    if (!decisionPatient || !decisionPatient.changeRequest) return;
    const patient = decisionPatient;
    const request = patient.changeRequest!;
    const status = revisedDate ? "revised" : "rejected";
    const finalDate = revisedDate || patient.appointmentDate;
    const finalTime = revisedDate ? revisedTime : patient.appointmentTime;
    const signOff: AuthorizationDecision = {
      outcome: status,
      by: DOCTOR_NAME,
      at: formatActivityTimestamp(),
      note: response,
      previousDate: patient.appointmentDate,
      finalDate,
    };
    setPatients(current =>
      current.map(record =>
        record.id !== patient.id
          ? record
          : {
              ...record,
              ...(revisedDate
                ? { appointmentDate: revisedDate, appointmentTime: revisedTime }
                : {}),
              changeRequest: { ...request, status, decision: signOff },
              authorizationTrail: [...record.authorizationTrail, signOff],
              ...(revisedDate
                ? {
                    reminders: [
                      ...record.reminders,
                      {
                        date: revisedDate,
                        time: "08:00",
                        channel: "Portal" as const,
                        status: "Scheduled" as const,
                        message:
                          "Revised appointment schedule confirmed by the doctor.",
                      },
                    ],
                  }
                : {}),
            }
      )
    );
    setDecisionTarget(null);
    if (status === "revised")
      toast.success("Schedule revised", {
        description: `${patient.name} is now scheduled for ${formatDate(finalDate, { month: "short", day: "numeric" })} at ${formatTime(finalTime)}.`,
      });
    else
      toast.message("Change rejected", {
        description: `The original appointment for ${patient.name} remains on ${formatDate(finalDate, { month: "short", day: "numeric" })}.`,
      });
  };

  const navigate = (section: Section) => {
    setActiveSection(section);
    if (section === "approvals") {
      setSearch("");
      setDateFilter("");
      setModeFilter("all");
      setStatusFilter("all");
      setSeverityFilter("all");
    }
  };
  const activeDateText = formatLongDate(today);
  const pageTitle =
    activeSection === "overview"
      ? `${greeting()}, Dr. Maya`
      : activeSection === "logs"
        ? "Patient records"
        : activeSection === "calendar"
          ? "Your schedule"
          : "Review changes";
  const visibleCount =
    activeSection === "calendar" ? patients.length : filteredPatients.length;

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900">
      <Sidebar
        active={activeSection}
        onNavigate={navigate}
        mobileOpen={mobileOpen}
        onClose={() => setMobileOpen(false)}
        pendingCount={pendingCount}
      />
      <div className="min-h-screen lg:pl-[248px]">
        <Topbar
          onMenu={() => setMobileOpen(true)}
          patientCount={patients.length}
          pendingCount={pendingCount}
          onApprovals={() => navigate("approvals")}
        />
        <main className="mx-auto w-full max-w-[1600px] px-4 pb-8 pt-6 sm:px-6 sm:pt-7 lg:px-8 lg:pt-8">
          <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <div>
              <h1 className="text-[21px] font-semibold tracking-tight text-slate-900 sm:text-[24px]">
                {pageTitle}
              </h1>
              <p className="mt-1.5 text-xs text-slate-500">
                {activeSection === "overview"
                  ? "A clear view of your patient follow-ups and care operations."
                  : activeSection === "calendar"
                    ? "Confirmed consultations and the latest schedule changes."
                    : "Patient details, appointment updates, and care team notes."}
              </p>
            </div>
            <div className="inline-flex w-fit items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-[11px] font-medium text-slate-600">
              <CalendarDays size={14} className="text-slate-400" />
              {activeDateText}
            </div>
          </div>

          <section className="mb-7 grid grid-cols-2 gap-3 xl:grid-cols-4">
            <StatCard
              label="Appointments today"
              value={todayCount.toString().padStart(2, "0")}
              detail="Scheduled for your local day"
              icon={CalendarCheck2}
              active={activeSection === "logs" && dateFilter === today}
              onClick={() => {
                setActiveSection("logs");
                setDateFilter(today);
                setStatusFilter("all");
              }}
            />
            <StatCard
              label="Awaiting your approval"
              value={pendingCount.toString().padStart(2, "0")}
              detail={
                pendingCount
                  ? "Assistant schedule changes to review"
                  : "No changes waiting for review"
              }
              icon={ShieldCheck}
              active={activeSection === "approvals"}
              onClick={() => navigate("approvals")}
            />
            <StatCard
              label="Online consultancy"
              value={onlineCount.toString().padStart(2, "0")}
              detail="Across all assigned patient logs"
              icon={Video}
              active={modeFilter === "Online Consultancy"}
              onClick={() => {
                setActiveSection("logs");
                setModeFilter(
                  modeFilter === "Online Consultancy"
                    ? "all"
                    : "Online Consultancy"
                );
              }}
            />
            <StatCard
              label="High severity"
              value={highCount.toString().padStart(2, "0")}
              detail="Patients prioritized for follow-up"
              icon={HeartPulse}
              active={severityFilter === "High"}
              onClick={() => {
                setActiveSection("logs");
                setSeverityFilter(severityFilter === "High" ? "all" : "High");
              }}
            />
          </section>

          {activeSection === "overview" && (
            <section className="mb-7 rounded-xl border border-slate-200 bg-white p-4 sm:p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
                      <Clock3 size={14} />
                    </span>
                    <h2 className="text-sm font-semibold text-slate-900">
                      Today’s consultations
                    </h2>
                  </div>
                  <p className="mt-1.5 pl-9 text-[11px] text-slate-400">
                    Your confirmed schedule for{" "}
                    {formatDate(today, { month: "long", day: "numeric" })}
                  </p>
                </div>
                <button
                  onClick={() => setActiveSection("calendar")}
                  className="inline-flex items-center gap-1 rounded-md px-2.5 py-1.5 text-[11px] font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-900"
                >
                  Full calendar
                  <ChevronRight size={13} />
                </button>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-1">
                {patients
                  .filter(patient => patient.appointmentDate === today)
                  .sort((a, b) =>
                    a.appointmentTime.localeCompare(b.appointmentTime)
                  )
                  .map(patient => (
                    <button
                      key={patient.id}
                      onClick={() => setSelectedPatientId(patient.id)}
                      className="flex min-w-[245px] flex-1 items-center gap-3 rounded-lg border border-slate-200 p-3 text-left transition hover:border-slate-300 hover:bg-slate-50"
                    >
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-[10px] font-semibold text-slate-600">
                        {patient.initials}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-xs font-semibold text-slate-800">
                          {patient.name}
                        </span>
                        <span className="mt-1 block truncate text-[10px] text-slate-500">
                          {formatTime(patient.appointmentTime)} ·{" "}
                          {patient.mode === "Online Consultancy"
                            ? "Online"
                            : "In-person"}
                        </span>
                      </span>
                      <span
                        className={`h-2 w-2 shrink-0 rounded-full ${patient.severity === "High" ? "bg-rose-500" : patient.severity === "Moderate" ? "bg-amber-400" : "bg-emerald-500"}`}
                        title={`${patient.severity} severity`}
                      />
                    </button>
                  ))}
                {todayCount === 0 && (
                  <div className="w-full rounded-lg border border-dashed border-slate-200 py-5 text-center text-xs text-slate-400">
                    No consultations scheduled for today.
                  </div>
                )}
              </div>
            </section>
          )}

          <div className="mb-4">
            <SectionHeading
              active={activeSection}
              filteredCount={visibleCount}
              onExport={handleExport}
            />
          </div>
          {activeSection !== "calendar" && (
            <div className="mb-4">
              <FilterBar
                search={search}
                onSearch={setSearch}
                dateFilter={dateFilter}
                onDateChange={setDateFilter}
                modeFilter={modeFilter}
                onModeChange={setModeFilter}
                statusFilter={statusFilter}
                onStatusChange={setStatusFilter}
                severityFilter={severityFilter}
                onSeverityChange={setSeverityFilter}
                onReset={resetFilters}
              />
            </div>
          )}
          {activeSection === "calendar" ? (
            <CalendarView patients={patients} onOpen={setSelectedPatientId} />
          ) : (
            <PatientTable
              patients={filteredPatients}
              onOpen={setSelectedPatientId}
              onApprove={approveChange}
              onReject={id => setDecisionTarget({ patientId: id })}
              active={activeSection}
            />
          )}
          <div className="mt-6">
            <PageFooter />
          </div>
        </main>
      </div>
      {selectedPatient && (
        <PatientReceiptModal
          patient={selectedPatient}
          onClose={() => setSelectedPatientId(null)}
        />
      )}
      {decisionPatient && (
        <DecisionModal
          patient={decisionPatient}
          onClose={() => setDecisionTarget(null)}
          onSubmit={decideChange}
        />
      )}
    </div>
  );
}
