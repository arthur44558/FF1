export type AppointmentMode = "Online Consultancy" | "In-person";
export type Severity = "High" | "Moderate" | "Low";
export type ChangeStatus = "pending" | "approved" | "rejected" | "revised";

export type PatientHistoryItem = {
  date: string;
  title: string;
  description: string;
  kind: "visit" | "test" | "note";
};

export type ReminderItem = {
  date: string;
  time: string;
  channel: "SMS" | "Email" | "Portal";
  status: "Sent" | "Scheduled" | "Acknowledged";
  message: string;
};

export type AuthorizationDecision = {
  outcome: "approved" | "rejected" | "revised";
  by: string;
  at: string;
  note: string;
  previousDate: string;
  finalDate: string;
};

export type ChangeRequest = {
  status: ChangeStatus;
  originalDate: string;
  requestedDate: string;
  requestedTime: string;
  requestedBy: string;
  requestedAt: string;
  assistantNote: string;
  decision?: AuthorizationDecision;
};

export type PatientLog = {
  id: string;
  name: string;
  initials: string;
  age: number;
  gender: string;
  patientSince: string;
  phone: string;
  email: string;
  severity: Severity;
  diagnosis: string;
  mode: AppointmentMode;
  appointmentDate: string;
  appointmentTime: string;
  duration: string;
  location: string;
  notes: string;
  lastVisit: string;
  doctorContext: string;
  assistantName: string;
  history: PatientHistoryItem[];
  reminders: ReminderItem[];
  changeRequest?: ChangeRequest;
  authorizationTrail: AuthorizationDecision[];
};

function dateAtOffset(offset: number): string {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + offset);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function historyDate(offset: number): string {
  return dateAtOffset(offset);
}

function makeReminders(
  appointmentOffset: number,
  mode: AppointmentMode
): ReminderItem[] {
  const isPast = appointmentOffset < 0;
  return [
    {
      date: dateAtOffset(appointmentOffset - 2),
      time: "09:00",
      channel: "SMS",
      status: "Acknowledged",
      message: "Appointment reminder sent to the patient.",
    },
    {
      date: dateAtOffset(appointmentOffset - 1),
      time: "16:30",
      channel: mode === "Online Consultancy" ? "Email" : "Portal",
      status: isPast ? "Sent" : "Scheduled",
      message:
        mode === "Online Consultancy"
          ? "Consultation link and joining instructions shared."
          : "Visit details and clinic directions shared.",
    },
    {
      date: dateAtOffset(appointmentOffset),
      time: "08:00",
      channel: "SMS",
      status: isPast ? "Sent" : "Scheduled",
      message: "Same-day appointment reminder.",
    },
  ];
}

export function createSeedPatients(): PatientLog[] {
  return [
    {
      id: "CT-10482",
      name: "Nadia Rahman",
      initials: "NR",
      age: 34,
      gender: "Female",
      patientSince: "2022",
      phone: "+1 (415) 555-0184",
      email: "nadia.rahman@example.com",
      severity: "High",
      diagnosis: "Hypertension · follow-up",
      mode: "In-person",
      appointmentDate: dateAtOffset(0),
      appointmentTime: "09:30",
      duration: "30 min",
      location: "Room 04 · North Clinic",
      notes:
        "Please review home BP readings; patient reports occasional dizziness.",
      lastVisit: dateAtOffset(-28),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Ava Chen",
      history: [
        {
          date: historyDate(-28),
          title: "Blood pressure review",
          description:
            "Home readings elevated on 4 of 7 days. Lisinopril continued; lifestyle plan reviewed.",
          kind: "visit",
        },
        {
          date: historyDate(-42),
          title: "Metabolic panel",
          description:
            "Electrolytes and kidney function within expected range.",
          kind: "test",
        },
        {
          date: historyDate(-90),
          title: "Annual review",
          description:
            "No acute concerns. Follow-up scheduled for blood pressure monitoring.",
          kind: "note",
        },
      ],
      reminders: makeReminders(0, "In-person"),
      changeRequest: {
        status: "pending",
        originalDate: dateAtOffset(0),
        requestedDate: dateAtOffset(1),
        requestedTime: "10:15",
        requestedBy: "Ava Chen",
        requestedAt: "Today, 08:42",
        assistantNote:
          "Patient asked to move the visit by one day due to a work conflict.",
      },
      authorizationTrail: [],
    },
    {
      id: "CT-10376",
      name: "Ethan Brooks",
      initials: "EB",
      age: 57,
      gender: "Male",
      patientSince: "2019",
      phone: "+1 (415) 555-0117",
      email: "ethan.brooks@example.com",
      severity: "Moderate",
      diagnosis: "Type 2 diabetes · care review",
      mode: "Online Consultancy",
      appointmentDate: dateAtOffset(0),
      appointmentTime: "10:45",
      duration: "20 min",
      location: "Secure video consultation",
      notes:
        "Medication adherence improved. Confirm fasting glucose log is uploaded.",
      lastVisit: dateAtOffset(-31),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Noah Williams",
      history: [
        {
          date: historyDate(-31),
          title: "Diabetes follow-up",
          description:
            "A1C trending down. Continue current metformin dose and nutrition plan.",
          kind: "visit",
        },
        {
          date: historyDate(-35),
          title: "HbA1c result",
          description: "HbA1c 7.1%; improved from 7.8% at previous review.",
          kind: "test",
        },
        {
          date: historyDate(-120),
          title: "Medication plan updated",
          description:
            "Metformin dose adjusted; patient agreed to monitor fasting glucose.",
          kind: "note",
        },
      ],
      reminders: makeReminders(0, "Online Consultancy"),
      authorizationTrail: [],
    },
    {
      id: "CT-10611",
      name: "Sofia Alvarez",
      initials: "SA",
      age: 29,
      gender: "Female",
      patientSince: "2024",
      phone: "+1 (415) 555-0163",
      email: "sofia.alvarez@example.com",
      severity: "Moderate",
      diagnosis: "Migraine · treatment review",
      mode: "Online Consultancy",
      appointmentDate: dateAtOffset(1),
      appointmentTime: "08:30",
      duration: "20 min",
      location: "Secure video consultation",
      notes: "Track frequency and response to new rescue medication.",
      lastVisit: dateAtOffset(-21),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Ava Chen",
      history: [
        {
          date: historyDate(-21),
          title: "Migraine review",
          description:
            "Episodes reduced to 3 per month. New rescue therapy trial started.",
          kind: "visit",
        },
        {
          date: historyDate(-24),
          title: "Neurology note received",
          description: "No new neurological red flags; continue symptom diary.",
          kind: "note",
        },
        {
          date: historyDate(-60),
          title: "Initial assessment",
          description:
            "Recurrent migraine without aura. Sleep and hydration plan discussed.",
          kind: "visit",
        },
      ],
      reminders: makeReminders(1, "Online Consultancy"),
      changeRequest: {
        status: "pending",
        originalDate: dateAtOffset(1),
        requestedDate: dateAtOffset(2),
        requestedTime: "11:00",
        requestedBy: "Ava Chen",
        requestedAt: "Today, 09:16",
        assistantNote:
          "Patient requested an afternoon slot after a schedule change.",
      },
      authorizationTrail: [],
    },
    {
      id: "CT-10294",
      name: "Omar Khan",
      initials: "OK",
      age: 42,
      gender: "Male",
      patientSince: "2021",
      phone: "+1 (415) 555-0128",
      email: "omar.khan@example.com",
      severity: "Low",
      diagnosis: "Seasonal allergies · review",
      mode: "In-person",
      appointmentDate: dateAtOffset(2),
      appointmentTime: "14:00",
      duration: "15 min",
      location: "Room 02 · North Clinic",
      notes:
        "Symptoms stable. Check whether current antihistamine remains effective.",
      lastVisit: dateAtOffset(-70),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Noah Williams",
      history: [
        {
          date: historyDate(-70),
          title: "Allergy review",
          description:
            "Symptoms controlled with seasonal antihistamine. No adverse effects reported.",
          kind: "visit",
        },
        {
          date: historyDate(-75),
          title: "Medication reconciliation",
          description:
            "Over-the-counter medication list confirmed with patient.",
          kind: "note",
        },
        {
          date: historyDate(-180),
          title: "Initial consultation",
          description:
            "Seasonal allergic rhinitis diagnosed; conservative care plan started.",
          kind: "visit",
        },
      ],
      reminders: makeReminders(2, "In-person"),
      changeRequest: {
        status: "pending",
        originalDate: dateAtOffset(2),
        requestedDate: dateAtOffset(4),
        requestedTime: "15:30",
        requestedBy: "Noah Williams",
        requestedAt: "Yesterday, 16:08",
        assistantNote:
          "Clinic room availability changed; assistant proposed a later slot.",
      },
      authorizationTrail: [],
    },
    {
      id: "CT-10058",
      name: "Priya Nair",
      initials: "PN",
      age: 63,
      gender: "Female",
      patientSince: "2017",
      phone: "+1 (415) 555-0192",
      email: "priya.nair@example.com",
      severity: "High",
      diagnosis: "Cardiac risk · medication review",
      mode: "Online Consultancy",
      appointmentDate: dateAtOffset(-1),
      appointmentTime: "16:00",
      duration: "30 min",
      location: "Secure video consultation",
      notes:
        "Review statin tolerance and recent lipid panel; daughter may join call.",
      lastVisit: dateAtOffset(-45),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Lena Morris",
      history: [
        {
          date: historyDate(-1),
          title: "Medication review",
          description:
            "No statin side effects reported. Lipid results reviewed; continue current plan.",
          kind: "visit",
        },
        {
          date: historyDate(-6),
          title: "Lipid panel",
          description: "LDL improved; results attached to the patient record.",
          kind: "test",
        },
        {
          date: historyDate(-45),
          title: "Cardiovascular risk review",
          description:
            "Risk factors discussed; follow-up recommended after lab work.",
          kind: "note",
        },
      ],
      reminders: makeReminders(-1, "Online Consultancy"),
      authorizationTrail: [],
    },
    {
      id: "CT-10509",
      name: "Leah Chen",
      initials: "LC",
      age: 26,
      gender: "Female",
      patientSince: "2025",
      phone: "+1 (415) 555-0144",
      email: "leah.chen@example.com",
      severity: "Low",
      diagnosis: "Preventive care · annual check-in",
      mode: "In-person",
      appointmentDate: dateAtOffset(3),
      appointmentTime: "09:15",
      duration: "25 min",
      location: "Room 01 · North Clinic",
      notes:
        "Routine preventive visit. Patient asked about updated immunizations.",
      lastVisit: dateAtOffset(-365),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Lena Morris",
      history: [
        {
          date: historyDate(-365),
          title: "Annual physical",
          description:
            "Exam unremarkable. Preventive screening schedule reviewed.",
          kind: "visit",
        },
        {
          date: historyDate(-365),
          title: "Immunization record",
          description: "Routine vaccinations reviewed and updated in chart.",
          kind: "test",
        },
        {
          date: historyDate(-370),
          title: "Patient portal message",
          description:
            "Patient requested a reminder for the next preventive visit.",
          kind: "note",
        },
      ],
      reminders: makeReminders(3, "In-person"),
      authorizationTrail: [],
    },
    {
      id: "CT-10173",
      name: "Marcus Green",
      initials: "MG",
      age: 71,
      gender: "Male",
      patientSince: "2015",
      phone: "+1 (415) 555-0171",
      email: "marcus.green@example.com",
      severity: "Moderate",
      diagnosis: "Arthritis · mobility follow-up",
      mode: "Online Consultancy",
      appointmentDate: dateAtOffset(5),
      appointmentTime: "11:30",
      duration: "20 min",
      location: "Secure video consultation",
      notes:
        "Ask about morning stiffness and response to the current exercise plan.",
      lastVisit: dateAtOffset(-55),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Noah Williams",
      history: [
        {
          date: historyDate(-55),
          title: "Mobility follow-up",
          description:
            "Mild improvement after daily mobility exercises; no new joint swelling.",
          kind: "visit",
        },
        {
          date: historyDate(-62),
          title: "Imaging report",
          description: "Stable degenerative changes; no acute findings.",
          kind: "test",
        },
        {
          date: historyDate(-120),
          title: "Care plan review",
          description: "Low-impact movement and symptom tracking encouraged.",
          kind: "note",
        },
      ],
      reminders: makeReminders(5, "Online Consultancy"),
      authorizationTrail: [],
    },
    {
      id: "CT-10722",
      name: "Amara Diallo",
      initials: "AD",
      age: 38,
      gender: "Female",
      patientSince: "2020",
      phone: "+1 (415) 555-0156",
      email: "amara.diallo@example.com",
      severity: "Moderate",
      diagnosis: "Asthma · symptom check",
      mode: "In-person",
      appointmentDate: dateAtOffset(-2),
      appointmentTime: "13:00",
      duration: "20 min",
      location: "Room 03 · North Clinic",
      notes:
        "Review inhaler technique and nighttime symptoms since the last visit.",
      lastVisit: dateAtOffset(-2),
      doctorContext: "Dr. Maya Patel · Internal Medicine",
      assistantName: "Lena Morris",
      history: [
        {
          date: historyDate(-2),
          title: "Asthma symptom check",
          description:
            "Nighttime symptoms less frequent. Inhaler technique reviewed.",
          kind: "visit",
        },
        {
          date: historyDate(-8),
          title: "Peak flow log",
          description:
            "Readings stable over the past week; chart added to patient record.",
          kind: "test",
        },
        {
          date: historyDate(-95),
          title: "Treatment plan",
          description:
            "Controller medication continued with an updated action plan.",
          kind: "note",
        },
      ],
      reminders: makeReminders(-2, "In-person"),
      authorizationTrail: [],
    },
  ];
}

export function formatDate(
  dateKey: string,
  options?: Intl.DateTimeFormatOptions
): string {
  const [year, month, day] = dateKey.split("-").map(Number);
  const date = new Date(year, month - 1, day, 12);
  return new Intl.DateTimeFormat(
    "en-US",
    options ?? { month: "short", day: "numeric", year: "numeric" }
  ).format(date);
}

export function formatLongDate(dateKey: string): string {
  return formatDate(dateKey, {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

export function formatTime(time: string): string {
  const [hours, minutes] = time.split(":").map(Number);
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);
  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function todayKey(): string {
  return dateAtOffset(0);
}

export function formatActivityTimestamp(): string {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date());
}
