import {
  Activity,
  Bell,
  CalendarDays,
  CheckCircle2,
  Clock3,
  FileText,
  HeartPulse,
  MapPin,
  Phone,
  ShieldCheck,
  UserRound,
  Video,
  X,
} from "lucide-react";
import { formatDate, formatTime, type PatientLog } from "./patientData";
import { useDialogFocus } from "./useDialogFocus";

type PatientReceiptModalProps = {
  patient: PatientLog;
  onClose: () => void;
};

const historyIcon = {
  visit: Activity,
  test: HeartPulse,
  note: FileText,
};

export default function PatientReceiptModal({
  patient,
  onClose,
}: PatientReceiptModalProps) {
  const dialogRef = useDialogFocus(
    onClose,
    `[data-open-patient="${patient.id}"]`
  );

  const request = patient.changeRequest;
  const modeIcon = patient.mode === "Online Consultancy" ? Video : MapPin;
  const ModeIcon = modeIcon;
  const severityClass =
    patient.severity === "High"
      ? "bg-rose-50 text-rose-700 ring-rose-100"
      : patient.severity === "Moderate"
        ? "bg-amber-50 text-amber-700 ring-amber-100"
        : "bg-emerald-50 text-emerald-700 ring-emerald-100";

  return (
    <div
      className="modal-backdrop fixed inset-0 z-[80] flex items-end justify-center bg-slate-950/30 p-0 sm:items-center sm:p-5"
      onMouseDown={event => event.target === event.currentTarget && onClose()}
    >
      <section
        ref={dialogRef}
        tabIndex={-1}
        className="modal-panel relative flex max-h-[94vh] w-full max-w-[980px] flex-col overflow-hidden rounded-t-2xl border border-slate-200 bg-white sm:rounded-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="receipt-title"
      >
        <header className="flex items-start justify-between border-b border-slate-200 px-5 py-5 sm:px-7">
          <div className="flex items-start gap-3.5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-sm font-semibold text-slate-700">
              {patient.initials}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2
                  id="receipt-title"
                  className="text-lg font-semibold tracking-tight text-slate-900"
                >
                  Patient receipt
                </h2>
                <span className="rounded-md border border-slate-200 px-2 py-0.5 text-[11px] font-medium text-slate-500">
                  {patient.id}
                </span>
              </div>
              <p className="mt-1 text-sm text-slate-500">
                Complete consultation record · {patient.name}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            data-autofocus
            aria-label="Close patient receipt"
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
          >
            <X size={18} />
          </button>
        </header>

        <div className="overflow-y-auto px-5 py-5 sm:px-7 sm:py-6">
          <div className="grid gap-6 lg:grid-cols-[1.35fr_0.85fr]">
            <div className="space-y-6">
              <section className="rounded-xl border border-slate-200 p-4 sm:p-5">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <h3 className="text-sm font-semibold text-slate-900">
                    Patient overview
                  </h3>
                  <span
                    className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${severityClass}`}
                  >
                    <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                    {patient.severity} severity
                  </span>
                </div>
                <div className="grid gap-x-6 gap-y-4 sm:grid-cols-2">
                  <div className="flex gap-2.5">
                    <UserRound size={16} className="mt-0.5 text-slate-400" />
                    <div>
                      <p className="text-xs text-slate-500">Demographics</p>
                      <p className="mt-1 text-sm font-medium text-slate-800">
                        {patient.age} years · {patient.gender}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        Patient since {patient.patientSince}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2.5">
                    <HeartPulse size={16} className="mt-0.5 text-slate-400" />
                    <div>
                      <p className="text-xs text-slate-500">
                        Primary care focus
                      </p>
                      <p className="mt-1 text-sm font-medium text-slate-800">
                        {patient.diagnosis}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2.5">
                    <Phone size={16} className="mt-0.5 text-slate-400" />
                    <div>
                      <p className="text-xs text-slate-500">Contact details</p>
                      <p className="mt-1 text-sm font-medium text-slate-800">
                        {patient.phone}
                      </p>
                      <p className="mt-0.5 break-all text-xs text-slate-500">
                        {patient.email}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2.5">
                    <CalendarDays size={16} className="mt-0.5 text-slate-400" />
                    <div>
                      <p className="text-xs text-slate-500">
                        Scheduled consultation
                      </p>
                      <p className="mt-1 text-sm font-medium text-slate-800">
                        {formatDate(patient.appointmentDate, {
                          month: "long",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {formatTime(patient.appointmentTime)} ·{" "}
                        {patient.duration}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-slate-100 pt-4 text-xs text-slate-600">
                  <span className="inline-flex items-center gap-1.5">
                    <ModeIcon size={14} className="text-slate-400" />
                    {patient.mode}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <MapPin size={14} className="text-slate-400" />
                    {patient.location}
                  </span>
                </div>
              </section>

              <section className="rounded-xl border border-slate-200 p-4 sm:p-5">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">
                      Patient history
                    </h3>
                    <p className="mt-1 text-xs text-slate-500">
                      Recent clinical activity and notes
                    </p>
                  </div>
                  <span className="text-xs text-slate-400">
                    Last visit{" "}
                    {formatDate(patient.lastVisit, {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                </div>
                <div className="space-y-0">
                  {patient.history.map((item, index) => {
                    const Icon = historyIcon[item.kind];
                    return (
                      <div
                        key={`${item.title}-${index}`}
                        className="relative flex gap-3.5 pb-5 last:pb-0"
                      >
                        {index < patient.history.length - 1 && (
                          <span className="absolute left-[13px] top-7 h-[calc(100%-18px)] w-px bg-slate-200" />
                        )}
                        <span className="relative z-10 flex h-[27px] w-[27px] shrink-0 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500">
                          <Icon size={13} />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                            <p className="text-sm font-medium text-slate-800">
                              {item.title}
                            </p>
                            <time className="text-[11px] text-slate-400">
                              {formatDate(item.date, {
                                month: "short",
                                day: "numeric",
                                year: "numeric",
                              })}
                            </time>
                          </div>
                          <p className="mt-1 text-xs leading-5 text-slate-500">
                            {item.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            </div>

            <div className="space-y-6">
              <section className="rounded-xl border border-slate-200 p-4 sm:p-5">
                <div className="mb-4 flex items-center gap-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
                    <ShieldCheck size={16} />
                  </span>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">
                      Doctor context
                    </h3>
                    <p className="text-xs text-slate-500">Assigned care team</p>
                  </div>
                </div>
                <p className="text-sm font-medium text-slate-800">
                  {patient.doctorContext}
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  Care coordinator · {patient.assistantName}
                </p>
                <div className="mt-4 rounded-lg bg-slate-50 p-3.5">
                  <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
                    Assistant notes
                  </p>
                  <p className="mt-1.5 text-xs leading-5 text-slate-600">
                    {patient.notes}
                  </p>
                </div>
                {request && (
                  <div className="mt-3 rounded-lg border border-slate-200 p-3.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-800">
                        <Clock3 size={13} />
                        {request.status === "pending"
                          ? "Pending approval"
                          : `Change ${request.status}`}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {request.requestedAt}
                      </span>
                    </div>
                    <p className="mt-2 text-xs leading-5 text-slate-600">
                      {request.assistantNote}
                    </p>
                    <p className="mt-2 text-[11px] text-slate-500">
                      {formatDate(request.originalDate, {
                        month: "short",
                        day: "numeric",
                      })}{" "}
                      →{" "}
                      {formatDate(request.requestedDate, {
                        month: "short",
                        day: "numeric",
                      })}{" "}
                      at {formatTime(request.requestedTime)}
                    </p>
                    {request.decision && (
                      <p className="mt-2 border-t border-slate-100 pt-2 text-[11px] leading-4 text-slate-500">
                        {request.decision.outcome === "approved"
                          ? "Approved"
                          : request.decision.outcome === "revised"
                            ? "Revised"
                            : "Rejected"}{" "}
                        by {request.decision.by} · {request.decision.note}
                      </p>
                    )}
                  </div>
                )}
              </section>

              <section className="rounded-xl border border-slate-200 p-4 sm:p-5">
                <div className="mb-4 flex items-center gap-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
                    <Bell size={15} />
                  </span>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">
                      Reminder timeline
                    </h3>
                    <p className="text-xs text-slate-500">
                      Patient communication record
                    </p>
                  </div>
                </div>
                <div className="space-y-3">
                  {patient.reminders.map((reminder, index) => (
                    <div
                      key={`${reminder.date}-${reminder.channel}-${index}`}
                      className="flex gap-3"
                    >
                      <span
                        className={`mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${reminder.status === "Acknowledged" ? "bg-slate-900 text-white" : "border border-slate-200 bg-white text-slate-400"}`}
                      >
                        {reminder.status === "Acknowledged" ? (
                          <CheckCircle2 size={12} />
                        ) : (
                          <Clock3 size={11} />
                        )}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-xs font-medium text-slate-800">
                            {reminder.channel} reminder
                          </p>
                          <span className="text-[10px] text-slate-400">
                            {reminder.status}
                          </span>
                        </div>
                        <p className="mt-0.5 text-[11px] leading-4 text-slate-500">
                          {reminder.message}
                        </p>
                        <p className="mt-1 text-[10px] text-slate-400">
                          {formatDate(reminder.date, {
                            month: "short",
                            day: "numeric",
                          })}{" "}
                          · {formatTime(reminder.time)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {patient.authorizationTrail.length > 0 && (
                <section className="rounded-xl border border-slate-200 p-4 sm:p-5">
                  <div className="mb-3 flex items-center gap-2">
                    <ShieldCheck size={15} className="text-slate-500" />
                    <h3 className="text-sm font-semibold text-slate-900">
                      Authorization sign-off
                    </h3>
                  </div>
                  <div className="space-y-3">
                    {patient.authorizationTrail.map((decision, index) => (
                      <div
                        key={`${decision.at}-${index}`}
                        className="border-l-2 border-slate-200 pl-3"
                      >
                        <p className="text-xs font-medium text-slate-800">
                          {decision.outcome === "approved"
                            ? "Change approved"
                            : decision.outcome === "revised"
                              ? "Schedule revised"
                              : "Change rejected"}{" "}
                          by {decision.by}
                        </p>
                        <p className="mt-1 text-[11px] leading-4 text-slate-500">
                          {decision.at} · {decision.note}
                        </p>
                      </div>
                    ))}
                  </div>
                </section>
              )}
            </div>
          </div>
        </div>
        <footer className="flex items-center justify-between border-t border-slate-200 bg-slate-50/70 px-5 py-3.5 sm:px-7">
          <span className="text-[11px] text-slate-500">
            CareTrack · Patient record receipt
          </span>
          <span className="text-[11px] text-slate-400">
            Updated for {patient.name}
          </span>
        </footer>
      </section>
    </div>
  );
}
