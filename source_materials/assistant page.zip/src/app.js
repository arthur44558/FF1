(() => {
  "use strict";

  const doctorsBySpecialty = {
    Cardiology: ["Dr. A. Mercer", "Dr. J. Lin", "Dr. S. Okafor"],
    Orthopedics: ["Dr. R. Morgan", "Dr. L. Ahmed", "Dr. C. Bennett"],
    "General Medicine": ["Dr. M. Ellis", "Dr. K. Sharma", "Dr. T. Rivera"],
    Pediatrics: ["Dr. N. Brooks", "Dr. P. Nair", "Dr. E. Foster"],
    Dermatology: ["Dr. I. Laurent", "Dr. D. Kim", "Dr. F. Cole"]
  };

  const stepCopy = {
    1: {
      kicker: "STEP 01",
      context: "DOCTOR CONTEXT",
      title: "Doctor Session Data",
      description: "Set the clinician and date for this session."
    },
    2: {
      kicker: "STEP 02",
      context: "PATIENT VERIFICATION",
      title: "Patient Verification",
      description: "Match a fictional patient profile in the local demo directory."
    },
    3: {
      kicker: "STEP 03",
      context: "FOLLOW-UP RULES",
      title: "Follow-Up & Notification Strategy",
      description: "Set the appointment, choose a priority, and add the doctor’s remark."
    }
  };

  const today = localDateValue(new Date());
  const state = {
    activeView: "intake",
    step: 1,
    completed: false,
    doctor: { specialty: "", name: "", date: today },
    patient: {
      name: "",
      phone: "",
      patientId: "",
      lookupStatus: "idle",
      followUp: false
    },
    followup: {
      appointmentDate: "",
      priority: "",
      doctorRemark: ""
    },
    receiptReference: ""
  };

  const elements = {
    notificationButton: document.getElementById("notification-button"),
    notificationPanel: document.getElementById("notification-panel"),
    todayStamp: document.getElementById("today-stamp"),
    currentDate: document.getElementById("current-date"),
    specialty: document.getElementById("doctor-specialty"),
    doctorName: document.getElementById("doctor-name"),
    appointmentDate: document.getElementById("appointment-date"),
    doctorRemark: document.getElementById("doctor-remark"),
    panels: Array.from(document.querySelectorAll("[data-panel]")),
    indicators: Array.from(document.querySelectorAll("[data-step-indicator]")),
    overviewSteps: Array.from(document.querySelectorAll("[data-overview-step]")),
    stepKicker: document.getElementById("step-kicker"),
    stepContext: document.getElementById("step-context"),
    stepTitle: document.getElementById("step-title"),
    stepDescription: document.getElementById("step-description"),
    progressFill: document.getElementById("stepper-progress-fill"),
    backButton: document.getElementById("back-button"),
    primaryButton: document.getElementById("primary-button"),
    primaryLabel: document.getElementById("primary-label"),
    requiredNote: document.querySelector(".required-note"),
    actions: document.getElementById("form-actions"),
    completionNote: document.getElementById("completion-note"),
    validationSummary: document.getElementById("validation-summary"),
    validationSummaryText: document.getElementById("validation-summary-text"),
    followupToggle: document.getElementById("followup-toggle"),
    followupValue: document.getElementById("followup-value"),
    lookupResult: document.getElementById("patient-lookup-result"),
    lookupHeading: document.getElementById("patient-lookup-heading"),
    lookupMessage: document.getElementById("patient-lookup-message"),
    maskedPatientId: document.getElementById("patient-masked-id"),
    modal: document.getElementById("confirmation-modal"),
    dialog: document.querySelector(".receipt-dialog"),
    modalClose: document.getElementById("modal-close"),
    modalDone: document.getElementById("modal-done"),
    modalReset: document.getElementById("modal-reset"),
    timeline: document.getElementById("timeline-list"),
    timelinePlaceholder: document.getElementById("timeline-placeholder")
  };

  const fieldErrors = {
    "doctor-specialty": "specialty-error",
    "doctor-name": "doctor-error",
    "current-date": "date-error",
    "patient-name": "patient-name-error",
    "patient-phone": "patient-phone-error",
    "appointment-date": "appointment-date-error",
    "priority-low": "priority-error"
  };

  const errorsByStep = {
    1: ["doctor-specialty", "doctor-name", "current-date"],
    2: ["patient-name", "patient-phone"],
    3: ["appointment-date", "priority-low"]
  };

  const fieldToState = {
    "patient-name": ["patient", "name"],
    "patient-phone": ["patient", "phone"],
    "appointment-date": ["followup", "appointmentDate"],
    "doctor-remark": ["followup", "doctorRemark"]
  };

  function localDateValue(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function formatDate(value, options = { dateStyle: "medium" }) {
    if (!value) return "—";
    const parsed = new Date(`${value}T12:00:00`);
    if (Number.isNaN(parsed.getTime())) return "—";
    return new Intl.DateTimeFormat("en", options).format(parsed);
  }

  function setText(id, value) {
    const node = document.getElementById(id);
    if (node) node.textContent = value || "—";
  }

  function closeHeaderPanels() {
    elements.notificationPanel.hidden = true;
    elements.notificationButton.setAttribute("aria-expanded", "false");
  }

  function toggleNotificationPanel() {
    const shouldOpen = elements.notificationPanel.hidden;
    closeHeaderPanels();
    if (shouldOpen) {
      elements.notificationPanel.hidden = false;
      elements.notificationButton.setAttribute("aria-expanded", "true");
    }
  }

  function setFieldError(fieldId, message) {
    const errorId = fieldErrors[fieldId];
    const errorNode = errorId ? document.getElementById(errorId) : null;
    const field = document.getElementById(fieldId);
    if (errorNode) errorNode.textContent = message || "";
    if (field) {
      if (message) field.setAttribute("aria-invalid", "true");
      else field.removeAttribute("aria-invalid");
    }
  }

  function clearStepErrors(step = state.step) {
    (errorsByStep[step] || []).forEach((id) => setFieldError(id, ""));
    if (step === 3) {
      document.querySelectorAll('input[name="priority"]').forEach((radio) => radio.removeAttribute("aria-invalid"));
    }
    elements.validationSummary.hidden = true;
  }

  function showValidationSummary(invalidFields) {
    const count = invalidFields.length;
    elements.validationSummaryText.textContent = count === 1
      ? "One field needs attention before you continue."
      : `${count} fields need attention before you continue.`;
    elements.validationSummary.hidden = false;
    elements.validationSummary.focus();
  }

  function populateDoctorOptions(specialty, selectedValue = "") {
    const options = doctorsBySpecialty[specialty] || [];
    elements.doctorName.replaceChildren();
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = specialty ? "Select a doctor" : "Select a speciality first";
    elements.doctorName.append(placeholder);
    options.forEach((name) => {
      const option = document.createElement("option");
      option.value = name;
      option.textContent = name;
      elements.doctorName.append(option);
    });
    elements.doctorName.disabled = !specialty;
    elements.doctorName.value = options.includes(selectedValue) ? selectedValue : "";
  }

  function setPriorityCardStates() {
    document.querySelectorAll(".priority-card").forEach((card) => {
      const radio = card.querySelector('input[type="radio"]');
      card.classList.toggle("is-selected", Boolean(radio && radio.checked));
    });
  }

  function updateFollowupToggle() {
    elements.followupToggle.setAttribute("aria-checked", String(state.patient.followUp));
    elements.followupValue.textContent = state.patient.followUp ? "Yes" : "No";
    document.getElementById("followup-description").textContent = state.patient.followUp
      ? "Follow-up date and priority will be set in the next step."
      : "Add follow-up rules for this demo patient.";
  }

  function updateOverview() {
    const doctorComplete = Boolean(state.doctor.specialty && state.doctor.name && state.doctor.date);
    const patientStarted = Boolean(state.patient.name || state.patient.phone);
    const followupSkipped = state.completed && !state.patient.followUp;

    document.getElementById("overview-doctor-status").textContent = doctorComplete
      ? "Session details set"
      : "Awaiting details";
    document.getElementById("overview-patient-status").textContent = state.completed
      ? "Intake complete"
      : patientStarted ? "Details in progress" : "Not started";
    document.getElementById("overview-followup-status").textContent = state.patient.followUp
      ? (state.followup.priority ? `${priorityName(state.followup.priority)} priority` : "Plan required")
      : followupSkipped ? "Not required" : "Conditional";

    setText("overview-clinician", state.doctor.name || "Not selected");
    setText("overview-specialty", state.doctor.specialty || "Not selected");
    setText("overview-date", formatDate(state.doctor.date));

    elements.overviewSteps.forEach((item) => {
      const itemStep = Number(item.dataset.overviewStep);
      const status = item.querySelector(".overview-state");
      item.classList.toggle("is-active", itemStep === state.step && !state.completed);
      item.classList.toggle("is-complete", (itemStep < state.step && itemStep !== 3) || (state.completed && (itemStep < 3 || (state.patient.followUp && itemStep === 3))));
      if (itemStep === 1) status.textContent = doctorComplete ? "Set" : (state.step === 1 ? "Current" : "Pending");
      if (itemStep === 2) status.textContent = state.completed ? "Complete" : (state.step === 2 ? "Current" : (patientStarted ? "In progress" : "Next"));
      if (itemStep === 3) status.textContent = state.patient.followUp
        ? (state.completed ? "Planned" : (state.step === 3 ? "Current" : "Required"))
        : followupSkipped ? "Skipped" : "Optional";
      if (itemStep === 3 && followupSkipped) item.classList.add("is-skipped");
      else item.classList.remove("is-skipped");
    });
  }

  function renderStep() {
    const copy = stepCopy[state.step];
    elements.stepKicker.textContent = copy.kicker;
    elements.stepContext.textContent = copy.context;
    elements.stepTitle.textContent = copy.title;
    elements.stepDescription.textContent = copy.description;
    elements.panels.forEach((panel) => {
      panel.hidden = Number(panel.dataset.panel) !== state.step;
    });
    elements.indicators.forEach((item) => {
      const itemStep = Number(item.dataset.stepIndicator);
      item.classList.toggle("is-current", itemStep === state.step && !state.completed);
      item.classList.toggle("is-complete", (itemStep < state.step) || (state.completed && (itemStep < 3 || (state.patient.followUp && itemStep === 3))));
      item.classList.toggle("is-skipped", state.completed && !state.patient.followUp && itemStep === 3);
      if (itemStep === state.step && !state.completed) item.setAttribute("aria-current", "step");
      else item.removeAttribute("aria-current");
      if (itemStep === 3 && !state.patient.followUp && state.completed) item.setAttribute("aria-label", "Follow-Up Rules, skipped");
      else item.removeAttribute("aria-label");
    });

    const progress = state.completed ? 100 : ((state.step - 1) / 2) * 100;
    elements.progressFill.style.width = `${progress}%`;
    elements.backButton.hidden = state.step === 1 || state.completed;
    elements.requiredNote.hidden = state.completed;
    elements.completionNote.hidden = !state.completed;
    elements.primaryLabel.textContent = state.completed
      ? "Start next patient"
      : state.step === 1 ? "Next Step"
        : state.step === 2 ? (state.patient.followUp ? "Proceed to Follow-Up" : "Submit Intake")
          : "Finalize & Schedule";

    document.querySelectorAll(".step-panel input, .step-panel select, .step-panel textarea, .step-panel button").forEach((control) => {
      control.disabled = state.completed;
    });
    elements.primaryButton.disabled = false;
    updateOverview();
    updateFollowupToggle();
    setPriorityCardStates();
  }

  function validateDoctor() {
    clearStepErrors(1);
    const invalid = [];
    if (!state.doctor.specialty) {
      setFieldError("doctor-specialty", "Choose a doctor speciality.");
      invalid.push("doctor-specialty");
    }
    if (!state.doctor.name) {
      setFieldError("doctor-name", "Choose a doctor from the selected speciality.");
      invalid.push("doctor-name");
    }
    if (!state.doctor.date) {
      setFieldError("current-date", "Enter the current session date.");
      invalid.push("current-date");
    }
    if (invalid.length) showValidationSummary(invalid);
    return invalid.length === 0;
  }

  function validPhone(value) {
    const trimmed = value.trim();
    const digitCount = (trimmed.match(/\d/g) || []).length;
    return /^\+?[\d\s().-]+$/.test(trimmed) && digitCount >= 8 && digitCount <= 15;
  }

  function normalizedPhone(value) {
    return value.replace(/\D/g, "");
  }

  function maskPatientId(id) {
    return id ? `${id.slice(0, 4)}*****${id.slice(-3)}` : "";
  }

  let patientLookupTimer = null;

  function setLookupStatus(status, heading, message, patientId = "") {
    state.patient.lookupStatus = status;
    state.patient.patientId = patientId;
    elements.lookupResult.dataset.status = status;
    elements.lookupHeading.textContent = heading;
    elements.lookupMessage.textContent = message;
    elements.maskedPatientId.hidden = !patientId;
    elements.maskedPatientId.textContent = patientId ? maskPatientId(patientId) : "";
  }

  function schedulePatientLookup() {
    window.clearTimeout(patientLookupTimer);
    state.patient.patientId = "";
    const name = state.patient.name.trim();
    const phone = state.patient.phone.trim();
    if (!name && !phone) {
      setLookupStatus("idle", "Patient Unique ID", "Enter a name and phone number to search the demo directory.");
      return;
    }
    if (name.length < 2 || !validPhone(phone)) {
      setLookupStatus("incomplete", "Waiting for details", "Enter a patient name and a valid phone number to continue.");
      return;
    }

    setLookupStatus("searching", "Searching demo directory", "Checking fictional sample records in this browser only.");
    patientLookupTimer = window.setTimeout(() => {
      const patient = consultationRecords.find((record) =>
        record.name.trim().toLowerCase() === name.toLowerCase()
        && normalizedPhone(record.phone) === normalizedPhone(phone));
      if (patient) {
        setLookupStatus("matched", "Patient Unique ID", "Demo profile matched; ID is masked for this prototype.", patient.id);
      } else {
        setLookupStatus("no-match", "No demo record found", "Try the fictional sample shown below; no live patient database is connected.");
      }
    }, 300);
  }

  function validatePatient() {
    clearStepErrors(2);
    const invalid = [];
    const name = state.patient.name.trim();
    if (name.length < 2) {
      setFieldError("patient-name", "Enter the patient's name.");
      invalid.push("patient-name");
    }
    if (!validPhone(state.patient.phone)) {
      setFieldError("patient-phone", "Enter a valid phone number with 8–15 digits.");
      invalid.push("patient-phone");
    }
    if (name.length >= 2 && validPhone(state.patient.phone) && state.patient.lookupStatus !== "matched") {
      setFieldError("patient-phone", state.patient.lookupStatus === "searching"
        ? "Wait for the demo lookup to finish."
        : "No matching demo record. Use the fictional sample shown below.");
      invalid.push("patient-phone");
    }
    if (invalid.length) showValidationSummary(invalid);
    return invalid.length === 0;
  }

  function validateFollowup() {
    clearStepErrors(3);
    const invalid = [];
    if (!state.followup.appointmentDate) {
      setFieldError("appointment-date", "Choose the next appointment date.");
      invalid.push("appointment-date");
    } else if (state.followup.appointmentDate < today) {
      setFieldError("appointment-date", "Choose today or a future appointment date.");
      invalid.push("appointment-date");
    }
    if (!state.followup.priority) {
      setFieldError("priority-low", "Select a priority level.");
      document.querySelectorAll('input[name="priority"]').forEach((radio) => radio.setAttribute("aria-invalid", "true"));
      invalid.push("priority-low");
    }
    if (invalid.length) showValidationSummary(invalid);
    return invalid.length === 0;
  }

  function priorityName(value) {
    return ({ low: "Low", mid: "Mid", severe: "Severe" })[value] || "—";
  }

  function createReference() {
    const datePart = today.replaceAll("-", "");
    const randomPart = Math.random().toString(36).slice(2, 7).toUpperCase().padEnd(5, "0");
    return `CP-${datePart}-${randomPart}`;
  }

  // Reminder milestones are intentionally not generated in this UI-only prototype.

  function renderReceipt() {
    const doctorDate = formatDate(state.doctor.date);
    setText("receipt-reference-value", state.receiptReference);
    setText("receipt-date-value", formatDate(today));
    setText("receipt-doctor-name", state.doctor.name);
    setText("receipt-doctor-specialty", state.doctor.specialty);
    setText("receipt-doctor-date", doctorDate);
    setText("receipt-patient-name", state.patient.name.trim());
    setText("receipt-patient-phone", state.patient.phone.trim());
    setText("receipt-patient-id", maskPatientId(state.patient.patientId));

    const followupSection = document.getElementById("receipt-followup-section");
    followupSection.hidden = !state.patient.followUp;
    if (state.patient.followUp) {
      setText("receipt-appointment", formatDate(state.followup.appointmentDate));
      setText("receipt-priority", priorityName(state.followup.priority));
    }
    setText("receipt-doctor-remark", state.followup.doctorRemark.trim() || "No doctor’s remark provided.");

    elements.timeline.replaceChildren();
    elements.timelinePlaceholder.hidden = false;
    document.getElementById("timeline-caption").textContent = "BACKEND PENDING";
    document.getElementById("receipt-disclaimer-text").textContent = "Demo only. No patient records are saved or sent, and no reminders are scheduled.";
    document.getElementById("receipt-footer-time").textContent = new Intl.DateTimeFormat("en", { timeStyle: "short" }).format(new Date());
  }

  let previouslyFocused = null;

  function openReceipt() {
    state.receiptReference = createReference();
    renderReceipt();
    state.completed = true;
    renderStep();
    elements.modal.hidden = false;
    document.body.classList.add("modal-open");
    previouslyFocused = document.activeElement;
    elements.modalClose.focus();
  }

  function closeReceipt() {
    elements.modal.hidden = true;
    document.body.classList.remove("modal-open");
    if (previouslyFocused && typeof previouslyFocused.focus === "function") previouslyFocused.focus();
  }

  function resetPatientForNext() {
    state.patient = { name: "", phone: "", patientId: "", lookupStatus: "idle", followUp: false };
    state.followup = { appointmentDate: "", priority: "", doctorRemark: "" };
    state.completed = false;
    state.receiptReference = "";
    state.step = 2;

    document.getElementById("patient-name").value = "";
    document.getElementById("patient-phone").value = "";
    elements.followupToggle.setAttribute("aria-checked", "false");
    document.querySelectorAll('input[name="priority"]').forEach((radio) => { radio.checked = false; });
    elements.appointmentDate.value = "";
    elements.doctorRemark.value = "";
    setLookupStatus("idle", "Patient Unique ID", "Enter a name and phone number to search the demo directory.");
    Object.values(errorsByStep).flat().forEach((id) => setFieldError(id, ""));
    elements.validationSummary.hidden = true;
    renderStep();
  }

  function handlePrimaryAction() {
    if (state.completed) {
      resetPatientForNext();
      return;
    }
    if (state.step === 1) {
      state.doctor.specialty = elements.specialty.value;
      state.doctor.name = elements.doctorName.value;
      state.doctor.date = elements.currentDate.value;
      if (!validateDoctor()) return;
      state.step = 2;
      renderStep();
      document.getElementById("patient-name").focus();
      return;
    }
    if (state.step === 2) {
      if (!validatePatient()) return;
      if (state.patient.followUp) {
        state.step = 3;
        renderStep();
        elements.appointmentDate.focus();
      } else {
        openReceipt();
      }
      return;
    }
    if (state.step === 3 && validateFollowup()) openReceipt();
  }

  function handleBack() {
    clearStepErrors(state.step);
    state.step = Math.max(1, state.step - 1);
    renderStep();
    if (state.step === 1) elements.specialty.focus();
    else document.getElementById("patient-name").focus();
  }

  function updateStateFromField(field) {
    const mapping = fieldToState[field.id];
    if (!mapping) return;
    const [group, property] = mapping;
    state[group][property] = field.value;
    if (field.id === "patient-name" || field.id === "patient-phone") schedulePatientLookup();
    const errorId = fieldErrors[field.id];
    if (errorId && field.getAttribute("aria-invalid") === "true") setFieldError(field.id, "");
    if (!elements.validationSummary.hidden) elements.validationSummary.hidden = true;
    updateOverview();
  }

  const consultancyRows = document.getElementById("consultancy-rows");
  const consultancyModal = document.getElementById("consultancy-modal");
  const consultancyDialog = consultancyModal.querySelector(".consultancy-dialog");
  const consultationRecords = [
    { id: "PT-20496", name: "Maya Ellison", age: 46, gender: "Female", priority: "severe", phone: "+1 (202) 555-0147", caretaker: "+1 (202) 555-0182", relationship: "Daughter", doctor: "Dr. Daniel Kim", specialty: "Pulmonology", date: offsetDate(2), note: "Confirm respiratory assessment before visit.", done: false },
    { id: "PT-31842", name: "Noah Bennett", age: 63, gender: "Male", priority: "mid", phone: "+1 (202) 555-0113", caretaker: "", relationship: "", doctor: "Dr. A. Mercer", specialty: "Cardiology", date: offsetDate(4), note: "Review current medication list.", done: false },
    { id: "PT-57210", name: "Ava Morgan", age: 29, gender: "Female", priority: "low", phone: "+1 (202) 555-0166", caretaker: "+1 (202) 555-0191", relationship: "Partner", doctor: "Dr. R. Morgan", specialty: "Orthopedics", date: offsetDate(1), note: "", done: false },
    { id: "PT-74031", name: "Eli Navarro", age: 51, gender: "Non-binary", priority: "severe", phone: "+1 (202) 555-0138", caretaker: "", relationship: "", doctor: "Dr. M. Ellis", specialty: "General Medicine", date: offsetDate(6), note: "Priority review requested by care team.", done: false },
    { id: "PT-86012", name: "Amara Singh", age: 34, gender: "Female", priority: "mid", phone: "+1 (202) 555-0174", caretaker: "+1 (202) 555-0129", relationship: "Sister", doctor: "Dr. I. Laurent", specialty: "Dermatology", date: offsetDate(3), note: "Patient prefers an afternoon consultation.", done: false },
    { id: "PT-92841", name: "Julian Okafor", age: 57, gender: "Male", priority: "low", phone: "+1 (202) 555-0155", caretaker: "", relationship: "", doctor: "Dr. N. Brooks", specialty: "Pediatrics", date: offsetDate(-1), note: "", done: true }
  ];

  function offsetDate(days) {
    const date = new Date(`${today}T12:00:00`);
    date.setDate(date.getDate() + days);
    return localDateValue(date);
  }

  function makeNode(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function initials(name) {
    return name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
  }

  function priorityLabel(priority) {
    return ({ low: "Low", mid: "Mid", severe: "Severe" })[priority] || "Unassigned";
  }

  function contactLine(label, value, secondary = false) {
    const line = makeNode("div", secondary ? "contact-line contact-line-secondary" : "contact-line");
    line.append(makeNode("span", "contact-kind", label), makeNode("span", "contact-value", value));
    return line;
  }

  function makeConsultancyRow(record) {
    const row = makeNode("tr", `consultancy-row${record.done ? " is-done" : ""}`);
    row.dataset.caseId = record.id;
    row.tabIndex = 0;
    row.setAttribute("aria-label", `Open consultation details for ${record.name}, ${priorityLabel(record.priority)} priority`);

    const patientCell = makeNode("td", "patient-cell");
    const patientBlock = makeNode("div", "patient-block");
    patientBlock.append(makeNode("span", "patient-avatar", initials(record.name)));
    const patientCopy = makeNode("span", "patient-copy");
    patientCopy.append(makeNode("strong", "patient-full-name", record.name));
    patientCopy.append(makeNode("span", "patient-demographics", `${record.age} years · ${record.gender}`));
    patientCopy.append(makeNode("span", "patient-id", record.id));
    patientBlock.append(patientCopy);
    patientCell.append(patientBlock);

    const priorityCell = makeNode("td", "priority-cell");
    const priorityPill = makeNode("span", `severity-pill severity-${record.priority}`);
    priorityPill.append(makeNode("span", "severity-dot", "•"), document.createTextNode(` ${priorityLabel(record.priority)}`));
    priorityCell.append(priorityPill);

    const contactCell = makeNode("td", "contact-cell");
    contactCell.append(contactLine("PERSONAL", record.phone));
    if (record.caretaker) {
      const additional = makeNode("div", "additional-contact");
      additional.append(contactLine("ADDITIONAL", record.caretaker, true));
      additional.append(makeNode("span", "relationship-flag", `${record.relationship} · additional contact`));
      contactCell.append(additional);
    } else {
      contactCell.append(makeNode("span", "no-additional-contact", "No additional contact"));
    }

    const doctorCell = makeNode("td", "doctor-cell");
    doctorCell.append(makeNode("strong", "doctor-name", record.doctor), makeNode("span", "doctor-specialty", record.specialty));

    const noteCell = makeNode("td", "remark-cell");
    const noteInput = document.createElement("input");
    noteInput.type = "text";
    noteInput.className = "remark-input";
    noteInput.placeholder = "Add a note...";
    noteInput.maxLength = 160;
    noteInput.value = record.note;
    noteInput.dataset.noteFor = record.id;
    noteInput.setAttribute("aria-label", `Staff remark for ${record.name}`);
    noteCell.append(noteInput);

    const actionCell = makeNode("td", "consult-date-cell");
    const dateInput = document.createElement("input");
    dateInput.type = "date";
    dateInput.className = "consult-date-input";
    dateInput.value = record.date;
    dateInput.dataset.dateFor = record.id;
    dateInput.setAttribute("aria-label", `Consultancy date for ${record.name}`);
    const doneButton = makeNode("button", record.done ? "done-button is-complete" : "done-button", record.done ? "Completed" : "Done");
    doneButton.type = "button";
    doneButton.dataset.doneFor = record.id;
    doneButton.disabled = record.done;
    doneButton.setAttribute("aria-label", record.done ? `${record.name} consultation completed` : `Mark ${record.name} consultation done`);
    const actionWrap = makeNode("div", "consult-date-actions");
    actionWrap.append(dateInput, doneButton);
    actionCell.append(actionWrap);

    row.append(patientCell, priorityCell, contactCell, doctorCell, noteCell, actionCell);
    return row;
  }

  function visibleConsultationRecords() {
    const query = document.getElementById("consultancy-search").value.trim().toLowerCase();
    const from = document.getElementById("consultancy-date-from").value;
    const to = document.getElementById("consultancy-date-to").value;
    return consultationRecords.filter((record) => {
      const searchable = [record.id, record.name, record.age, record.gender, record.priority, record.phone, record.caretaker, record.relationship, record.doctor, record.specialty, record.note, record.done ? "completed" : "open"]
        .join(" ").toLowerCase();
      return (!query || searchable.includes(query)) && (!from || record.date >= from) && (!to || record.date <= to);
    });
  }

  function renderConsultancyRows() {
    const visible = visibleConsultationRecords();
    consultancyRows.replaceChildren(...visible.map(makeConsultancyRow));
    document.getElementById("consultancy-empty").hidden = visible.length !== 0;
    document.getElementById("consultancy-count").textContent = String(visible.length).padStart(2, "0");
    document.getElementById("consultancy-count-label").textContent = visible.length === 1 ? "record shown" : "records shown";
    document.getElementById("table-result-summary").textContent = `Showing ${visible.length} of ${consultationRecords.length} demo records`;
  }

  function updateConsultancyReceipt(record) {
    document.getElementById("consultancy-receipt-title").textContent = record.name;
    document.getElementById("consultancy-receipt-description").textContent = `${priorityLabel(record.priority)}-priority online consultancy`;
    document.getElementById("consultancy-receipt-id").textContent = record.id;
    document.getElementById("consultancy-receipt-name").textContent = record.name;
    document.getElementById("consultancy-receipt-age-gender").textContent = `${record.age} years · ${record.gender}`;
    document.getElementById("consultancy-receipt-phone").textContent = record.phone;
    document.getElementById("consultancy-receipt-caretaker").textContent = record.caretaker
      ? `${record.caretaker} · ${record.relationship}`
      : "No additional contact";
    document.getElementById("consultancy-receipt-doctor").textContent = record.doctor;
    document.getElementById("consultancy-receipt-specialty").textContent = record.specialty;
    document.getElementById("consultancy-receipt-priority").textContent = priorityLabel(record.priority);
    document.getElementById("consultancy-receipt-date").textContent = formatDate(record.date);
    document.getElementById("consultancy-receipt-status").textContent = record.done ? "Completed" : "Scheduled · demo";
    document.getElementById("consultancy-receipt-note").textContent = record.note.trim() || "No note added.";

    const timeline = document.getElementById("consultancy-timeline");
    timeline.replaceChildren();
    const events = [
      { when: "2 days before", date: formatDate(offsetDate(-2)), title: "Consultation record created", detail: "Illustrative demo entry added to the local queue." },
      { when: "Scheduled visit", date: formatDate(record.date), title: `${priorityLabel(record.priority)}-priority consultation`, detail: `Assigned to ${record.doctor} · ${record.specialty}.` }
    ];
    if (record.note.trim()) events.push({ when: "Staff note", date: formatDate(today), title: "Remark available", detail: record.note.trim() });
    if (record.done) events.push({ when: "Session status", date: formatDate(today), title: "Marked completed", detail: "Completed in this tab only; no record was transmitted." });
    events.forEach((event) => {
      const item = makeNode("li", "timeline-item");
      const dot = makeNode("span", "timeline-dot");
      dot.setAttribute("aria-hidden", "true");
      const copy = makeNode("div", "timeline-copy");
      copy.append(makeNode("strong", "", `${event.when} · ${event.date}`), makeNode("span", "", `${event.title} — ${event.detail}`));
      item.append(dot, copy);
      timeline.append(item);
    });
  }

  let activeConsultancyRecord = null;
  let focusBeforeConsultancyReceipt = null;

  function openConsultancyReceipt(record, opener) {
    activeConsultancyRecord = record;
    focusBeforeConsultancyReceipt = opener || document.activeElement;
    updateConsultancyReceipt(record);
    consultancyModal.hidden = false;
    document.body.classList.add("modal-open");
    document.getElementById("consultancy-modal-close").focus();
  }

  function closeConsultancyReceipt() {
    consultancyModal.hidden = true;
    document.body.classList.remove("modal-open");
    activeConsultancyRecord = null;
    if (focusBeforeConsultancyReceipt && typeof focusBeforeConsultancyReceipt.focus === "function") focusBeforeConsultancyReceipt.focus();
  }

  function setActiveView(view) {
    const isConsultancy = view === "consultancy";
    state.activeView = isConsultancy ? "consultancy" : "intake";
    closeHeaderPanels();
    document.getElementById("intake-view").hidden = isConsultancy;
    document.getElementById("consultancy-view").hidden = !isConsultancy;
    document.getElementById("nav-intake").classList.toggle("is-active", !isConsultancy);
    document.getElementById("nav-intake").setAttribute("aria-pressed", String(!isConsultancy));
    document.getElementById("nav-consultancy").classList.toggle("is-active", isConsultancy);
    document.getElementById("nav-consultancy").setAttribute("aria-pressed", String(isConsultancy));
    if (isConsultancy) {
      renderConsultancyRows();
      document.getElementById("consultancy-title").focus({ preventScroll: true });
    } else {
      document.getElementById("step-title").focus({ preventScroll: true });
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  elements.notificationButton.addEventListener("click", toggleNotificationPanel);
  document.getElementById("use-demo-patient").addEventListener("click", () => {
    const patient = consultationRecords[0];
    document.getElementById("patient-name").value = patient.name;
    document.getElementById("patient-phone").value = patient.phone;
    document.getElementById("patient-name").dispatchEvent(new Event("input", { bubbles: true }));
    document.getElementById("patient-phone").dispatchEvent(new Event("input", { bubbles: true }));
  });
  document.addEventListener("pointerdown", (event) => {
    if (!event.target.closest(".header-popover-anchor")) closeHeaderPanels();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape" || elements.notificationPanel.hidden) return;
    closeHeaderPanels();
    elements.notificationButton.focus();
  });

  document.getElementById("nav-intake").addEventListener("click", () => setActiveView("intake"));
  document.getElementById("nav-consultancy").addEventListener("click", () => setActiveView("consultancy"));
  document.getElementById("consultancy-search").addEventListener("input", renderConsultancyRows);
  document.getElementById("consultancy-date-from").addEventListener("change", renderConsultancyRows);
  document.getElementById("consultancy-date-to").addEventListener("change", renderConsultancyRows);
  document.getElementById("clear-filters").addEventListener("click", () => {
    document.getElementById("consultancy-search").value = "";
    document.getElementById("consultancy-date-from").value = "";
    document.getElementById("consultancy-date-to").value = "";
    renderConsultancyRows();
    document.getElementById("consultancy-search").focus();
  });

  consultancyRows.addEventListener("input", (event) => {
    const input = event.target.closest("[data-note-for]");
    if (!input) return;
    const record = consultationRecords.find((item) => item.id === input.dataset.noteFor);
    if (record) record.note = input.value;
  });
  consultancyRows.addEventListener("change", (event) => {
    const input = event.target.closest("[data-date-for]");
    if (!input) return;
    const record = consultationRecords.find((item) => item.id === input.dataset.dateFor);
    if (!record || !input.value) return;
    record.date = input.value;
    renderConsultancyRows();
  });
  consultancyRows.addEventListener("click", (event) => {
    const doneButton = event.target.closest("[data-done-for]");
    if (doneButton) {
      const record = consultationRecords.find((item) => item.id === doneButton.dataset.doneFor);
      if (record) {
        record.done = true;
        renderConsultancyRows();
      }
      return;
    }
    if (event.target.closest("input, button, a, select, textarea, label")) return;
    const row = event.target.closest("tr[data-case-id]");
    const record = row && consultationRecords.find((item) => item.id === row.dataset.caseId);
    if (record) openConsultancyReceipt(record, row);
  });
  consultancyRows.addEventListener("keydown", (event) => {
    if (event.target !== event.currentTarget && event.target.closest("input, button, a, select, textarea")) return;
    const row = event.target.closest("tr[data-case-id]");
    if (!row || (event.key !== "Enter" && event.key !== " ")) return;
    event.preventDefault();
    const record = consultationRecords.find((item) => item.id === row.dataset.caseId);
    if (record) openConsultancyReceipt(record, row);
  });
  document.getElementById("consultancy-modal-close").addEventListener("click", closeConsultancyReceipt);
  document.getElementById("consultancy-modal-done").addEventListener("click", closeConsultancyReceipt);
  consultancyModal.addEventListener("click", (event) => {
    if (event.target === consultancyModal) closeConsultancyReceipt();
  });
  document.addEventListener("keydown", (event) => {
    if (consultancyModal.hidden) return;
    if (event.key === "Escape") {
      closeConsultancyReceipt();
      return;
    }
    if (event.key === "Tab") {
      const focusable = Array.from(consultancyDialog.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
        .filter((node) => !node.hidden && node.getAttribute("aria-hidden") !== "true");
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });

  elements.specialty.addEventListener("change", () => {
    state.doctor.specialty = elements.specialty.value;
    state.doctor.name = "";
    populateDoctorOptions(state.doctor.specialty);
    setFieldError("doctor-specialty", "");
    setFieldError("doctor-name", "");
    if (!elements.validationSummary.hidden) elements.validationSummary.hidden = true;
    updateOverview();
  });

  elements.doctorName.addEventListener("change", () => {
    state.doctor.name = elements.doctorName.value;
    setFieldError("doctor-name", "");
    if (!elements.validationSummary.hidden) elements.validationSummary.hidden = true;
    updateOverview();
  });

  elements.currentDate.addEventListener("change", () => {
    state.doctor.date = elements.currentDate.value;
    setFieldError("current-date", "");
    if (!elements.validationSummary.hidden) elements.validationSummary.hidden = true;
    updateOverview();
  });

  document.querySelectorAll(".step-panel input:not([type='radio']), .step-panel select, .step-panel textarea").forEach((field) => {
    field.addEventListener("input", () => updateStateFromField(field));
    field.addEventListener("change", () => updateStateFromField(field));
  });

  document.querySelectorAll('input[name="priority"]').forEach((radio) => {
    radio.addEventListener("change", () => {
      state.followup.priority = radio.checked ? radio.value : state.followup.priority;
      setPriorityCardStates();
      setFieldError("priority-low", "");
      document.querySelectorAll('input[name="priority"]').forEach((item) => item.removeAttribute("aria-invalid"));
      if (!elements.validationSummary.hidden) elements.validationSummary.hidden = true;
      updateOverview();
    });
  });

  elements.followupToggle.addEventListener("click", () => {
    if (state.completed) return;
    state.patient.followUp = !state.patient.followUp;
    renderStep();
  });

  elements.backButton.addEventListener("click", handleBack);
  elements.primaryButton.addEventListener("click", handlePrimaryAction);
  elements.modalClose.addEventListener("click", closeReceipt);
  elements.modalDone.addEventListener("click", closeReceipt);
  elements.modalReset.addEventListener("click", () => {
    closeReceipt();
    resetPatientForNext();
    document.getElementById("patient-name").focus();
  });
  elements.modal.addEventListener("click", (event) => {
    if (event.target === elements.modal) closeReceipt();
  });

  document.addEventListener("keydown", (event) => {
    if (elements.modal.hidden) return;
    if (event.key === "Escape") {
      closeReceipt();
      return;
    }
    if (event.key === "Tab") {
      const focusable = Array.from(elements.dialog.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
        .filter((node) => !node.hidden && node.getAttribute("aria-hidden") !== "true");
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });

  elements.todayStamp.textContent = formatDate(today);
  elements.currentDate.value = today;
  elements.appointmentDate.min = today;
  elements.appointmentDate.value = "";
  populateDoctorOptions("");
  setLookupStatus("idle", "Patient Unique ID", "Enter a name and phone number to search the demo directory.");
  renderConsultancyRows();
  updateOverview();
  renderStep();
})();
