# TODO

## 1. Deliver the clinical intake wizard shell and step navigation
- [x] Build a state-driven wizard interface with a clear top progress stepper tracking three distinct phases: (01) Doctor Context, (02) Patient Info, and (03) Follow-Up Rules.
- [x] Use the requested Swiss minimalist style: pure white and soft slate-50 canvas elements (`#f8fafc`), razor-thin slate-200 borders, dark slate-900 headers, monochromatic deep-charcoal (`#09090b`) primary actions, and no heavy drop shadows or skeuomorphic styling.
- [x] Preserve entered values when navigating Back and forward; make the responsive form controls and step navigation usable with keyboard and assistive technology.

## 2. Capture and validate doctor session data
- [x] Step 1 card title is “Doctor Session Data”.
- [x] Provide Doctor Speciality as a dropdown with Cardiology, Orthopedics, General Medicine, Pediatrics, and Dermatology.
- [x] Provide Doctor Name as a dropdown dynamically filtered by the selected specialty.
- [x] Provide Current Date pre-filled with today's date.
- [x] Validate required fields before advancing state via the “Next Step” primary button.

## 3. Verify the patient in the demo directory and branch on follow-up requirement
- [x] Step 2 card title is “Patient Verification”.
- [x] Provide required Patient Name and Phone Number text inputs only.
- [x] Once both fields are entered, simulate lookup against fictional demo records and display a matching Patient Unique ID in masked format (for example `PT-2*****496`); if no match is found, show guidance to use a demo record.
- [x] Include a minimalist Yes/No switch for “Is Follow-Up Required?”.
- [x] Retain a “Back” button and preserve patient inputs and matched masked ID when navigating between steps.
- [x] Dynamically label the primary action “Submit Intake” when Follow-Up is No and trigger the receipt; label it “Proceed to Follow-Up” when Follow-Up is Yes and advance to Step 3.
- [x] Explain visibly that patient lookup is simulated with demo records only; do not save or transmit patient data.

## 4. Capture streamlined conditional follow-up rules
- [x] Step 3 is conditional: it is accessible only when Follow-Up = Yes.
- [x] Step 3 card title is “Follow-Up & Notification Strategy”.
- [x] Provide the Next Appointment Date picker, selectable Priority Level cards with radio behavior for Low, Mid, and Severe, and an optional “Doctor’s Remark” textarea; do not include personal/caretaker contact or residential address fields.
- [x] Include a “Back” button and a solid “Finalize & Schedule” button; validate the appointment date and priority before finalization, while keeping the remark optional.

## 5. Show a receipt with an unpopulated backend timeline placeholder
- [x] Trigger a clean confirmation modal upon completing Step 2 when Follow-Up is No, or completing Step 3 when Follow-Up is Yes.
- [x] Present a clean, border-separated receipt summarizing doctor session details, patient name, phone, masked demo patient ID, and follow-up date/priority where applicable.
- [x] Show a separate Doctor’s Remark block in the receipt after finalization, displaying the entered text or a clear “No doctor’s remark provided” placeholder when none was entered.
- [x] Keep the Reminder Timeline empty and show a clear placeholder that says it will be calculated/populated by a backend service; do not create demo reminder milestones or claim that messages/calls were dispatched.
- [x] Keep the “Add another patient” reset trigger; clear patient and follow-up fields for sequential demo entry while retaining Step 1 doctor context.

## 6. Add the Online Consultancy Patients dashboard as a second view
- [x] Keep the CareTrack Clinical Portal brand in the top header and provide two top-right navigation buttons: “Patient Intake” switches to the existing 3-step intake wizard; “Online Consultancy” switches to the Online Consultancy Patients dashboard.
- [x] The dashboard has the title “Online Consultancy Patients”, a date filter toolbar, and live search input.
- [x] Render interactive tabular consultancy log rows that show patient initials avatar, full name, age, gender and unique Patient ID; a monochromatic dark severity pill; personal number and any additional/caretaker number with relationship label; assigned doctor and specialty; inline editable staff remark input with “Add a note...” placeholder; editable online consultancy date and a distinct “Done” action to mark the entry completed.
- [x] Clicking a log row opens a detailed receipt modal with comprehensive patient data, doctor details and tracking timeline.
- [x] Retain Carepath’s existing Swiss minimalist neutral/charcoal styling and implement the dashboard as a responsive accessible interface. Sample/demo cases and edits remain in the current tab only; do not represent them as persistent clinical records or actually dispatch reminders.

## 7. Start directly in the clinical workspace without an in-app sign-in step
- [x] Remove the prototype login/sign-in page and credential form; open the Patient Intake page directly at Step 1 without asking for an Assistant ID or password because sign-in is handled on a separate page.
- [x] Remove the mock assistant profile/logout controls that depend on the in-app demo login; keep the Patient Intake and Online Consultancy navigation available in the workspace.

## 8. Add a demo notification dropdown
- [x] Keep the notification bell with a badge counter in the top header; clicking it toggles a dropdown showing illustrative system alerts, assistant updates, and patient tracking logs.
- [x] Keep notifications fictional and session-only; do not claim that real alerts or tracking updates are connected.
