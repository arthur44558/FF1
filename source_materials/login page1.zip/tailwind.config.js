export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        caretrack: {
          charcoal: '#09090b',
          canvas: '#f8fafc',
          surface: '#ffffff',
          border: '#e2e8f0',
        },
      },
    },
  },
  plugins: [],
};
