# CareTrack authentication operations

## What the backend does

CareTrack looks up the submitted Generated Unique ID in `caretrack_users`, verifies the password using the stored scrypt hash, and checks that the account is active. Unknown IDs, incorrect passwords, and revoked accounts share the message “Invalid Unique ID or Access Revoked”. A successful login creates an eight-hour server-side session and uses the role and permissions stored on the member record. The browser does not submit a role during sign-in.

Registration requests are saved with `pending` status. Their password is stored only as a one-way scrypt hash. Pending members cannot sign in. The registration dropdown allows Doctor, Assistant Doctor, Staff Head, Staff, and Receptionist only. IT Head is supported for existing/provisioned backend users but cannot be requested through the form.

## Schema and database

The managed project MySQL database is shared by development and the published deployment. The additive migration creates `caretrack_users`, `caretrack_registration_requests`, `caretrack_sessions`, and `caretrack_schema_migrations`; it does not delete existing records. Run `pnpm migrate` from the project directory after the managed database is available. The migration is lock-protected and records its completion, so rerunning it is safe.

Never print or commit `DATABASE_URL`. The server obtains it from the platform runtime and requires verified TLS.

## Review a pending request

An authorized operator with access to the project's managed database can list pending requests with:

```sql
SELECT request_id, full_name, work_email, department, role, created_at
FROM caretrack_registration_requests
WHERE request_status = 'pending'
ORDER BY created_at;
```

After the hospital has verified the member, approve a request and assign its permissions:

```sh
pnpm review-registration <request-uuid> approve '["workspace:read"]'
```

The review tool creates an active user, generates a role-prefixed random Unique ID (for example `DOC-…`), stores the approved permissions, and marks the request approved in one transaction. Give the printed Unique ID to the member through an approved out-of-band channel. The default permission is `workspace:read`; additional permission strings must be explicitly approved by the operator.

To reject a request and clear its pending password hash:

```sh
pnpm review-registration <request-uuid> reject
```

The review utility is an operator CLI, not a public web route; administrative credentials and actions are never bundled into the browser. No email or SMS delivery is configured.

## Sessions and troubleshooting

Sessions expire after eight hours and are stored hashed in `caretrack_sessions`. Revoking an account (`account_status = 'revoked'`) immediately prevents both new sign-ins and existing sessions from resolving. The session cookie is HTTP-only, Secure, SameSite=None, and path-scoped; browsers that block third-party cookies may require opening the portal in a standalone tab.

`GET /healthz` checks database connectivity. If it fails, inspect runtime environment availability and platform database provisioning without printing secret values. `pnpm migrate` can be safely rerun to apply the committed schema migration.
