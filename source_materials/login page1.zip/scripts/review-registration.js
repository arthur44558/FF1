import { randomBytes } from 'node:crypto';
import { createDatabasePool } from '../server/db.js';

const requestId = process.argv[2];
const action = process.argv[3] || 'approve';
let permissions;

try {
  permissions = JSON.parse(process.argv[4] || '["workspace:read"]');
} catch {
  console.error('Permissions must be a JSON array of permission strings.');
  process.exit(2);
}

if (!requestId || !/^[0-9a-f-]{36}$/i.test(requestId)) {
  console.error('Usage: pnpm review-registration <request-uuid> [approve|reject] [permissions-json]');
  process.exit(2);
}
if (!['approve', 'reject'].includes(action)) {
  console.error('Action must be approve or reject.');
  process.exit(2);
}
if (!Array.isArray(permissions) || permissions.length > 64 || permissions.some((item) => typeof item !== 'string' || item.length > 100)) {
  console.error('Permissions must be an array of at most 64 strings (100 characters each).');
  process.exit(2);
}

const rolePrefix = {
  it_head: 'ITH',
  doctor: 'DOC',
  assistant_doctor: 'AST',
  staff_head: 'STH',
  staff: 'STF',
  receptionist: 'REC',
};
const pool = createDatabasePool();
let connection;

try {
  connection = await pool.getConnection();
  await connection.beginTransaction();
  const [requests] = await connection.execute(
    'SELECT * FROM caretrack_registration_requests WHERE request_id = ? FOR UPDATE',
    [requestId],
  );
  const request = requests[0];
  if (!request || request.request_status !== 'pending') {
    throw new Error('Registration request not found or is no longer pending.');
  }

  if (action === 'reject') {
    await connection.execute(
      `UPDATE caretrack_registration_requests
       SET request_status = 'rejected', password_hash = '', reviewed_at = UTC_TIMESTAMP(3)
       WHERE request_id = ?`,
      [requestId],
    );
    await connection.commit();
    console.log(`Rejected CareTrack registration request ${requestId}.`);
  } else {
    if (!rolePrefix[request.role]) throw new Error('The requested registration role is not permitted.');
    const [existingAccounts] = await connection.execute(
      'SELECT id FROM caretrack_users WHERE work_email = ? LIMIT 1',
      [request.work_email],
    );
    if (existingAccounts.length > 0) throw new Error('An active CareTrack account already uses this work email.');

    let generatedUniqueId;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      generatedUniqueId = `${rolePrefix[request.role]}-${randomBytes(5).toString('hex').toUpperCase()}`;
      const [matches] = await connection.execute(
        'SELECT id FROM caretrack_users WHERE generated_unique_id = ? LIMIT 1',
        [generatedUniqueId],
      );
      if (matches.length === 0) break;
      generatedUniqueId = undefined;
    }
    if (!generatedUniqueId) throw new Error('Could not allocate a unique CareTrack ID; retry the approval.');

    const [insertResult] = await connection.execute(
      `INSERT INTO caretrack_users
       (generated_unique_id, full_name, work_email, role, password_hash, permissions_json, account_status)
       VALUES (?, ?, ?, ?, ?, ?, 'active')`,
      [generatedUniqueId, request.full_name, request.work_email, request.role, request.password_hash, JSON.stringify(permissions)],
    );
    await connection.execute(
      `UPDATE caretrack_registration_requests
       SET request_status = 'approved', password_hash = '', generated_unique_id = ?, approved_user_id = ?, reviewed_at = UTC_TIMESTAMP(3)
       WHERE request_id = ?`,
      [generatedUniqueId, insertResult.insertId, requestId],
    );
    await connection.commit();
    console.log(`Approved CareTrack registration request ${requestId}.`);
    console.log(`Generated Unique ID: ${generatedUniqueId}`);
    console.log(`Role: ${request.role}`);
    console.log(`Permissions: ${JSON.stringify(permissions)}`);
    console.log('Share the generated ID with the member through an approved out-of-band channel.');
  }
} catch (error) {
  if (connection) {
    try { await connection.rollback(); } catch { /* Preserve the actionable operation error. */ }
  }
  console.error(`CareTrack registration review failed: ${error.code || error.message}`);
  process.exitCode = 1;
} finally {
  connection?.release();
  await pool.end();
}
