import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import mysql from 'mysql2/promise';
import { databaseOptions } from '../server/db.js';

const rootDirectory = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const migrationId = '001_initial_auth';
const migrationPath = path.join(rootDirectory, 'db', 'migrations', `${migrationId}.sql`);
const pool = mysql.createPool(databaseOptions());
let connection;
let lockAcquired = false;

try {
  connection = await pool.getConnection();
  const [lockRows] = await connection.query(
    "SELECT GET_LOCK('caretrack_schema_migrations', 30) AS acquired",
  );
  lockAcquired = Number(lockRows[0]?.acquired) === 1;
  if (!lockAcquired) throw new Error('Could not acquire the CareTrack migration lock.');

  await connection.query(`
    CREATE TABLE IF NOT EXISTS caretrack_schema_migrations (
      migration_id VARCHAR(120) NOT NULL,
      applied_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (migration_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  const [applied] = await connection.execute(
    'SELECT migration_id FROM caretrack_schema_migrations WHERE migration_id = ? LIMIT 1',
    [migrationId],
  );

  if (applied.length === 0) {
    const migrationSql = await readFile(migrationPath, 'utf8');
    const statements = migrationSql
      .split(';')
      .map((statement) => statement.trim())
      .filter(Boolean);

    for (const statement of statements) await connection.query(statement);
    await connection.execute(
      'INSERT INTO caretrack_schema_migrations (migration_id) VALUES (?)',
      [migrationId],
    );
    console.log(`Applied CareTrack migration ${migrationId}.`);
  } else {
    console.log(`CareTrack migration ${migrationId} is already applied.`);
  }
} catch (error) {
  console.error(`CareTrack migration failed: ${error.code || error.message}`);
  process.exitCode = 1;
} finally {
  if (connection && lockAcquired) {
    try { await connection.query("SELECT RELEASE_LOCK('caretrack_schema_migrations')"); }
    catch { /* The connection is closed below even if lock cleanup fails. */ }
  }
  connection?.release();
  await pool.end();
}
