# CareTrack Access Portal — Implementation Plan

## Product and interaction

Replace the role selector on Sign In with exactly two fields: backend-generated Unique ID and Password. Submit credentials to a same-origin backend endpoint; never send or infer a role from the client. The backend performs an exact database lookup, verifies a salted password hash, rejects unknown, invalid, revoked, or inactive accounts with the same message, and returns only the authenticated profile, stored role, and permission list. A successful session routes to the dashboard path resolved from that stored role. On direct dashboard navigation, the server-backed session is revalidated and mismatched role paths are corrected.

Move role choice into account registration as a “Requested Role” field containing exactly Doctor, Assistant Doctor, Staff Head, Staff, and Receptionist. Preserve the other registration fields, password confirmation and certification validation. Persist the request with a hashed password and `pending` status; it cannot authenticate until an administrator approves it. Show an accessible administrator-pending confirmation modal only after the backend confirms the request was saved. A server-side review utility will approve or reject a pending request, generate the unique ID using a role prefix and cryptographically random suffix, assign an explicit permission list, activate the account, and print the generated ID for out-of-band delivery. IT Head remains a supported stored role for already provisioned accounts, but is not a registration option.

## Backend and serving

Use the project's managed Node server and managed MySQL database. Express serves same-origin `/api/auth/*`, `/api/registration-requests`, and `/api/dashboard/*` endpoints. In development it mounts Vite middleware on the same port; in production it serves the built frontend as a fallback while the published gateway routes `/api/*` to the container and static page paths to the Vite build. The API uses an HTTP-only Secure, SameSite=None session cookie, a double-submit CSRF token on mutations, password hashing with Node's built-in scrypt, request rate limits, and server-side account-status/role checks. It does not accept role or permissions from sign-in input.

Database changes are additive and repeatable: migration 001 creates member, pending registration, session, and migration-history tables. `pnpm migrate` runs as a finite preparation command. The container entrypoint applies pending migrations before starting the API; migrations use an advisory lock and can safely be retried. `pnpm review-registration <request-id>` provides an operator-only approval/rejection path; direct database credentials and administrative actions never enter the client bundle.

## Dependencies and deployment

Keep React, TypeScript, Tailwind CSS, Lucide, Vite, and the pnpm 11 lockfile. Add Express, mysql2, cookie-parser, and express-rate-limit for the managed API. The container installs the locked dependencies, builds the frontend, runs migrations, and starts Express on `PORT` (3000 default). The published configuration retains static output and adds a container, unauthenticated database-aware `/healthz`, and ordered `/api/*` server plus `/*` static SPA-fallback routes. Database access uses the platform `DATABASE_URL` over TLS; no database value is committed or exposed to the browser.

## Project structure

- `src/App.tsx`: Sign In and registration tabs, role-aware pending requests, session bootstrap, role-derived dashboards, and user-facing API states.
- `src/index.css`: Swiss minimalist visual system, responsive portal and dashboard styling.
- `server/index.js`: Express API, Vite development middleware, production static fallback, sessions, CSRF, rate limiting, and health endpoint.
- `server/db.js`: TLS-configured managed MySQL pool.
- `db/migrations/001_initial_auth.sql`: additive user, registration, session, and migration tables.
- `scripts/migrate.js`: safe, lock-protected migration runner.
- `scripts/review-registration.js`: operator-only pending-request approval/rejection, generated ID and explicit permissions.
- `Dockerfile`: production container for the server and frontend assets.
- `public/manus-routes.json`: `/` and `/dashboard/:role` page-route manifest.

## Design direction

**Swiss Minimalist Clinical Portal**

- **Core principles:** disciplined spacing, high legibility, shallow visual hierarchy, and low-noise clinical utility.
- **Color philosophy:** a quiet `#f8fafc` canvas, pure-white surfaces, hairline `#e2e8f0` dividers, and charcoal `#09090b` actions; color is reserved for restrained status feedback.
- **Layout paradigm:** a composed editorial portal with a compact assurance column beside a single precise access card; narrow screens collapse into a simple vertical sequence.
- **Signature elements:** thin rules, compact uppercase metadata, and crisp iconography rather than gradient-heavy decoration.
- **Interaction philosophy:** explicit labels, native keyboard-accessible role selection, inline errors, and no success state until a backend write or authentication succeeds.
- **Animation:** minimal short state transitions; respect reduced-motion preferences.
- **Typography:** the existing system UI/Inter sans-serif stack, with tight charcoal headings and measured muted supporting text.
- **Brand essence:** a calm clinical access point for CareTrack teams; precise, restrained, dependable.
- **Brand voice:** clear and operational. “Enter the Unique ID issued to you.” “Your request is saved and remains pending until an administrator approves it.”
- **Wordmark and logo:** preserve the CareTrack calendar-and-cross mark while simplifying surrounding color and elevation.
- **Signature color:** charcoal `#09090b`.
