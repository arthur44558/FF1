CREATE TABLE IF NOT EXISTS caretrack_users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  generated_unique_id VARCHAR(40) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  work_email VARCHAR(254) NOT NULL,
  role ENUM('it_head','doctor','assistant_doctor','staff_head','staff','receptionist') NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  permissions_json JSON NOT NULL,
  account_status ENUM('active','revoked') NOT NULL DEFAULT 'active',
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_caretrack_user_generated_id (generated_unique_id),
  UNIQUE KEY uq_caretrack_user_work_email (work_email),
  KEY idx_caretrack_user_role_status (role, account_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS caretrack_registration_requests (
  request_id CHAR(36) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  work_email VARCHAR(254) NOT NULL,
  department VARCHAR(100) NOT NULL,
  role ENUM('doctor','assistant_doctor','staff_head','staff','receptionist') NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  authorized_clinical_staff TINYINT(1) NOT NULL,
  request_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  generated_unique_id VARCHAR(40) NULL,
  approved_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  reviewed_at DATETIME(3) NULL,
  PRIMARY KEY (request_id),
  KEY idx_caretrack_request_email_status (work_email, request_status),
  KEY idx_caretrack_request_status_created (request_status, created_at),
  UNIQUE KEY uq_caretrack_request_generated_id (generated_unique_id),
  CONSTRAINT fk_caretrack_request_user FOREIGN KEY (approved_user_id) REFERENCES caretrack_users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS caretrack_sessions (
  session_hash CHAR(64) NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  expires_at DATETIME(3) NOT NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (session_hash),
  KEY idx_caretrack_session_expiration (expires_at),
  KEY idx_caretrack_session_user (user_id),
  CONSTRAINT fk_caretrack_session_user FOREIGN KEY (user_id) REFERENCES caretrack_users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
