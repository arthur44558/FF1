# CareTrack Portal — Delivery Status

## 1. Swiss minimalist access portal — Complete
- [x] Use the `#f8fafc` canvas, pure white `#ffffff` cards, thin `#e2e8f0` borders, and charcoal `#09090b` action accents.
- [x] Preserve the “Sign In” and “Request / Register Account” tabs, responsive layout, security notices, accessible labels, keyboard access, and password visibility toggles.
- [x] Keep manual role selection off the Sign In view.

## 2. Generated unique-ID sign-in and role-based access — Complete
- [x] Accept only the member’s backend-generated Unique ID and Password; do not ask the member to select a role.
- [x] Look up the Unique ID in the managed database, verify its scrypt password hash, and resolve the associated profile, active status, stored role, and permissions from that record.
- [x] For an unknown ID, invalid password, or revoked access, show exactly “Invalid Unique ID or Access Revoked”.
- [x] For an active member, establish a secure server session and route to the dashboard path matching the stored role; check the active account and assigned dashboard permission on authenticated server requests.
- [x] Support stored IT Head, Doctor, Assistant Doctor, Staff Head, Staff, and Receptionist roles for existing/provisioned members without accepting role input at sign-in.

## 3. Restricted account registration — Complete
- [x] The “Requested Role” dropdown contains exactly Doctor, Assistant Doctor, Staff Head, Staff, and Receptionist; IT Head is not a selectable registration option, including at the API boundary.
- [x] Preserve Full Name, Work Email Address, Department / Speciality, password creation and confirmation, password visibility, and “I certify that I am an authorized clinical staff member.” validation.
- [x] Persist approved-form submissions as pending database requests with a password hash only; pending requests cannot sign in and receive no Generated Unique ID until approval.
- [x] Show an accessible administrator-approval-pending confirmation modal only after the request is saved.

## 4. Backend, data, and security — Complete
- [x] Enable the managed server/database and add repeatable migrations for member accounts, pending registration requests, and sessions.
- [x] Store password hashes only; protect mutations with CSRF checks, apply rate limits, use Secure/HttpOnly/SameSite=None sessions, expire sessions, and reject revoked users.
- [x] Resolve dashboard role and permissions from the backend member record; never trust sign-in role input.
- [x] Provide an operator-only review command that approves or rejects pending requests; approval generates a role-prefixed random Unique ID and assigns explicit permissions without exposing administrative credentials in the frontend.
- [x] Return service/database errors rather than simulating success.

## 5. Feedback, security, and support footer — Complete
- [x] Preserve the quick feedback dialog, “Encrypted 256-bit SSL Connection • Authorized Personnel Only”, +91 24/7 support text, Privacy Protocol, and 2026 copyright notice.

> Verification note: The build, API health, schema presence, CSRF, invalid-ID response, registration IT Head rejection, root route, dashboard SPA route, and route manifest were checked. No real member account or test registration was created in the shared database, so successful sign-in requires an existing active record; see [AUTH_OPERATIONS.md](AUTH_OPERATIONS.md) for the approval/provisioning workflow.
