import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Clock3,
  HeartPulse,
  LockKeyhole,
  Mail,
  MessageSquareText,
  Plus,
  ShieldCheck,
  Sparkles,
  UserRound,
  X,
  Eye,
  EyeOff,
  Send,
  type LucideIcon,
} from 'lucide-react';

type Role = 'it_head' | 'doctor' | 'assistant_doctor' | 'staff_head' | 'staff' | 'receptionist';
type AuthMode = 'signin' | 'register';
type Notice = { title: string; body: string; tone: 'info' | 'success' | 'error' };
type AuthProfile = {
  generatedUniqueId: string;
  fullName: string;
  workEmail: string;
  role: Role;
  permissions: string[];
};
type Registration = {
  fullName: string;
  email: string;
  department: string;
  password: string;
  confirmPassword: string;
  authorized: boolean;
};
type RegistrationErrors = Partial<Record<keyof Registration, string>>;
type SignInCredentials = { uniqueId: string; password: string };

type FieldProps = {
  id: string;
  label: string;
  icon: LucideIcon;
  error?: string;
  hint?: string;
  children: ReactNode;
  className?: string;
};

const roleDetails: Record<Role, { label: string; idPrefix: string }> = {
  it_head: { label: 'IT Head', idPrefix: 'ITH' },
  doctor: { label: 'Doctor', idPrefix: 'DOC' },
  assistant_doctor: { label: 'Assistant Doctor', idPrefix: 'AST' },
  staff_head: { label: 'Staff Head', idPrefix: 'STH' },
  staff: { label: 'Staff', idPrefix: 'STF' },
  receptionist: { label: 'Receptionist', idPrefix: 'REC' },
};

const registrationRoles: Exclude<Role, 'it_head'>[] = [
  'doctor',
  'assistant_doctor',
  'staff_head',
  'staff',
  'receptionist',
];

const dashboardPaths: Record<Role, string> = {
  it_head: '/dashboard/it-head',
  doctor: '/dashboard/doctor',
  assistant_doctor: '/dashboard/assistant-doctor',
  staff_head: '/dashboard/staff-head',
  staff: '/dashboard/staff',
  receptionist: '/dashboard/receptionist',
};

const initialRegistration: Registration = {
  fullName: '',
  email: '',
  department: '',
  password: '',
  confirmPassword: '',
  authorized: false,
};

async function csrfPost(path: string, body?: unknown): Promise<Response> {
  const csrfResponse = await fetch('/api/auth/csrf', { credentials: 'same-origin' });
  const csrfPayload = await csrfResponse.json().catch(() => ({})) as { csrfToken?: string; error?: string };
  if (!csrfResponse.ok || !csrfPayload.csrfToken) {
    throw new Error(csrfPayload.error || 'Security check could not be started. Refresh the page and try again.');
  }
  return fetch(path, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
      'X-CareTrack-CSRF': csrfPayload.csrfToken,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

async function responseError(response: Response, fallback: string): Promise<string> {
  const payload = await response.json().catch(() => ({})) as { error?: string };
  return typeof payload.error === 'string' && payload.error.trim() ? payload.error : fallback;
}

function Field({ id, label, icon: Icon, error, hint, children, className = '' }: FieldProps) {
  return (
    <div className={`field-group ${className}`}>
      <label className="field-label" htmlFor={id}>{label}</label>
      <div className={`input-wrap ${error ? 'has-error' : ''}`}>
        <Icon className="input-icon" size={17} strokeWidth={1.8} aria-hidden="true" />
        {children}
      </div>
      {error && <p className="field-error" id={`${id}-error`} role="alert">{error}</p>}
      {!error && hint && <p className="field-hint">{hint}</p>}
    </div>
  );
}

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <span className={`brand-mark ${compact ? 'brand-mark-compact' : ''}`} aria-hidden="true">
      <CalendarDays size={compact ? 21 : 25} strokeWidth={1.8} />
      <span className="brand-mark-cross"><Plus size={compact ? 12 : 14} strokeWidth={3} /></span>
    </span>
  );
}

function Header({ onFeedback }: { onFeedback: () => void }) {
  return (
    <header className="site-header">
      <div className="header-inner">
        <a className="brand-lockup" href="/" aria-label="CareTrack home">
          <BrandMark />
          <span className="brand-copy">
            <span className="brand-name">Care<span>Track</span></span>
            <span className="brand-tagline">Healthcare Follow-Up &amp; Tracking System</span>
          </span>
        </a>
        <nav className="header-actions" aria-label="Page actions">
          <a className="back-link" href="/">
            <ArrowLeft size={16} strokeWidth={1.9} aria-hidden="true" />
            <span>Back to Home</span>
          </a>
          <span className="header-divider" aria-hidden="true" />
          <button className="feedback-trigger" type="button" onClick={onFeedback}>
            <MessageSquareText size={16} strokeWidth={1.9} aria-hidden="true" />
            <span>Feedback</span>
          </button>
        </nav>
      </div>
    </header>
  );
}

function PasswordField({
  id,
  label,
  value,
  onChange,
  visible,
  onToggle,
  error,
  autoComplete,
  hint,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  visible: boolean;
  onToggle: () => void;
  error?: string;
  autoComplete: string;
  hint?: string;
}) {
  return (
    <Field id={id} label={label} icon={LockKeyhole} error={error} hint={hint}>
      <input
        className="field-input with-trailing-action"
        id={id}
        name={id}
        type={visible ? 'text' : 'password'}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        autoComplete={autoComplete}
        required
        minLength={id === 'new-password' || id === 'confirm-password' ? 8 : undefined}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-error` : undefined}
      />
      <button
        type="button"
        className="password-toggle"
        onClick={onToggle}
        aria-label={`${visible ? 'Hide' : 'Show'} ${label.toLowerCase()}`}
        aria-pressed={visible}
      >
        {visible ? <EyeOff size={17} /> : <Eye size={17} />}
      </button>
    </Field>
  );
}

function SignInForm({
  userId,
  setUserId,
  rememberId,
  setRememberId,
  onSubmit,
  onForgot,
  error,
  isSubmitting,
}: {
  userId: string;
  setUserId: (value: string) => void;
  rememberId: boolean;
  setRememberId: (value: boolean) => void;
  onSubmit: (credentials: SignInCredentials) => void;
  onForgot: () => void;
  error: string;
  isSubmitting: boolean;
}) {
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onSubmit({ uniqueId: userId.trim(), password });
  }

  return (
    <form className="auth-form" onSubmit={submit}>
      <Field
        id="signin-id"
        label="Generated Unique ID"
        icon={BadgeCheck}
        hint="Enter the Unique ID issued to you after administrator approval."
      >
        <input
          className="field-input"
          id="signin-id"
          name="uniqueId"
          type="text"
          value={userId}
          onChange={(event) => setUserId(event.target.value)}
          placeholder="e.g. DOC-4A81D9C2"
          autoComplete="username"
          autoCapitalize="characters"
          spellCheck={false}
          required
        />
      </Field>

      <PasswordField
        id="signin-password"
        label="Password"
        value={password}
        onChange={setPassword}
        visible={passwordVisible}
        onToggle={() => setPasswordVisible((current) => !current)}
        autoComplete="current-password"
      />

      <div className="form-options">
        <label className="check-label" htmlFor="remember-id">
          <input
            id="remember-id"
            type="checkbox"
            checked={rememberId}
            onChange={(event) => setRememberId(event.target.checked)}
          />
          <span className="custom-check"><Check size={13} strokeWidth={3} /></span>
          <span>Remember ID on this device</span>
        </label>
        <button className="text-link" type="button" onClick={onForgot}>Forgot Password?</button>
      </div>

      {error && <p className="auth-error" role="alert">{error}</p>}
      <button className="primary-button sign-in-button" type="submit" disabled={isSubmitting}>
        <span>{isSubmitting ? 'Checking Unique ID…' : 'Sign In to Workspace'}</span>
        {!isSubmitting && <ArrowRight size={17} strokeWidth={2} aria-hidden="true" />}
      </button>
      <div className="preview-note">
        <LockKeyhole size={14} strokeWidth={1.9} aria-hidden="true" />
        <span>Role and permissions are resolved from your secure member record.</span>
      </div>
    </form>
  );
}

function RegistrationForm({
  role,
  onRoleChange,
  registration,
  onChange,
  errors,
  onSubmit,
  submitError,
  isSubmitting,
}: {
  role: Role;
  onRoleChange: (role: Role) => void;
  registration: Registration;
  onChange: (field: keyof Registration, value: string | boolean) => void;
  errors: RegistrationErrors;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  submitError: string;
  isSubmitting: boolean;
}) {
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmVisible, setConfirmVisible] = useState(false);

  return (
    <form className="auth-form registration-form" onSubmit={onSubmit} noValidate>
      <div className="register-grid">
        <Field id="full-name" label="Full Name" icon={UserRound} error={errors.fullName}>
          <input
            className="field-input"
            id="full-name"
            name="fullName"
            type="text"
            value={registration.fullName}
            onChange={(event) => onChange('fullName', event.target.value)}
            autoComplete="name"
            placeholder="e.g. Dr. Aditi Mehra"
            aria-invalid={Boolean(errors.fullName)}
            aria-describedby={errors.fullName ? 'full-name-error' : undefined}
          />
        </Field>

        <Field id="work-email" label="Work Email Address" icon={Mail} error={errors.email}>
          <input
            className="field-input"
            id="work-email"
            name="email"
            type="email"
            value={registration.email}
            onChange={(event) => onChange('email', event.target.value)}
            autoComplete="email"
            placeholder="name@hospital.org"
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? 'work-email-error' : undefined}
          />
        </Field>

        <Field id="requested-role" label="Requested Role" icon={BadgeCheck}>
          <select
            className="field-input field-select"
            id="requested-role"
            name="requestedRole"
            value={role}
            onChange={(event) => onRoleChange(event.target.value as Role)}
          >
            {registrationRoles.map((registrationRole) => (
              <option key={registrationRole} value={registrationRole}>{roleDetails[registrationRole].label}</option>
            ))}
          </select>
          <ChevronDown className="select-chevron" size={16} aria-hidden="true" />
        </Field>

        <Field id="department" label="Department / Speciality" icon={HeartPulse} error={errors.department}>
          <select
            className={`field-input field-select ${registration.department ? '' : 'is-placeholder'}`}
            id="department"
            name="department"
            value={registration.department}
            onChange={(event) => onChange('department', event.target.value)}
            aria-invalid={Boolean(errors.department)}
            aria-describedby={errors.department ? 'department-error' : undefined}
          >
            <option value="" disabled>Select your department</option>
            <option>Cardiology</option>
            <option>Orthopedics</option>
            <option>General Medicine</option>
            <option>Oncology</option>
            <option>Neurology</option>
            <option>Pediatrics</option>
            <option>Obstetrics &amp; Gynecology</option>
            <option>Administration</option>
            <option>Other Clinical Department</option>
          </select>
          <ChevronDown className="select-chevron" size={16} aria-hidden="true" />
        </Field>

        <p className="unique-id-note"><LockKeyhole size={13} /> Your Generated Unique ID will be issued after approval.</p>

        <PasswordField
          id="new-password"
          label="Create Password"
          value={registration.password}
          onChange={(value) => onChange('password', value)}
          visible={passwordVisible}
          onToggle={() => setPasswordVisible((current) => !current)}
          autoComplete="new-password"
          error={errors.password}
          hint="Use at least 8 characters."
        />

        <PasswordField
          id="confirm-password"
          label="Confirm Password"
          value={registration.confirmPassword}
          onChange={(value) => onChange('confirmPassword', value)}
          visible={confirmVisible}
          onToggle={() => setConfirmVisible((current) => !current)}
          autoComplete="new-password"
          error={errors.confirmPassword}
        />
      </div>

      <div className={`certification-box ${errors.authorized ? 'has-error' : ''}`}>
        <label className="check-label certification-label" htmlFor="authorized-staff">
          <input
            id="authorized-staff"
            type="checkbox"
            checked={registration.authorized}
            onChange={(event) => onChange('authorized', event.target.checked)}
            aria-invalid={Boolean(errors.authorized)}
            aria-describedby={errors.authorized ? 'authorized-staff-error' : undefined}
          />
          <span className="custom-check"><Check size={13} strokeWidth={3} /></span>
          <span>I certify that I am an authorized clinical staff member.</span>
        </label>
        {errors.authorized && <p className="field-error certification-error" id="authorized-staff-error" role="alert">{errors.authorized}</p>}
      </div>

      <p className="registration-disclaimer">
        Your request is stored as pending. An administrator must approve it before access is enabled.
      </p>
      {submitError && <p className="auth-error" role="alert">{submitError}</p>}
      <button className="primary-button register-button" type="submit" disabled={isSubmitting}>
        <span>{isSubmitting ? 'Submitting request…' : 'Submit Registration Request'}</span>
        {!isSubmitting && <ArrowRight size={17} strokeWidth={2} aria-hidden="true" />}
      </button>
    </form>
  );
}

function RegistrationConfirmation({
  person,
  onSignIn,
}: {
  person: { name: string; email: string; role: Role; requestId: string };
  onSignIn: () => void;
}) {
  const modalRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    document.body.style.overflow = 'hidden';
    modalRef.current?.querySelector<HTMLElement>('.modal-close')?.focus();
    const focusableElements = () => Array.from(
      modalRef.current?.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
      ) ?? [],
    );
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onSignIn();
      if (event.key === 'Tab') {
        const items = focusableElements();
        const first = items[0];
        const last = items[items.length - 1];
        const focusOutsideDialog = !modalRef.current?.contains(document.activeElement);
        if (items.length === 0) {
          event.preventDefault();
        } else if (event.shiftKey && (document.activeElement === first || focusOutsideDialog)) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && (document.activeElement === last || focusOutsideDialog)) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', onKeyDown);
      if (previouslyFocused?.isConnected) previouslyFocused.focus();
      else document.getElementById('signin-id')?.focus();
    };
  }, [onSignIn]);

  return (
    <div className="modal-backdrop registration-backdrop">
      <section
        ref={modalRef}
        className="feedback-modal registration-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="registration-confirmation-title"
        aria-describedby="registration-confirmation-copy"
      >
        <button className="modal-close" type="button" onClick={onSignIn} aria-label="Close registration confirmation"><X size={19} /></button>
        <div className="registration-confirmation">
          <span className="confirmation-icon"><CheckCircle2 size={29} strokeWidth={1.7} /></span>
          <p className="confirmation-eyebrow" role="status" aria-live="polite">Request received</p>
          <h2 id="registration-confirmation-title">Registration is pending review.</h2>
          <p className="confirmation-copy" id="registration-confirmation-copy">
            Thanks, {person.name}. Your request for <strong>{roleDetails[person.role].label}</strong> access has been saved and is awaiting administrator approval. A Generated Unique ID will be issued only if the request is approved.
          </p>
          <div className="request-summary">
            <span><span className="summary-label">Request reference</span><strong>{person.requestId.slice(0, 8).toUpperCase()}</strong></span>
            <span><span className="summary-label">Review status</span><strong className="pending-status"><span /> Pending approval</strong></span>
          </div>
          <p className="confirmation-copy confirmation-email">Request contact: <strong>{person.email}</strong></p>
          <button className="primary-button confirmation-button" type="button" onClick={onSignIn}>
            Return to Sign In <ArrowRight size={16} />
          </button>
          <p className="confirmation-footnote"><ShieldCheck size={14} /> Your password is stored as a one-way hash.</p>
        </div>
      </section>
    </div>
  );
}

function PortalCard({
  mode,
  setMode,
  role,
  onRoleChange,
  userId,
  setUserId,
  rememberId,
  setRememberId,
  registration,
  onRegistrationChange,
  registrationErrors,
  onSignIn,
  onRegister,
  onForgot,
  signInError,
  signInBusy,
  registrationError,
  registrationBusy,
}: {
  mode: AuthMode;
  setMode: (mode: AuthMode) => void;
  role: Role;
  onRoleChange: (role: Role) => void;
  userId: string;
  setUserId: (value: string) => void;
  rememberId: boolean;
  setRememberId: (value: boolean) => void;
  registration: Registration;
  onRegistrationChange: (field: keyof Registration, value: string | boolean) => void;
  registrationErrors: RegistrationErrors;
  onSignIn: (credentials: SignInCredentials) => void;
  onRegister: (event: FormEvent<HTMLFormElement>) => void;
  onForgot: () => void;
  signInError: string;
  signInBusy: boolean;
  registrationError: string;
  registrationBusy: boolean;
}) {
  const isRegister = mode === 'register';
  return (
    <section className="portal-card" aria-labelledby="card-title">
      <div className="card-topline">
        <div className="secure-label"><span className="secure-dot" /> SECURE CARE TEAM PORTAL</div>
        <div className="ssl-badge"><ShieldCheck size={14} strokeWidth={2} /> SSL PROTECTED</div>
      </div>
      <div className="card-heading">
        <div className="card-heading-mark"><BrandMark compact /></div>
        <div>
          <p className="card-overline">{isRegister ? 'REQUEST PORTAL ACCESS' : 'SIGN IN TO CONTINUE'}</p>
          <h2 id="card-title">{isRegister ? 'Request an account' : 'Access your workspace'}</h2>
          <p className="card-subtitle">
            {isRegister ? 'Your administrator will verify your details.' : 'Sign in using the Unique ID issued to you.'}
          </p>
        </div>
      </div>

      <div className="auth-tabs" role="tablist" aria-label="Choose an account action">
        <button
          type="button"
          role="tab"
          aria-selected={!isRegister}
          className={`auth-tab ${!isRegister ? 'is-active' : ''}`}
          onClick={() => setMode('signin')}
        >
          <LockKeyhole size={15} aria-hidden="true" /> Sign In
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={isRegister}
          className={`auth-tab ${isRegister ? 'is-active' : ''}`}
          onClick={() => setMode('register')}
        >
          <UserRound size={15} aria-hidden="true" /> Request / Register Account
        </button>
      </div>

      {isRegister ? (
        <>
          <div className="role-section">
            <div className="role-heading">
              <span>REGISTRATION DETAILS</span>
              <span className="role-hint"><CircleHelp size={13} /> Role is subject to approval</span>
            </div>
          </div>
          <RegistrationForm
            role={role}
            onRoleChange={onRoleChange}
            registration={registration}
            onChange={onRegistrationChange}
            errors={registrationErrors}
            onSubmit={onRegister}
            submitError={registrationError}
            isSubmitting={registrationBusy}
          />
        </>
      ) : (
        <SignInForm
          userId={userId}
          setUserId={setUserId}
          rememberId={rememberId}
          setRememberId={setRememberId}
          onSubmit={onSignIn}
          onForgot={onForgot}
          error={signInError}
          isSubmitting={signInBusy}
        />
      )}

      {!isRegister && <div className="card-bottom-note"><span className="note-seal"><ShieldCheck size={15} /></span><span>Role and access are confirmed against the active member record.</span></div>}
    </section>
  );
}

function FeedbackModal({ onClose, onComplete }: { onClose: () => void; onComplete: () => void }) {
  const [category, setCategory] = useState('Portal experience');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  const modalRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    document.body.style.overflow = 'hidden';
    modalRef.current?.querySelector<HTMLElement>('.modal-close')?.focus();
    const focusableElements = () => Array.from(
      modalRef.current?.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
      ) ?? [],
    );
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
      if (event.key === 'Tab') {
        const items = focusableElements();
        if (items.length === 0) {
          event.preventDefault();
          return;
        }
        const first = items[0];
        const last = items[items.length - 1];
        const focusOutsideDialog = !modalRef.current?.contains(document.activeElement);
        if (event.shiftKey && (document.activeElement === first || focusOutsideDialog)) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && (document.activeElement === last || focusOutsideDialog)) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', onKeyDown);
      previouslyFocused?.focus();
    };
  }, [onClose]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSent(true);
    onComplete();
  }

  return (
    <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section ref={modalRef} className="feedback-modal" role="dialog" aria-modal="true" aria-labelledby="feedback-title" aria-describedby="feedback-description">
        <button className="modal-close" type="button" onClick={onClose} aria-label="Close feedback dialog"><X size={19} /></button>
        {!sent ? (
          <>
            <span className="modal-icon"><MessageSquareText size={20} /></span>
            <p className="modal-eyebrow">CARETRACK FEEDBACK</p>
            <h2 id="feedback-title">Help us make care flow better.</h2>
            <p id="feedback-description" className="modal-copy">Tell us what is working or what could feel easier for your team.</p>
            <form onSubmit={handleSubmit} className="feedback-form">
              <label className="field-label" htmlFor="feedback-category">Topic</label>
              <div className="feedback-select-wrap">
                <select id="feedback-category" value={category} onChange={(event) => setCategory(event.target.value)}>
                  <option>Portal experience</option>
                  <option>Account access</option>
                  <option>Accessibility</option>
                  <option>Other</option>
                </select>
                <ChevronDown size={16} aria-hidden="true" />
              </div>
              <label className="field-label" htmlFor="feedback-message">Your feedback</label>
              <textarea
                id="feedback-message"
                value={message}
                onChange={(event) => setMessage(event.target.value)}
                placeholder="Share a thought with the CareTrack team…"
                rows={4}
                required
                maxLength={600}
              />
              <span className="character-count">{message.length}/600</span>
              <button className="primary-button feedback-submit" type="submit">
                <span>Send Feedback</span><Send size={16} />
              </button>
              <p className="modal-privacy-note"><LockKeyhole size={13} /> Feedback stays in this preview session.</p>
            </form>
          </>
        ) : (
          <div className="feedback-success" role="status" aria-live="polite">
            <span className="confirmation-icon"><CheckCircle2 size={29} /></span>
            <p className="modal-eyebrow">THANK YOU</p>
            <h2 id="feedback-title">Your voice helps us improve.</h2>
            <p id="feedback-description" className="modal-copy">Your {category.toLowerCase()} note has been captured for this preview session.</p>
            <button className="primary-button feedback-submit" type="button" onClick={onClose}>Done <Check size={16} /></button>
          </div>
        )}
      </section>
    </div>
  );
}

function Footer() {
  const [privacyOpen, setPrivacyOpen] = useState(false);
  return (
    <footer className="site-footer">
      <div className="security-line">
        <span className="security-mark"><LockKeyhole size={14} /></span>
        <span>Encrypted 256-bit SSL Connection</span>
        <span className="security-separator">•</span>
        <span>Authorized Personnel Only</span>
      </div>
      <div className="footer-bottom">
        <div className="footer-support">
          <span className="support-icon"><Clock3 size={15} /></span>
          <span><small>CARETRACK SUPPORT</small><strong>+91 · 24/7 helpline</strong><small className="support-detail">Use your hospital's verified local number</small></span>
        </div>
        <span className="footer-rule" aria-hidden="true" />
        <div className="footer-rights">
          <a
            className="privacy-link"
            href="#privacy-protocol"
            aria-expanded={privacyOpen}
            onClick={(event) => {
              event.preventDefault();
              setPrivacyOpen((open) => !open);
            }}
          >
            Privacy Protocol <ArrowUpRight size={13} />
          </a>
          <span className="copyright">© 2026 CareTrack. All rights reserved.</span>
        </div>
      </div>
      {privacyOpen && (
        <p className="privacy-note" id="privacy-protocol" role="status">
          Registration details and password hashes are stored for review. “Remember ID” stores only your ID in this browser. Sign-in uses a secure server session. Do not enter patient or clinical information here.
        </p>
      )}
    </footer>
  );
}

function FeedbackToast({ notice, onClose }: { notice: Notice | null; onClose: () => void }) {
  if (!notice) return null;
  return (
    <div className={`toast toast-${notice.tone}`} role="status" aria-live="polite">
      <span className="toast-icon">{notice.tone === 'success' ? <CheckCircle2 size={18} /> : <ShieldCheck size={18} />}</span>
      <span className="toast-copy"><strong>{notice.title}</strong><span>{notice.body}</span></span>
      <button className="toast-close" type="button" onClick={onClose} aria-label="Dismiss message"><X size={16} /></button>
    </div>
  );
}

function DashboardView({
  profile,
  isLoading,
  error,
  onSignOut,
}: {
  profile: AuthProfile;
  isLoading: boolean;
  error: string;
  onSignOut: () => void;
}) {
  return (
    <div className="app-shell dashboard-shell">
      <header className="site-header">
        <div className="header-inner">
          <a className="brand-lockup" href="/" aria-label="CareTrack home">
            <BrandMark />
            <span className="brand-copy">
              <span className="brand-name">Care<span>Track</span></span>
              <span className="brand-tagline">Healthcare Follow-Up &amp; Tracking System</span>
            </span>
          </a>
          <button className="feedback-trigger" type="button" onClick={onSignOut}>
            <ArrowLeft size={15} /> Sign Out
          </button>
        </div>
      </header>
      <main className="site-main dashboard-main">
        <section className="dashboard-card" aria-labelledby="dashboard-title">
          <div className="dashboard-meta"><span className="secure-dot" /> AUTHENTICATED CARETRACK SESSION</div>
          <div className="dashboard-role-icon"><BadgeCheck size={23} /></div>
          <p className="card-overline">{roleDetails[profile.role].label.toUpperCase()} WORKSPACE</p>
          <h1 id="dashboard-title">Welcome, {profile.fullName}.</h1>
          <p className="dashboard-subtitle">Your workspace access was resolved from your active member record.</p>
          <div className="dashboard-profile">
            <div><small>GENERATED UNIQUE ID</small><strong>{profile.generatedUniqueId}</strong></div>
            <div><small>ACCOUNT ROLE</small><strong>{roleDetails[profile.role].label}</strong></div>
          </div>
          <div className="dashboard-permissions">
            <div className="dashboard-permissions-heading"><span>ASSIGNED PERMISSIONS</span><span>{profile.permissions.length}</span></div>
            {isLoading ? (
              <p className="dashboard-state">Loading your permissions…</p>
            ) : error ? (
              <p className="auth-error" role="alert">{error}</p>
            ) : profile.permissions.length > 0 ? (
              <ul>{profile.permissions.map((permission) => <li key={permission}><CheckCircle2 size={15} />{permission}</li>)}</ul>
            ) : (
              <p className="dashboard-state">No additional permissions are assigned. Contact your administrator.</p>
            )}
          </div>
          <p className="dashboard-safety"><ShieldCheck size={15} /> Protected workspace · session expires after inactivity</p>
        </section>
      </main>
      <Footer />
    </div>
  );
}

function LoadingView() {
  return (
    <div className="app-shell loading-shell" role="status" aria-live="polite">
      <BrandMark />
      <span>Checking your CareTrack session…</span>
    </div>
  );
}

export default function App() {
  const [role, setRole] = useState<Role>('assistant_doctor');
  const [mode, setMode] = useState<AuthMode>('signin');
  const [userId, setUserId] = useState('');
  const [rememberId, setRememberId] = useState(false);
  const [registration, setRegistration] = useState<Registration>(initialRegistration);
  const [registrationErrors, setRegistrationErrors] = useState<RegistrationErrors>({});
  const [submittedRegistration, setSubmittedRegistration] = useState<{
    name: string;
    email: string;
    role: Role;
    requestId: string;
  } | null>(null);
  const [currentUser, setCurrentUser] = useState<AuthProfile | null>(null);
  const [currentPath, setCurrentPath] = useState(() => window.location.pathname);
  const [isCheckingSession, setIsCheckingSession] = useState(true);
  const [isSignInBusy, setIsSignInBusy] = useState(false);
  const [isRegistrationBusy, setIsRegistrationBusy] = useState(false);
  const [signInError, setSignInError] = useState('');
  const [registrationError, setRegistrationError] = useState('');
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [dashboardError, setDashboardError] = useState('');
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [notice, setNotice] = useState<Notice | null>(null);
  const closeFeedback = useCallback(() => setFeedbackOpen(false), []);
  const closeRegistrationConfirmation = useCallback(() => {
    setSubmittedRegistration(null);
    setMode('signin');
  }, []);

  function navigate(path: string, replace = false) {
    if (window.location.pathname !== path) {
      if (replace) window.history.replaceState({}, '', path);
      else window.history.pushState({}, '', path);
    }
    setCurrentPath(path);
  }

  useEffect(() => {
    try {
      const savedId = window.localStorage.getItem('caretrack.remembered-id');
      if (savedId) {
        setUserId(savedId);
        setRememberId(true);
      }
    } catch {
      // Private browsing settings may disable local storage; the form remains usable.
    }
  }, []);

  useEffect(() => {
    const onPopState = () => setCurrentPath(window.location.pathname);
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    let active = true;
    const initialPath = window.location.pathname;

    async function restoreSession() {
      try {
        const response = await fetch('/api/auth/me', { credentials: 'same-origin' });
        if (response.status === 401) {
          if (initialPath.startsWith('/dashboard/')) {
            navigate('/', true);
            setSignInError('Invalid Unique ID or Access Revoked');
          }
          return;
        }
        if (!response.ok) throw new Error(await responseError(response, 'CareTrack sign-in service is unavailable.'));
        const payload = await response.json() as { user: AuthProfile };
        if (!active) return;
        setCurrentUser(payload.user);
        const destination = dashboardPaths[payload.user.role];
        if (destination) navigate(destination, true);
      } catch (error) {
        if (active) {
          setNotice({
            title: 'CareTrack service unavailable',
            body: error instanceof Error ? error.message : 'The sign-in service could not be reached. Try again shortly.',
            tone: 'error',
          });
        }
      } finally {
        if (active) setIsCheckingSession(false);
      }
    }

    void restoreSession();
    return () => { active = false; };
    // The first URL is checked once; subsequent navigation is handled by the session and route state below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!currentUser || !currentPath.startsWith('/dashboard/')) return;
    const expectedPath = dashboardPaths[currentUser.role];
    if (expectedPath && currentPath !== expectedPath) navigate(expectedPath, true);

    const controller = new AbortController();
    setDashboardLoading(true);
    setDashboardError('');
    fetch('/api/dashboard/overview', { credentials: 'same-origin', signal: controller.signal })
      .then(async (response) => {
        if (response.status === 401) {
          setCurrentUser(null);
          navigate('/', true);
          setSignInError('Invalid Unique ID or Access Revoked');
          throw new Error('session-ended');
        }
        if (!response.ok) throw new Error(await responseError(response, 'Your dashboard could not be loaded.'));
        return response.json() as Promise<{ user: AuthProfile }>;
      })
      .then(({ user }) => {
        setCurrentUser(user);
      })
      .catch((error: unknown) => {
        if (error instanceof Error && error.name === 'AbortError') return;
        if (error instanceof Error && error.message === 'session-ended') return;
        setDashboardError(error instanceof Error ? error.message : 'Your dashboard could not be loaded.');
      })
      .finally(() => {
        if (!controller.signal.aborted) setDashboardLoading(false);
      });
    return () => controller.abort();
  }, [currentUser?.generatedUniqueId, currentPath]);

  function changeRole(nextRole: Role) {
    setRole(nextRole);
    setRegistrationError('');
  }

  async function handleSignIn(credentials: SignInCredentials) {
    setIsSignInBusy(true);
    setSignInError('');
    try {
      const response = await csrfPost('/api/auth/sign-in', credentials);
      const payload = await response.json().catch(() => ({})) as { user?: AuthProfile; error?: string };
      if (!response.ok || !payload.user) {
        setSignInError(payload.error || 'CareTrack sign-in failed. Please try again.');
        return;
      }
      try {
        if (rememberId) window.localStorage.setItem('caretrack.remembered-id', credentials.uniqueId);
        else window.localStorage.removeItem('caretrack.remembered-id');
      } catch {
        // Remember ID is optional and must not prevent authentication.
      }
      setCurrentUser(payload.user);
      const destination = dashboardPaths[payload.user.role];
      if (!destination) {
        setSignInError('Invalid Unique ID or Access Revoked');
        setCurrentUser(null);
        return;
      }
      navigate(destination);
    } catch (error) {
      setSignInError(error instanceof Error ? error.message : 'CareTrack sign-in service is unavailable.');
    } finally {
      setIsSignInBusy(false);
    }
  }

  function handleRegistrationChange(field: keyof Registration, value: string | boolean) {
    setRegistration((current) => ({ ...current, [field]: value }));
    setRegistrationErrors((current) => ({ ...current, [field]: undefined }));
    setRegistrationError('');
  }

  async function handleRegister(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const errors: RegistrationErrors = {};
    if (!registration.fullName.trim()) errors.fullName = 'Enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(registration.email.trim())) errors.email = 'Enter a valid work email address.';
    if (!registration.department) errors.department = 'Select your department or speciality.';
    if (registration.password.length < 8) errors.password = 'Use at least 8 characters for your password.';
    if (!registration.confirmPassword) errors.confirmPassword = 'Confirm your password.';
    else if (registration.password !== registration.confirmPassword) errors.confirmPassword = 'Passwords do not match.';
    if (!registration.authorized) errors.authorized = 'Certification is required to request access.';
    setRegistrationErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setIsRegistrationBusy(true);
    setRegistrationError('');
    try {
      const response = await csrfPost('/api/registration-requests', {
        fullName: registration.fullName.trim(),
        workEmail: registration.email.trim(),
        department: registration.department,
        role,
        password: registration.password,
        authorized: registration.authorized,
      });
      const payload = await response.json().catch(() => ({})) as { requestId?: string; error?: string };
      if (!response.ok || !payload.requestId) {
        setRegistrationError(payload.error || 'Your request could not be saved. Please try again.');
        return;
      }
      setSubmittedRegistration({
        name: registration.fullName.trim(),
        email: registration.email.trim(),
        role,
        requestId: payload.requestId,
      });
      setMode('signin');
      setRegistration(initialRegistration);
    } catch (error) {
      setRegistrationError(error instanceof Error ? error.message : 'CareTrack registration service is unavailable.');
    } finally {
      setIsRegistrationBusy(false);
    }
  }

  async function handleSignOut() {
    try {
      const response = await csrfPost('/api/auth/logout');
      if (!response.ok) throw new Error(await responseError(response, 'Sign out could not be completed.'));
      setCurrentUser(null);
      setDashboardError('');
      navigate('/');
    } catch (error) {
      setNotice({
        title: 'Sign out could not be completed',
        body: error instanceof Error ? error.message : 'Please try again.',
        tone: 'error',
      });
    }
  }

  function handleForgotPassword() {
    setNotice({
      title: 'Password help',
      body: 'Password recovery is not configured. Contact your hospital administrator for account-recovery assistance.',
      tone: 'info',
    });
  }

  function handleFeedbackComplete() {
    setNotice({
      title: 'Feedback captured',
      body: 'Your note is available in this preview session; no message was sent to an administrator.',
      tone: 'success',
    });
  }

  const isDashboardPath = currentPath.startsWith('/dashboard/');
  if (isCheckingSession) return <LoadingView />;
  if (currentUser && isDashboardPath) {
    return (
      <>
        <DashboardView profile={currentUser} isLoading={dashboardLoading} error={dashboardError} onSignOut={handleSignOut} />
        <FeedbackToast notice={notice} onClose={() => setNotice(null)} />
      </>
    );
  }

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" aria-hidden="true" />
      <div className="ambient ambient-two" aria-hidden="true" />
      <Header onFeedback={() => setFeedbackOpen(true)} />

      <main className="site-main">
        <div className="portal-layout">
          <aside className="portal-story" aria-label="CareTrack overview">
            <div className="story-eyebrow"><span className="story-eyebrow-dot" /> BUILT AROUND CONTINUITY OF CARE</div>
            <h1>Every next step,<br /><span>in good hands.</span></h1>
            <p className="story-description">
              A clearer view of every follow-up—so care teams can stay close to what matters most.
            </p>

            <div className="care-flow" aria-label="CareTrack team benefits">
              <div className="care-flow-line" aria-hidden="true" />
              <div className="care-flow-item">
                <span className="flow-icon flow-icon-teal"><CalendarDays size={18} /></span>
                <span><strong>Follow-ups, in view</strong><small>Keep each next step on track.</small></span>
                <CheckCircle2 className="flow-check" size={17} />
              </div>
              <div className="care-flow-item">
                <span className="flow-icon flow-icon-orange"><HeartPulse size={18} /></span>
                <span><strong>Care teams, connected</strong><small>Share a steadier picture of care.</small></span>
                <CheckCircle2 className="flow-check" size={17} />
              </div>
              <div className="care-flow-item">
                <span className="flow-icon flow-icon-navy"><BadgeCheck size={18} /></span>
                <span><strong>Access, protected</strong><small>Role-based entry for your team.</small></span>
                <CheckCircle2 className="flow-check" size={17} />
              </div>
            </div>

            <div className="story-trust">
              <span className="trust-icon"><ShieldCheck size={17} /></span>
              <span><small>A PRIVATE SPACE FOR CARE TEAMS</small><strong>Thoughtful follow-up. Trusted access.</strong></span>
              <Sparkles className="trust-sparkle" size={16} />
            </div>
          </aside>

          <PortalCard
            mode={mode}
            setMode={(nextMode) => {
              setMode(nextMode);
              setRegistrationErrors({});
              setRegistrationError('');
              setSignInError('');
              if (nextMode === 'signin') setSubmittedRegistration(null);
            }}
            role={role}
            onRoleChange={changeRole}
            userId={userId}
            setUserId={(value) => {
              setUserId(value);
              setSignInError('');
            }}
            rememberId={rememberId}
            setRememberId={setRememberId}
            registration={registration}
            onRegistrationChange={handleRegistrationChange}
            registrationErrors={registrationErrors}
            onSignIn={handleSignIn}
            onRegister={handleRegister}
            onForgot={handleForgotPassword}
            signInError={signInError}
            signInBusy={isSignInBusy}
            registrationError={registrationError}
            registrationBusy={isRegistrationBusy}
          />
        </div>
      </main>

      <Footer />
      <FeedbackToast notice={notice} onClose={() => setNotice(null)} />
      {feedbackOpen && <FeedbackModal onClose={closeFeedback} onComplete={handleFeedbackComplete} />}
      {submittedRegistration && (
        <RegistrationConfirmation person={submittedRegistration} onSignIn={closeRegistrationConfirmation} />
      )}
    </div>
  );
}
