import mysql from 'mysql2/promise';

export function databaseOptions(databaseUrl = process.env.DATABASE_URL || process.env.DRIZZLE_DATABASE_URL) {
  if (!databaseUrl) {
    throw new Error('DATABASE_URL is not configured. Enable the managed CareTrack database first.');
  }

  const url = new URL(databaseUrl);
  if (!['mysql:', 'mariadb:'].includes(url.protocol)) {
    throw new Error('DATABASE_URL must use the mysql or mariadb protocol.');
  }

  return {
    host: url.hostname,
    port: Number(url.port || 3306),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: decodeURIComponent(url.pathname.replace(/^\//, '')),
    ssl: { rejectUnauthorized: true },
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4',
    timezone: 'Z',
    enableKeepAlive: true,
    connectTimeout: 10000,
  };
}

export function createDatabasePool() {
  return mysql.createPool(databaseOptions());
}
