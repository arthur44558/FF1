import { createHash, randomBytes, randomUUID, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { createServer as createHttpServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import express from 'express';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { createServer as createViteServer } from 'vite';
import { createDatabasePool } from './db.js';

const rootDirectory = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const app = express();
const httpServer = createHttpServer(app);
const port = Number(process.env.PORT || 3000);
const sessionCookieName = 'caretrack_session';
const csrfCookieName = 'caretrack_csrf';
const sessionLifetimeMs = 8 * 60 * 60 * 1000;
const passwordKeyLength = 64;
const scryptAsync = promisify(scrypt);
const registrationRoles = new Set(['doctor', 'assistant_doctor', 'staff_head', 'staff', 'receptionist']);
let databasePool;
let viteServer;

const asyncHandler = (handler) => (request, response, next) => {
  Promise.resolve(handler(request, response, next)).catch(next);
};

function getPool() {
  if (!databasePool) databasePool = createDatabasePool();
  return databasePool;
}

function hashToken(token) {
  return createHash('sha256').update(token).digest('hex');
}

async function hashPassword(password) {
  const salt = randomBytes(16);
  const derivedKey = await scryptAsync(password, salt, passwordKeyLength, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 64 * 1024 * 1024,
  });
  return `scrypt$16384$8$1$${salt.toString('hex')}$${Buffer.from(derivedKey).toString('hex')}`;
}

async function verifyPassword(password, encodedHash) {
  if (typeof encodedHash !== 'string') return false;
  const [algorithm, cost, blockSize, parallelism, saltHex, keyHex] = encodedHash.split('$');
  if (algorithm !== 'scrypt' || cost !== '16384' || blockSize !== '8' || parallelism !== '1') return false;
  if (!/^[a-f0-9]{32}$/i.test(saltHex || '') || !/^[a-f0-9]{128}$/i.test(keyHex || '')) return false;
  const expected = Buffer.from(keyHex, 'hex');
  const actual = Buffer.from(await scryptAsync(password, Buffer.from(saltHex, 'hex'), expected.length, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 64 * 1024 * 1024,
  }));
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

const dummyPasswordHash = hashPassword('CareTrack-dummy-password-never-used');

function parsePermissions(value) {
  if (Array.isArray(value)) return value.filter((item) => typeof item === 'string');
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((item) => typeof item === 'string') : [];
    } catch {
      return [];
    }
  }
  return [];
}

function publicProfile(user) {
  return {
    generatedUniqueId: user.generated_unique_id,
    fullName: user.full_name,
    workEmail: user.work_email,
    role: user.role,
    permissions: parsePermissions(user.permissions_json),
  };
}

function constantTimeMatch(left, right) {
  if (typeof left !== 'string' || typeof right !== 'string') return false;
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

function setCsrfCookie(response, token) {
  response.cookie(csrfCookieName, token, {
    httpOnly: false,
    secure: true,
    sameSite: 'none',
    path: '/',
    maxAge: sessionLifetimeMs,
  });
}

function requireCsrf(request, response, next) {
  const cookieToken = request.cookies[csrfCookieName];
  const headerToken = request.get('x-caretrack-csrf');
  if (!constantTimeMatch(cookieToken, headerToken)) {
    return response.status(403).json({ error: 'Security check failed. Refresh the page and try again.' });
  }
  next();
}

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 12,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many sign-in attempts. Please wait and try again.' },
});

const registrationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many registration requests. Please try again later.' },
});

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(cookieParser());
app.use(express.json({ limit: '24kb', strict: true }));
app.use('/api', (request, response, next) => {
  response.setHeader('Cache-Control', 'no-store, private');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Referrer-Policy', 'same-origin');
  next();
});

app.get('/healthz', asyncHandler(async (_request, response) => {
  await getPool().query('SELECT 1');
  response.status(200).json({ status: 'ok' });
}));

app.get('/api/auth/csrf', (_request, response) => {
  const token = randomBytes(32).toString('base64url');
  setCsrfCookie(response, token);
  response.json({ csrfToken: token });
});

app.post('/api/auth/sign-in', loginLimiter, requireCsrf, asyncHandler(async (request, response) => {
  const uniqueId = typeof request.body?.uniqueId === 'string' ? request.body.uniqueId.trim().toUpperCase() : '';
  const password = typeof request.body?.password === 'string' ? request.body.password : '';

  if (!/^[A-Z0-9][A-Z0-9-]{4,39}$/.test(uniqueId) || password.length < 1 || password.length > 256) {
    await verifyPassword(password.slice(0, 256), await dummyPasswordHash);
    return response.status(401).json({ error: 'Invalid Unique ID or Access Revoked' });
  }

  const pool = getPool();
  const [users] = await pool.execute(
    `SELECT id, generated_unique_id, full_name, work_email, role, password_hash,
            permissions_json, account_status
     FROM caretrack_users
     WHERE generated_unique_id = ?
     LIMIT 1`,
    [uniqueId],
  );
  const user = users[0];
  const passwordIsValid = await verifyPassword(password, user?.password_hash || await dummyPasswordHash);
  if (!user || user.account_status !== 'active' || !passwordIsValid) {
    return response.status(401).json({ error: 'Invalid Unique ID or Access Revoked' });
  }

  const sessionToken = randomBytes(32).toString('base64url');
  const expiresAt = new Date(Date.now() + sessionLifetimeMs);
  await pool.execute('DELETE FROM caretrack_sessions WHERE expires_at <= UTC_TIMESTAMP(3)');
  await pool.execute(
    'INSERT INTO caretrack_sessions (session_hash, user_id, expires_at) VALUES (?, ?, ?)',
    [hashToken(sessionToken), user.id, expiresAt],
  );
  response.cookie(sessionCookieName, sessionToken, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
    maxAge: sessionLifetimeMs,
  });
  response.json({ user: publicProfile(user) });
}));

const requireSession = asyncHandler(async (request, response, next) => {
  const sessionToken = request.cookies[sessionCookieName];
  if (!sessionToken) return response.status(401).json({ error: 'Authentication required.' });

  const [rows] = await getPool().execute(
    `SELECT u.generated_unique_id, u.full_name, u.work_email, u.role, u.permissions_json
     FROM caretrack_sessions s
     INNER JOIN caretrack_users u ON u.id = s.user_id
     WHERE s.session_hash = ?
       AND s.expires_at > UTC_TIMESTAMP(3)
       AND u.account_status = 'active'
     LIMIT 1`,
    [hashToken(sessionToken)],
  );
  if (!rows[0]) return response.status(401).json({ error: 'Invalid Unique ID or Access Revoked' });
  request.caretrackUser = rows[0];
  next();
});

app.get('/api/auth/me', requireSession, (request, response) => {
  response.json({ user: publicProfile(request.caretrackUser) });
});

app.post('/api/auth/logout', requireCsrf, asyncHandler(async (request, response) => {
  const sessionToken = request.cookies[sessionCookieName];
  if (sessionToken) {
    await getPool().execute('DELETE FROM caretrack_sessions WHERE session_hash = ?', [hashToken(sessionToken)]);
  }
  response.clearCookie(sessionCookieName, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
  });
  response.status(204).end();
}));

app.post('/api/registration-requests', registrationLimiter, requireCsrf, asyncHandler(async (request, response) => {
  const fullName = typeof request.body?.fullName === 'string' ? request.body.fullName.trim() : '';
  const workEmail = typeof request.body?.workEmail === 'string' ? request.body.workEmail.trim().toLowerCase() : '';
  const department = typeof request.body?.department === 'string' ? request.body.department.trim() : '';
  const role = typeof request.body?.role === 'string' ? request.body.role : '';
  const password = typeof request.body?.password === 'string' ? request.body.password : '';
  const authorized = request.body?.authorized === true;
  const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(workEmail);

  if (
    fullName.length < 2 || fullName.length > 120 ||
    !validEmail || workEmail.length > 254 ||
    department.length < 2 || department.length > 100 ||
    !registrationRoles.has(role) ||
    password.length < 8 || password.length > 128 ||
    !authorized
  ) {
    return response.status(400).json({ error: 'Please review the registration fields and try again.' });
  }

  const pool = getPool();
  const [activeMembers] = await pool.execute(
    'SELECT id FROM caretrack_users WHERE work_email = ? LIMIT 1',
    [workEmail],
  );
  const [pendingRequests] = await pool.execute(
    `SELECT request_id FROM caretrack_registration_requests
     WHERE work_email = ? AND request_status = 'pending' LIMIT 1`,
    [workEmail],
  );
  if (activeMembers.length > 0 || pendingRequests.length > 0) {
    return response.status(409).json({ error: 'An active account or pending request already uses this work email.' });
  }

  const requestId = randomUUID();
  const passwordHash = await hashPassword(password);
  await pool.execute(
    `INSERT INTO caretrack_registration_requests
      (request_id, full_name, work_email, department, role, password_hash, authorized_clinical_staff, request_status)
     VALUES (?, ?, ?, ?, ?, ?, 1, 'pending')`,
    [requestId, fullName, workEmail, department, role, passwordHash],
  );
  response.status(201).json({ requestId, status: 'pending' });
}));

app.get('/api/dashboard/overview', requireSession, (request, response) => {
  const profile = publicProfile(request.caretrackUser);
  if (!profile.permissions.includes('workspace:read')) {
    return response.status(403).json({ error: 'Dashboard access has not been assigned. Contact your administrator.' });
  }
  response.json({ user: profile });
});

app.use('/api', (_request, response) => {
  response.status(404).json({ error: 'CareTrack API endpoint not found.' });
});

app.use((error, _request, response, _next) => {
  if (error?.type === 'entity.parse.failed') {
    return response.status(400).json({ error: 'Request body must contain valid JSON.' });
  }
  if (error?.type === 'entity.too.large') {
    return response.status(413).json({ error: 'Request is too large.' });
  }
  console.error(`CareTrack request failed: ${error?.code || error?.name || 'internal_error'}`);
  response.status(503).json({ error: 'CareTrack service is temporarily unavailable. Please try again shortly.' });
});

async function start() {
  const isProduction = process.env.NODE_ENV === 'production';
  if (isProduction) {
    const distributionDirectory = path.join(rootDirectory, 'dist');
    app.use(express.static(distributionDirectory, { index: false, fallthrough: true }));
    app.get('*', (_request, response, next) => {
      response.sendFile(path.join(distributionDirectory, 'index.html'), (error) => {
        if (error) next(error);
      });
    });
  } else {
    viteServer = await createViteServer({
      root: rootDirectory,
      appType: 'spa',
      server: {
        middlewareMode: true,
        hmr: { server: httpServer },
      },
    });
    app.use(viteServer.middlewares);
  }

  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`CareTrack ${isProduction ? 'API' : 'development'} server listening on port ${port}.`);
  });
}

start().catch((error) => {
  console.error(`CareTrack could not start: ${error?.code || error?.name || 'startup_error'}`);
  process.exitCode = 1;
});

async function shutdown() {
  httpServer.close();
  if (viteServer) await viteServer.close();
  if (databasePool) await databasePool.end();
}

process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);
